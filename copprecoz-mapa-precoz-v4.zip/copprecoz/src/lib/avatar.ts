// Personaje del estudiante: se puede editar y vestir con ropa comprada
// con las monedas ganadas en las misiones. Local-first + sincronización.
import { supabase } from "@/integrations/supabase/client";
import { getGame, levelFromXp } from "@/lib/gamification";

const KEY = "copprecoz_avatar";
const EVENT = "copprecoz-avatar";

export type Slot = "cuerpo" | "pelo" | "camiseta" | "sombrero" | "gafas" | "mascota" | "fondo";

export type Genero = "mujer" | "hombre";

export type Peinado =
  | "corto"
  | "largo"
  | "rizado"
  | "coletas"
  | "moño"
  | "trenzas"
  | "afro"
  | "mohicano"
  | "calvo";

export const PEINADOS: { id: Peinado; nombre: string; emoji: string }[] = [
  { id: "corto", nombre: "Corto", emoji: "💇" },
  { id: "largo", nombre: "Largo", emoji: "💁" },
  { id: "rizado", nombre: "Rizado", emoji: "🌀" },
  { id: "coletas", nombre: "Coletas", emoji: "👧" },
  { id: "moño", nombre: "Moño", emoji: "🎀" },
  { id: "trenzas", nombre: "Trenzas", emoji: "🧶" },
  { id: "afro", nombre: "Afro", emoji: "🦱" },
  { id: "mohicano", nombre: "Mohicano", emoji: "🤘" },
  { id: "calvo", nombre: "Sin pelo", emoji: "🧑‍🦲" },
];

export type AvatarConfig = {
  nombre: string;
  genero: Genero;
  peinado: Peinado;
  piel: string;
  pelo: string;
  camiseta: string;
  sombrero: string | null;
  gafas: string | null;
  mascota: string | null;
  fondo: string;
};

export type AvatarState = { config: AvatarConfig; owned: string[] };

export const PIELES = ["#fbe0c4", "#f3d2b3", "#e8b98c", "#c78a5c", "#a06a3c", "#8d5a35", "#5c3a20"];
export const PELOS = [
  "#1c1614",
  "#2b2118",
  "#6b3f21",
  "#a9662b",
  "#c88c2c",
  "#e8c86a",
  "#d94f4f",
  "#e0619b",
  "#3f6fd9",
  "#37b3a1",
  "#8f8f8f",
  "#f1f1f1",
];

export type Prenda = {
  id: string;
  slot: Slot;
  nombre: string;
  precio: number;
  emoji?: string;
  color?: string;
  nivel?: number; // nivel mínimo para poder comprarla
};

export const TIENDA_ROPA: Prenda[] = [
  { id: "cam-naranja", slot: "camiseta", nombre: "Camiseta naranja", precio: 0, color: "#f97316" },
  { id: "cam-azul", slot: "camiseta", nombre: "Camiseta azul", precio: 300, color: "#3b82f6" },
  { id: "cam-verde", slot: "camiseta", nombre: "Camiseta verde", precio: 300, color: "#22c55e" },
  { id: "cam-morada", slot: "camiseta", nombre: "Camiseta morada", precio: 600, color: "#a855f7" },
  { id: "cam-amarilla", slot: "camiseta", nombre: "Camiseta amarilla", precio: 600, color: "#eab308" },
  { id: "cam-cooprecoz", slot: "camiseta", nombre: "Uniforme Cooprecoz", precio: 1500, color: "#0ea5e9", nivel: 3 },
  { id: "cam-rosa", slot: "camiseta", nombre: "Camiseta rosada", precio: 400, color: "#ec4899" },
  { id: "cam-turquesa", slot: "camiseta", nombre: "Camiseta turquesa", precio: 500, color: "#14b8a6" },
  { id: "cam-roja", slot: "camiseta", nombre: "Camiseta roja", precio: 400, color: "#ef4444" },
  { id: "cam-negra", slot: "camiseta", nombre: "Camiseta negra", precio: 800, color: "#1f2937" },
  { id: "cam-arcoiris", slot: "camiseta", nombre: "Camiseta arcoíris", precio: 2200, color: "#8b5cf6", nivel: 4 },

  { id: "gorra", slot: "sombrero", nombre: "Gorra", precio: 400, emoji: "🧢" },
  { id: "vueltiao", slot: "sombrero", nombre: "Sombrero vueltiao", precio: 1200, emoji: "👒", nivel: 2 },
  { id: "corona", slot: "sombrero", nombre: "Corona de campeón", precio: 2500, emoji: "👑", nivel: 5 },
  { id: "casco", slot: "sombrero", nombre: "Casco de aventura", precio: 900, emoji: "⛑️" },
  { id: "diadema", slot: "sombrero", nombre: "Diadema con moño", precio: 600, emoji: "🎀" },
  { id: "sombrero-fiesta", slot: "sombrero", nombre: "Gorro de fiesta", precio: 700, emoji: "🥳" },
  { id: "graduacion", slot: "sombrero", nombre: "Birrete", precio: 1600, emoji: "🎓", nivel: 3 },

  { id: "gafas-sol", slot: "gafas", nombre: "Gafas de sol", precio: 500, emoji: "🕶️" },
  { id: "gafas-lentes", slot: "gafas", nombre: "Lentes", precio: 350, emoji: "👓" },
  { id: "gafas-buceo", slot: "gafas", nombre: "Gafas de piscina", precio: 800, emoji: "🥽" },

  { id: "gato", slot: "mascota", nombre: "Gatico", precio: 1000, emoji: "🐱" },
  { id: "perro", slot: "mascota", nombre: "Perrito", precio: 1000, emoji: "🐶" },
  { id: "rana", slot: "mascota", nombre: "Rana dorada", precio: 2000, emoji: "🐸", nivel: 4 },
  { id: "loro", slot: "mascota", nombre: "Guacamayo", precio: 1800, emoji: "🦜", nivel: 3 },
  { id: "conejo", slot: "mascota", nombre: "Conejito", precio: 1100, emoji: "🐰" },
  { id: "tortuga", slot: "mascota", nombre: "Tortuga", precio: 1300, emoji: "🐢" },
  { id: "unicornio", slot: "mascota", nombre: "Unicornio", precio: 3000, emoji: "🦄", nivel: 6 },

  { id: "fondo-cielo", slot: "fondo", nombre: "Fondo cielo", precio: 0, color: "#dbeafe" },
  { id: "fondo-tienda", slot: "fondo", nombre: "Fondo tienda", precio: 700, color: "#fee2b3" },
  { id: "fondo-paramo", slot: "fondo", nombre: "Fondo páramo", precio: 700, color: "#d1fae5" },
  { id: "fondo-noche", slot: "fondo", nombre: "Fondo noche", precio: 1400, color: "#c7d2fe", nivel: 2 },
  { id: "fondo-rosa", slot: "fondo", nombre: "Fondo rosado", precio: 500, color: "#fbcfe8" },
  { id: "fondo-playa", slot: "fondo", nombre: "Fondo playa", precio: 900, color: "#bae6fd" },
  { id: "fondo-selva", slot: "fondo", nombre: "Fondo selva", precio: 1200, color: "#bbf7d0", nivel: 2 },
];

export const DEFAULT_AVATAR: AvatarState = {
  config: {
    nombre: "Mi personaje",
    genero: "mujer",
    peinado: "corto",
    piel: PIELES[1],
    pelo: PELOS[0],
    camiseta: "cam-naranja",
    sombrero: null,
    gafas: null,
    mascota: null,
    fondo: "fondo-cielo",
  },
  owned: ["cam-naranja", "fondo-cielo"],
};

export function prenda(id: string | null | undefined) {
  if (!id) return undefined;
  return TIENDA_ROPA.find((p) => p.id === id);
}

export function nivelActual() {
  return levelFromXp(getGame().xp);
}

export function getAvatar(): AvatarState {
  if (typeof window === "undefined") return DEFAULT_AVATAR;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return DEFAULT_AVATAR;
    const parsed = JSON.parse(raw) as Partial<AvatarState>;
    return {
      config: { ...DEFAULT_AVATAR.config, ...(parsed.config ?? {}) },
      owned: Array.from(new Set([...DEFAULT_AVATAR.owned, ...(parsed.owned ?? [])])),
    };
  } catch {
    return DEFAULT_AVATAR;
  }
}

export function saveAvatar(s: AvatarState) {
  window.localStorage.setItem(KEY, JSON.stringify(s));
  window.dispatchEvent(new Event(EVENT));
  void syncAvatar(s);
}

export function subscribeAvatar(cb: () => void) {
  if (typeof window === "undefined") return () => {};
  window.addEventListener(EVENT, cb);
  return () => window.removeEventListener(EVENT, cb);
}

async function syncAvatar(s: AvatarState) {
  try {
    if (!navigator.onLine) return;
    const { data } = await supabase.auth.getUser();
    const uid = data.user?.id;
    if (!uid) return;
    await supabase.from("avatars").upsert(
      {
        user_id: uid,
        config: JSON.parse(JSON.stringify(s.config)),
        owned: s.owned,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id" },
    );
  } catch {
    // se reintenta en el próximo guardado
  }
}

/** Trae el personaje guardado en la nube (al iniciar sesión en otro equipo). */
export async function pullAvatar() {
  try {
    const { data } = await supabase.auth.getUser();
    const uid = data.user?.id;
    if (!uid) return;
    const { data: row } = await supabase
      .from("avatars")
      .select("config, owned")
      .eq("user_id", uid)
      .maybeSingle();
    if (!row) return;
    const local = getAvatar();
    const merged: AvatarState = {
      config: { ...local.config, ...((row.config ?? {}) as Partial<AvatarConfig>) },
      owned: Array.from(new Set([...local.owned, ...((row.owned ?? []) as string[])])),
    };
    window.localStorage.setItem(KEY, JSON.stringify(merged));
    window.dispatchEvent(new Event(EVENT));
  } catch {
    // sin conexión: se usa lo local
  }
}