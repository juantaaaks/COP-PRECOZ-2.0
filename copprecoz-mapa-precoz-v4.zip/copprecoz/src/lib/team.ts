// Equipo Cooprecoz: quién puede usar la Calculadora Precoz y el Arqueo de caja.
// El maestro líder o el gerente (correos dueños) aprueban a cada integrante.
import { supabase } from "@/integrations/supabase/client";

export type EstadoEquipo = "pendiente" | "aprobado" | "rechazado";

export type Integrante = {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  cargo: string;
  status: EstadoEquipo;
  created_at: string;
};

export type MiEquipo = {
  email: string;
  esDueño: boolean;
  solicitud: Integrante | null;
  aprobado: boolean;
};

const CACHE_KEY = "copprecoz_equipo_estado";

/** Último estado conocido, para que funcione también sin conexión. */
export function equipoCache(): MiEquipo | null {
  if (typeof window === "undefined") return null;
  try {
    return JSON.parse(window.localStorage.getItem(CACHE_KEY) ?? "null") as MiEquipo | null;
  } catch {
    return null;
  }
}

export async function cargarMiEquipo(): Promise<MiEquipo> {
  const vacio: MiEquipo = { email: "", esDueño: false, solicitud: null, aprobado: false };
  try {
    const { data: u } = await supabase.auth.getUser();
    const email = (u.user?.email ?? "").toLowerCase();
    const uid = u.user?.id;
    if (!uid) return equipoCache() ?? vacio;

    const [{ data: owners }, { data: mine }] = await Promise.all([
      supabase.from("team_owners").select("email"),
      supabase.from("team_members").select("*").eq("user_id", uid).maybeSingle(),
    ]);

    const esDueño = (owners ?? []).some((o) => (o.email ?? "").toLowerCase() === email);
    const solicitud = (mine as Integrante | null) ?? null;
    const estado: MiEquipo = {
      email,
      esDueño,
      solicitud,
      aprobado: esDueño || solicitud?.status === "aprobado",
    };
    window.localStorage.setItem(CACHE_KEY, JSON.stringify(estado));
    return estado;
  } catch {
    return equipoCache() ?? vacio;
  }
}

export async function pedirAcceso(nombre: string, cargo: string) {
  const { data: u } = await supabase.auth.getUser();
  const user = u.user;
  if (!user) throw new Error("Inicia sesión con tu cuenta para pedir acceso.");
  const { error } = await supabase.from("team_members").insert({
    user_id: user.id,
    email: user.email ?? "",
    full_name: nombre,
    cargo,
    status: "pendiente",
  });
  if (error) throw error;
}

export async function listarEquipo(): Promise<Integrante[]> {
  const { data } = await supabase
    .from("team_members")
    .select("*")
    .order("created_at", { ascending: false });
  return (data ?? []) as Integrante[];
}

export async function cambiarEstado(id: string, status: EstadoEquipo) {
  const { data: u } = await supabase.auth.getUser();
  const { error } = await supabase
    .from("team_members")
    .update({
      status,
      approved_by: u.user?.id ?? null,
      approved_at: new Date().toISOString(),
    })
    .eq("id", id);
  if (error) throw error;
}

export async function quitarIntegrante(id: string) {
  const { error } = await supabase.from("team_members").delete().eq("id", id);
  if (error) throw error;
}

export async function listarDueños(): Promise<string[]> {
  const { data } = await supabase.from("team_owners").select("email");
  return (data ?? []).map((o) => o.email as string);
}

/** Agrega un correo de maestro líder o gerente (solo lo pueden hacer los dueños actuales). */
export async function agregarDueño(email: string) {
  const limpio = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(limpio)) throw new Error("Escribe un correo válido.");
  const { error } = await supabase.from("team_owners").insert({ email: limpio });
  if (error) throw new Error(error.code === "23505" ? "Ese correo ya es líder." : error.message);
}

export async function quitarDueño(email: string) {
  const { error } = await supabase.from("team_owners").delete().eq("email", email);
  if (error) throw error;
}
