// Arqueo de caja: conteo del dinero de la cooperativa.
// Local-first: se guarda en el dispositivo y se sincroniza con la nube.
import { supabase } from "@/integrations/supabase/client";
import { COP_DENOMINATIONS } from "@/lib/cop";

const DRAFT_KEY = "copprecoz_arqueo_borrador";
const LOCAL_KEY = "copprecoz_arqueos";
const QUEUE_KEY = "copprecoz_arqueos_pendientes";

export type Conteo = Record<number, number>;

export type Arqueo = {
  id: string;
  cashier_name: string;
  counted_at: string;
  denominations: Conteo;
  coins_total: number;
  bills_total: number;
  total: number;
  notes: string;
  pendiente?: boolean;
};

export function totales(conteo: Conteo) {
  let monedas = 0;
  let billetes = 0;
  for (const d of COP_DENOMINATIONS) {
    const n = conteo[d.value] ?? 0;
    if (n <= 0) continue;
    if (d.type === "moneda") monedas += n * d.value;
    else billetes += n * d.value;
  }
  return { monedas, billetes, total: monedas + billetes };
}

/* ------------------------------ borrador ------------------------------ */

export function getDraft(): Conteo {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(window.localStorage.getItem(DRAFT_KEY) ?? "{}") as Conteo;
  } catch {
    return {};
  }
}

export function saveDraft(c: Conteo) {
  window.localStorage.setItem(DRAFT_KEY, JSON.stringify(c));
}

export function clearDraft() {
  window.localStorage.removeItem(DRAFT_KEY);
}

/* ------------------------------ historial ----------------------------- */

function readLocal(): Arqueo[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(LOCAL_KEY) ?? "[]") as Arqueo[];
  } catch {
    return [];
  }
}

function writeLocal(list: Arqueo[]) {
  window.localStorage.setItem(LOCAL_KEY, JSON.stringify(list.slice(0, 200)));
}

function readQueue(): Arqueo[] {
  try {
    return JSON.parse(window.localStorage.getItem(QUEUE_KEY) ?? "[]") as Arqueo[];
  } catch {
    return [];
  }
}

function writeQueue(list: Arqueo[]) {
  window.localStorage.setItem(QUEUE_KEY, JSON.stringify(list));
}

export function pendientes() {
  if (typeof window === "undefined") return 0;
  return readQueue().length;
}

export async function guardarArqueo(input: {
  cashier_name: string;
  denominations: Conteo;
  notes: string;
}): Promise<Arqueo> {
  const t = totales(input.denominations);
  const a: Arqueo = {
    id: crypto.randomUUID(),
    cashier_name: input.cashier_name,
    counted_at: new Date().toISOString(),
    denominations: input.denominations,
    coins_total: t.monedas,
    bills_total: t.billetes,
    total: t.total,
    notes: input.notes,
    pendiente: true,
  };
  writeLocal([a, ...readLocal()]);
  writeQueue([a, ...readQueue()]);
  await sincronizar();
  return a;
}

export async function sincronizar() {
  if (typeof window === "undefined" || !navigator.onLine) return;
  const q = readQueue();
  if (q.length === 0) return;
  const { data } = await supabase.auth.getUser();
  const uid = data.user?.id;
  if (!uid) return;
  const restantes: Arqueo[] = [];
  for (const a of q) {
    const { error } = await supabase.from("cash_counts").insert({
      id: a.id,
      user_id: uid,
      cashier_name: a.cashier_name,
      counted_at: a.counted_at,
      denominations: a.denominations as unknown as never,
      coins_total: a.coins_total,
      bills_total: a.bills_total,
      total: a.total,
      notes: a.notes,
    });
    if (error && error.code !== "23505") restantes.push(a);
  }
  writeQueue(restantes);
  const pendIds = new Set(restantes.map((r) => r.id));
  writeLocal(readLocal().map((a) => ({ ...a, pendiente: pendIds.has(a.id) })));
}

/** Historial combinado: nube + lo que aún no se ha sincronizado. */
export async function listarArqueos(): Promise<Arqueo[]> {
  const locales = readLocal();
  try {
    const { data: u } = await supabase.auth.getUser();
    const uid = u.user?.id;
    if (!uid || !navigator.onLine) return locales;
    const { data } = await supabase
      .from("cash_counts")
      .select("id, cashier_name, counted_at, denominations, coins_total, bills_total, total, notes")
      .eq("user_id", uid)
      .order("counted_at", { ascending: false })
      .limit(200);
    const nube: Arqueo[] = (data ?? []).map((r) => ({
      id: r.id,
      cashier_name: r.cashier_name,
      counted_at: r.counted_at,
      denominations: (r.denominations ?? {}) as unknown as Conteo,
      coins_total: r.coins_total,
      bills_total: r.bills_total,
      total: r.total,
      notes: r.notes ?? "",
    }));
    const ids = new Set(nube.map((n) => n.id));
    const soloLocal = locales.filter((l) => !ids.has(l.id));
    const todos = [...nube, ...soloLocal].sort((a, b) => b.counted_at.localeCompare(a.counted_at));
    writeLocal(todos);
    return todos;
  } catch {
    return locales;
  }
}

export async function eliminarArqueo(id: string) {
  writeLocal(readLocal().filter((a) => a.id !== id));
  writeQueue(readQueue().filter((a) => a.id !== id));
  try {
    await supabase.from("cash_counts").delete().eq("id", id);
  } catch {
    // sin conexión: ya quedó fuera del historial local
  }
}
/** Todos los arqueos del equipo (los dueños los ven por las reglas de la nube). */
export async function listarArqueosEquipo(): Promise<Arqueo[]> {
  const { data } = await supabase
    .from("cash_counts")
    .select("id, cashier_name, counted_at, denominations, coins_total, bills_total, total, notes")
    .order("counted_at", { ascending: false })
    .limit(500);
  return (data ?? []).map((r) => ({
    id: r.id,
    cashier_name: r.cashier_name,
    counted_at: r.counted_at,
    denominations: (r.denominations ?? {}) as unknown as Conteo,
    coins_total: r.coins_total,
    bills_total: r.bills_total,
    total: r.total,
    notes: r.notes ?? "",
  }));
}
