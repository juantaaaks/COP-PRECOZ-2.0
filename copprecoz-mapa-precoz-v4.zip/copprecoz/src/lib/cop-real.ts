/**
 * Fotos reales de billetes y monedas guardadas dentro del proyecto
 * (carpeta src/assets/cop-real). Así no dependen de un servidor externo.
 *
 * PARA AGREGAR O CAMBIAR UNA FOTO: guarda el archivo en src/assets/cop-real
 * con el nombre front-<valor>.jpg (parte de adelante) o back-<valor>.jpg
 * (parte de atrás). Ejemplo: front-20000.jpg, back-500.jpg.
 * Si una foto no está aquí, la app usa la que ya estaba cargada en Lovable.
 */
const files = import.meta.glob("../assets/cop-real/*.jpg", {
  eager: true,
  query: "?url",
  import: "default",
}) as Record<string, string>;

function collect(side: "front" | "back"): Record<number, string> {
  const out: Record<number, string> = {};
  for (const [path, url] of Object.entries(files)) {
    const m = path.match(new RegExp(`${side}-(\\d+)\\.jpg$`));
    if (m) out[Number(m[1])] = url;
  }
  return out;
}

export const REAL_FRONT = collect("front");
export const REAL_BACK = collect("back");
