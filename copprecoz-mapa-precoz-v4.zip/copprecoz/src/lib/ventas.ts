// Ventas de la cooperativa: lo que se vendió con la Calculadora Precoz.
// Local-first: se guarda en el dispositivo y se sube a la nube cuando hay sesión.
import { supabase } from "@/integrations/supabase/client";

const LOCAL_KEY = "copprecoz_ventas";

export type Venta = {
  id: string;
  seller_name: string;
  sold_at: string;
  items: Record<string, number>;
  total: number;
  received: number;
  change_given: number;
  notes: string;
};

function readLocal(): Venta[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(LOCAL_KEY) ?? "[]") as Venta[];
  } catch {
    return [];
  }
}

function writeLocal(list: Venta[]) {
  window.localStorage.setItem(LOCAL_KEY, JSON.stringify(list.slice(0, 300)));
}

export function hoyISO() {
  return new Date().toISOString().slice(0, 10);
}

/** Guarda una venta (queda local aunque no haya conexión). */
export async function guardarVenta(input: {
  seller_name: string;
  items: Record<string, number>;
  total: number;
  received: number;
  change_given: number;
  notes?: string;
}): Promise<Venta> {
  const v: Venta = {
    id: crypto.randomUUID(),
    seller_name: input.seller_name,
    sold_at: new Date().toISOString(),
    items: input.items,
    total: input.total,
    received: input.received,
    change_given: input.change_given,
    notes: input.notes ?? "",
  };
  writeLocal([v, ...readLocal()]);
  try {
    const { data } = await supabase.auth.getUser();
    const uid = data.user?.id;
    if (uid) {
      await supabase.from("sales").insert({
        id: v.id,
        user_id: uid,
        seller_name: v.seller_name,
        sold_at: v.sold_at,
        items: v.items as unknown as never,
        total: v.total,
        received: v.received,
        change_given: v.change_given,
        notes: v.notes,
      });
    }
  } catch {
    // sin conexión: queda guardada en el dispositivo
  }
  return v;
}

/** Ventas propias (nube + locales), ordenadas de la más nueva a la más vieja. */
export async function listarVentas(): Promise<Venta[]> {
  const locales = readLocal();
  try {
    const { data: u } = await supabase.auth.getUser();
    const uid = u.user?.id;
    if (!uid || !navigator.onLine) return locales;
    const { data } = await supabase
      .from("sales")
      .select("id, seller_name, sold_at, items, total, received, change_given, notes")
      .eq("user_id", uid)
      .order("sold_at", { ascending: false })
      .limit(300);
    const nube: Venta[] = (data ?? []).map((r) => ({
      id: r.id,
      seller_name: r.seller_name,
      sold_at: r.sold_at,
      items: (r.items ?? {}) as unknown as Record<string, number>,
      total: r.total,
      received: r.received,
      change_given: r.change_given,
      notes: r.notes ?? "",
    }));
    const ids = new Set(nube.map((n) => n.id));
    const todas = [...nube, ...locales.filter((l) => !ids.has(l.id))].sort((a, b) =>
      b.sold_at.localeCompare(a.sold_at),
    );
    writeLocal(todas);
    return todas;
  } catch {
    return locales;
  }
}

/** Todas las ventas del equipo (solo los dueños las pueden ver por las reglas de la nube). */
export async function listarVentasEquipo(): Promise<Venta[]> {
  const { data } = await supabase
    .from("sales")
    .select("id, seller_name, sold_at, items, total, received, change_given, notes")
    .order("sold_at", { ascending: false })
    .limit(500);
  return (data ?? []).map((r) => ({
    id: r.id,
    seller_name: r.seller_name,
    sold_at: r.sold_at,
    items: (r.items ?? {}) as unknown as Record<string, number>,
    total: r.total,
    received: r.received,
    change_given: r.change_given,
    notes: r.notes ?? "",
  }));
}

export type ResumenDia = {
  fecha: string;
  cantidad: number;
  vendido: number;
  recibido: number;
  devuelto: number;
};

export function resumenDelDia(ventas: Venta[], fecha = hoyISO()): ResumenDia {
  const dia = ventas.filter((v) => v.sold_at.slice(0, 10) === fecha);
  return {
    fecha,
    cantidad: dia.length,
    vendido: dia.reduce((s, v) => s + v.total, 0),
    recibido: dia.reduce((s, v) => s + v.received, 0),
    devuelto: dia.reduce((s, v) => s + v.change_given, 0),
  };
}
