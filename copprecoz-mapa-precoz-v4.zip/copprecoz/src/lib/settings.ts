// Preferencias de la app: cómo se muestra el dinero y el tema (claro/oscuro).
export type MoneyFormat = "digitos" | "palabras";
export type Theme = "light" | "dark";

const MONEY_KEY = "pesopro_money_format";
const THEME_KEY = "pesopro_theme";
const EVENT = "pesopro-settings";

const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
  if (typeof window !== "undefined") window.dispatchEvent(new Event(EVENT));
}

export function subscribeSettings(cb: () => void) {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

export function getMoneyFormat(): MoneyFormat {
  if (typeof window === "undefined") return "digitos";
  return window.localStorage.getItem(MONEY_KEY) === "palabras" ? "palabras" : "digitos";
}

export function setMoneyFormat(f: MoneyFormat) {
  window.localStorage.setItem(MONEY_KEY, f);
  emit();
}

export function getTheme(): Theme {
  if (typeof window === "undefined") return "light";
  return window.localStorage.getItem(THEME_KEY) === "dark" ? "dark" : "light";
}

export function applyTheme(t: Theme) {
  document.documentElement.classList.toggle("dark", t === "dark");
}

export function setTheme(t: Theme) {
  window.localStorage.setItem(THEME_KEY, t);
  applyTheme(t);
  emit();
}

/* ------------------- Preferencias de accesibilidad ------------------- */

export type Difficulty = "basica" | "intermedia" | "avanzada";

export type A11ySettings = {
  fontScale: number; // 1 = normal
  highContrast: boolean;
  sounds: boolean;
  readAloud: boolean;
  speechRate: number; // 0.6 - 1.4
  pictograms: boolean;
  reduceMotion: boolean;
  lowStimulus: boolean;
  difficulty: Difficulty;
  language: "es";
};

export const DEFAULT_A11Y: A11ySettings = {
  fontScale: 1,
  highContrast: false,
  sounds: true,
  readAloud: true,
  speechRate: 0.95,
  pictograms: true,
  reduceMotion: false,
  lowStimulus: false,
  difficulty: "basica",
  language: "es",
};

const A11Y_KEY = "copprecoz_a11y";

export function getA11y(): A11ySettings {
  if (typeof window === "undefined") return DEFAULT_A11Y;
  try {
    const raw = window.localStorage.getItem(A11Y_KEY);
    if (!raw) return DEFAULT_A11Y;
    return { ...DEFAULT_A11Y, ...(JSON.parse(raw) as Partial<A11ySettings>) };
  } catch {
    return DEFAULT_A11Y;
  }
}

export function applyA11y(s: A11ySettings) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.style.setProperty("--font-scale", String(s.fontScale));
  root.classList.toggle("hc", s.highContrast);
  root.classList.toggle("reduce-motion", s.reduceMotion);
  root.classList.toggle("low-stimulus", s.lowStimulus);
}

export function setA11y(patch: Partial<A11ySettings>) {
  const next = { ...getA11y(), ...patch };
  window.localStorage.setItem(A11Y_KEY, JSON.stringify(next));
  applyA11y(next);
  emit();
}

export function resetA11y() {
  window.localStorage.removeItem(A11Y_KEY);
  applyA11y(DEFAULT_A11Y);
  emit();
}

// "10 mil 500" — lectura amigable para educandos.
export function moneyWords(value: number): string {
  const v = Math.max(0, Math.round(value));
  if (v === 0) return "0";
  const miles = Math.floor(v / 1000);
  const resto = v % 1000;
  const parts: string[] = [];
  if (miles > 0) parts.push(`${miles} mil`);
  if (resto > 0) parts.push(String(resto));
  return parts.join(" ");
}

export function moneyDigits(value: number): string {
  return `$ ${Math.round(value).toLocaleString("es-CO")}`;
}

export function formatMoney(value: number, format: MoneyFormat): string {
  return format === "palabras" ? `${moneyWords(value)} pesos` : moneyDigits(value);
}
