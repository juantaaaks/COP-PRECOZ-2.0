// Modo invitado: acceso rápido sin cuenta (el progreso no se guarda).
const KEY = "pesopro_guest";

export function isGuest() {
  if (typeof window === "undefined") return false;
  return window.localStorage.getItem(KEY) === "1";
}

export function enableGuest() {
  window.localStorage.setItem(KEY, "1");
}

export function disableGuest() {
  window.localStorage.removeItem(KEY);
}
