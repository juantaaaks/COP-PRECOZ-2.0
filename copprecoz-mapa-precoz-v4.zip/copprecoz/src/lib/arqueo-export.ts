// Exportar el historial de arqueos a CSV o PDF (impresión del navegador).
import { COP_DENOMINATIONS, formatCOP } from "@/lib/cop";
import type { Arqueo } from "@/lib/arqueo";

function fechaLarga(iso: string) {
  return new Date(iso).toLocaleString("es-CO", { dateStyle: "medium", timeStyle: "short" });
}

function descargar(nombre: string, contenido: string, tipo: string) {
  const blob = new Blob([contenido], { type: tipo });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nombre;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

const DENOMS = [...COP_DENOMINATIONS].sort((a, b) => a.value - b.value);

export function exportarCSV(lista: Arqueo[]) {
  const cab = [
    "Fecha y hora",
    "Cajero/a",
    ...DENOMS.map((d) => `${d.type} ${d.value}`),
    "Total monedas",
    "Total billetes",
    "Total en caja",
    "Observaciones",
  ];
  const filas = lista.map((a) => [
    fechaLarga(a.counted_at),
    a.cashier_name,
    ...DENOMS.map((d) => String(a.denominations[d.value] ?? 0)),
    String(a.coins_total),
    String(a.bills_total),
    String(a.total),
    (a.notes ?? "").replace(/\s+/g, " "),
  ]);
  const csv = [cab, ...filas]
    .map((f) => f.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(";"))
    .join("\n");
  descargar(`arqueos-copprecoz-${new Date().toISOString().slice(0, 10)}.csv`, "\ufeff" + csv, "text/csv;charset=utf-8");
}

export function exportarPDF(lista: Arqueo[]) {
  const total = lista.reduce((s, a) => s + a.total, 0);
  const bloques = lista
    .map((a) => {
      const filas = DENOMS.filter((d) => (a.denominations[d.value] ?? 0) > 0)
        .map(
          (d) => `<tr><td>${d.type === "moneda" ? "Moneda" : "Billete"} de ${formatCOP(d.value)}</td>
            <td class="n">${a.denominations[d.value]}</td>
            <td class="n">${formatCOP((a.denominations[d.value] ?? 0) * d.value)}</td></tr>`,
        )
        .join("");
      return `<section>
        <h2>${fechaLarga(a.counted_at)}</h2>
        <p class="sub">Cajero/a: <b>${a.cashier_name}</b></p>
        <table><thead><tr><th>Denominación</th><th class="n">Cantidad</th><th class="n">Valor</th></tr></thead>
        <tbody>${filas || '<tr><td colspan="3">Sin dinero registrado</td></tr>'}</tbody></table>
        <p class="tot">Monedas: <b>${formatCOP(a.coins_total)}</b> · Billetes: <b>${formatCOP(a.bills_total)}</b>
          · Total en caja: <b>${formatCOP(a.total)}</b></p>
        ${a.notes ? `<p class="obs">Observaciones: ${a.notes}</p>` : ""}
      </section>`;
    })
    .join("");

  const html = `<!doctype html><html lang="es"><head><meta charset="utf-8">
    <title>Arqueos de caja — COPprecoz</title>
    <style>
      body { font-family: system-ui, sans-serif; color: #1f2937; margin: 32px; }
      h1 { color: #d2601a; margin-bottom: 4px; }
      h2 { font-size: 16px; margin: 0 0 2px; }
      section { border: 2px solid #f0e2d4; border-radius: 14px; padding: 14px 16px; margin-bottom: 14px; page-break-inside: avoid; }
      table { width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 13px; }
      th, td { border-bottom: 1px solid #eee; padding: 6px 4px; text-align: left; }
      .n { text-align: right; }
      .sub, .obs { font-size: 13px; color: #6b7280; margin: 0; }
      .tot { font-size: 14px; margin: 6px 0 2px; }
      .resumen { background: #fff5ec; border-radius: 14px; padding: 12px 16px; margin-bottom: 18px; }
    </style></head><body>
    <h1>Arqueos de caja — COPprecoz</h1>
    <div class="resumen">Cooperativa escolar · ${lista.length} arqueo(s) · Suma de totales: <b>${formatCOP(total)}</b><br>
    Generado el ${fechaLarga(new Date().toISOString())}</div>
    ${bloques || "<p>No hay arqueos guardados.</p>"}
    </body></html>`;

  const w = window.open("", "_blank");
  if (!w) return false;
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 400);
  return true;
}
/** Exporta el historial a un Excel (.xlsx) que se puede editar en Excel o Google Sheets. */
export async function exportarExcel(lista: Arqueo[]) {
  const XLSX = await import("xlsx");
  const filas = lista.map((a) => {
    const fila: Record<string, string | number> = {
      "Fecha y hora": fechaLarga(a.counted_at),
      "Cajero/a": a.cashier_name,
    };
    for (const d of DENOMS) {
      fila[`${d.type === "moneda" ? "Moneda" : "Billete"} ${d.value}`] = a.denominations[d.value] ?? 0;
    }
    fila["Total monedas"] = a.coins_total;
    fila["Total billetes"] = a.bills_total;
    fila["Total en caja"] = a.total;
    fila["Observaciones"] = a.notes ?? "";
    return fila;
  });
  const hoja = XLSX.utils.json_to_sheet(
    filas.length > 0 ? filas : [{ "Fecha y hora": "", "Cajero/a": "", "Total en caja": 0 }],
  );
  hoja["!cols"] = [{ wch: 22 }, { wch: 20 }, ...DENOMS.map(() => ({ wch: 12 }))];
  const libro = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(libro, hoja, "Arqueos");
  XLSX.writeFile(libro, `arqueos-copprecoz-${new Date().toISOString().slice(0, 10)}.xlsx`);
}
