import { useEffect, useState } from "react";

/**
 * Reversos (parte de atrás) de billetes y monedas COP.
 *
 * PARA EL DESARROLLADOR:
 * 1) Sube la imagen del reverso y pega aquí su URL (o importa un .asset.json y usa .url).
 * 2) También puedes cargarlas sin tocar código desde la página /reversos
 *    (se guardan en este navegador).
 */
import back100000 from "@/assets/cop-back/back-100000.jpg.asset.json";
import back50000 from "@/assets/cop-back/back-50000.jpg.asset.json";
import back20000 from "@/assets/cop-back/back-20000.jpg.asset.json";
import back10000 from "@/assets/cop-back/back-10000.jpg.asset.json";
import back5000 from "@/assets/cop-back/back-5000.jpg.asset.json";
import back2000 from "@/assets/cop-back/back-2000.jpg.asset.json";
import back1000 from "@/assets/cop-back/back-1000.jpg.asset.json";
import back200 from "@/assets/cop-back/back-200.jpg.asset.json";
import back100 from "@/assets/cop-back/back-100.jpg.asset.json";
import back500 from "@/assets/cop-back/back-500.jpg.asset.json";
import back50 from "@/assets/cop-back/back-50.jpg.asset.json";

import { REAL_BACK } from "@/lib/cop-real";

const LOVABLE_BACKS: Record<number, string> = {
  100000: back100000.url,
  50000: back50000.url,
  20000: back20000.url,
  10000: back10000.url,
  5000: back5000.url,
  2000: back2000.url,
  1000: back1000.url,
  500: back500.url,
  200: back200.url,
  100: back100.url,
  50: back50.url,
};

// Primero la foto guardada en el proyecto; si no existe, la de Lovable.
export const COP_BACK_IMAGES_DEFAULT: Record<number, string> = { ...LOVABLE_BACKS, ...REAL_BACK };

const KEY = "copprecoz.backImages.v1";
const EVT = "copprecoz-back-images";

function readOverrides(): Record<number, string> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? "{}") as Record<number, string>;
  } catch {
    return {};
  }
}

export function getBackImages(): Record<number, string> {
  return { ...COP_BACK_IMAGES_DEFAULT, ...readOverrides() };
}

export function getBackImage(value: number): string {
  return getBackImages()[value] ?? "";
}

export function setBackImage(value: number, url: string) {
  const next = readOverrides();
  if (url.trim()) next[value] = url.trim();
  else delete next[value];
  localStorage.setItem(KEY, JSON.stringify(next));
  window.dispatchEvent(new Event(EVT));
}

export function clearBackImages() {
  localStorage.removeItem(KEY);
  window.dispatchEvent(new Event(EVT));
}

export function useBackImages() {
  const [imgs, setImgs] = useState<Record<number, string>>(COP_BACK_IMAGES_DEFAULT);
  useEffect(() => {
    const sync = () => setImgs(getBackImages());
    sync();
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);
  return imgs;
}
