import { formatMoney, getMoneyFormat } from "@/lib/settings";

// Formatea valores en COP según la opción elegida: "$ 2.000" o "2 mil pesos".
export function formatCOP(value: number): string {
  return formatMoney(value, getMoneyFormat());
}

export const COP_DENOMINATIONS = [
  { value: 100000, type: "billete", color: "#a855f7", name: "Cien mil pesos" },
  { value: 50000, type: "billete", color: "#ec4899", name: "Cincuenta mil pesos" },
  { value: 20000, type: "billete", color: "#f97316", name: "Veinte mil pesos" },
  { value: 10000, type: "billete", color: "#ef4444", name: "Diez mil pesos" },
  { value: 5000, type: "billete", color: "#eab308", name: "Cinco mil pesos" },
  { value: 2000, type: "billete", color: "#3b82f6", name: "Dos mil pesos" },
  { value: 1000, type: "moneda", color: "#facc15", name: "Mil pesos" },
  { value: 500, type: "moneda", color: "#fbbf24", name: "Quinientos pesos" },
  { value: 200, type: "moneda", color: "#d4d4d8", name: "Doscientos pesos" },
  { value: 100, type: "moneda", color: "#a1a1aa", name: "Cien pesos" },
  { value: 50, type: "moneda", color: "#71717a", name: "Cincuenta pesos" },
] as const;

export type Denomination = (typeof COP_DENOMINATIONS)[number];

// Pistas para reconocer cada billete/moneda de otras maneras (color, personaje, tamaño).
export const COP_FACTS: Record<number, { color: string; quien: string; pista: string }> = {
  100000: {
    color: "morado claro y verde",
    quien: "Carlos Lleras Restrepo",
    pista: "Es el billete de mayor valor. Tiene el Valle de Cocora con palmas de cera.",
  },
  50000: {
    color: "morado",
    quien: "Gabriel García Márquez",
    pista: "Billete morado con mariposas amarillas y la Ciudad Perdida.",
  },
  20000: {
    color: "naranja",
    quien: "Alfonso López Michelsen",
    pista: "Billete naranja con el sombrero vueltiao y el Canal del Dique.",
  },
  10000: {
    color: "rojo",
    quien: "Virginia Gutiérrez de Pineda",
    pista: "Billete rojo con la Amazonía y la flor Victoria amazónica.",
  },
  5000: {
    color: "verde",
    quien: "José Asunción Silva",
    pista: "Billete verde con el páramo y los frailejones.",
  },
  2000: {
    color: "azul",
    quien: "Débora Arango",
    pista: "Es el billete azul, el más pequeño en valor.",
  },
  1000: {
    color: "plateada por dentro y dorada por fuera",
    quien: "una tortuga caguama",
    pista: "Moneda grande de dos colores con una tortuga de mar.",
  },
  500: {
    color: "dorada por dentro y plateada por fuera",
    quien: "una rana de cristal",
    pista: "Moneda de dos colores con una ranita, al revés que la de mil.",
  },
  200: {
    color: "plateada",
    quien: "un guacamayo",
    pista: "Moneda plateada mediana con un pájaro.",
  },
  100: {
    color: "dorada",
    quien: "el frailejón",
    pista: "Moneda dorada con una planta del páramo.",
  },
  50: {
    color: "plateada",
    quien: "el oso de anteojos",
    pista: "Es la moneda más pequeña de todas.",
  },
};

// Descompone un valor en billetes y monedas COP (mayor a menor).
export function breakdownCOP(value: number): { value: number; count: number }[] {
  let rest = Math.max(0, Math.floor(value));
  const out: { value: number; count: number }[] = [];
  for (const d of COP_DENOMINATIONS) {
    const count = Math.floor(rest / d.value);
    if (count > 0) {
      out.push({ value: d.value, count });
      rest -= count * d.value;
    }
  }
  return out;
}

import bill100000 from "@/assets/cop/bill-100000.jpg.asset.json";
import bill50000 from "@/assets/cop/bill-50000.jpg.asset.json";
import bill20000 from "@/assets/cop/bill-20000.jpg.asset.json";
import bill10000 from "@/assets/cop/bill-10000.jpg.asset.json";
import bill5000 from "@/assets/cop/bill-5000.jpg.asset.json";
import bill2000 from "@/assets/cop/bill-2000.jpg.asset.json";
import coin1000 from "@/assets/cop/coin-1000.jpg.asset.json";
import coin500 from "@/assets/cop/coin-500.jpg.asset.json";
import coin200 from "@/assets/cop/coin-200.jpg.asset.json";
import coin100 from "@/assets/cop/coin-100.jpg.asset.json";
import coin50 from "@/assets/cop/coin-50.jpg.asset.json";

import { REAL_FRONT } from "@/lib/cop-real";

const LOVABLE_IMAGES: Record<number, string> = {
  100000: bill100000.url,
  50000: bill50000.url,
  20000: bill20000.url,
  10000: bill10000.url,
  5000: bill5000.url,
  2000: bill2000.url,
  1000: coin1000.url,
  500: coin500.url,
  200: coin200.url,
  100: coin100.url,
  50: coin50.url,
};

// Primero la foto guardada en el proyecto; si no existe, la de Lovable.
export const COP_IMAGES: Record<number, string> = { ...LOVABLE_IMAGES, ...REAL_FRONT };
