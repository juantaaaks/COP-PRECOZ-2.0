import { supabase } from "@/integrations/supabase/client";

// Aviso local del avance para que el encabezado del módulo lo muestre al instante.
type ProgressListener = (slug: string, percent: number) => void;
const listeners = new Set<ProgressListener>();

export function subscribeModuleProgress(fn: ProgressListener) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export async function saveModuleProgress(slug: string, percent: number) {
  listeners.forEach((fn) => fn(slug, percent));
  const { data } = await supabase.auth.getUser();
  const uid = data.user?.id;
  if (!uid) return;
  await supabase
    .from("module_progress")
    .upsert(
      { user_id: uid, module_slug: slug, percent, updated_at: new Date().toISOString() },
      { onConflict: "user_id,module_slug" },
    );
}

export async function addXpAndCoins(xp: number, coins: number) {
  const { data } = await supabase.auth.getUser();
  const uid = data.user?.id;
  if (!uid) return;
  const { data: cur } = await supabase
    .from("student_progress")
    .select("xp, coins, level")
    .eq("user_id", uid)
    .maybeSingle();
  const newXp = (cur?.xp ?? 0) + xp;
  const newLevel = Math.max(cur?.level ?? 1, Math.floor(newXp / 1000) + 1);
  await supabase
    .from("student_progress")
    .update({
      xp: newXp,
      coins: (cur?.coins ?? 0) + coins,
      level: newLevel,
      last_active_date: new Date().toISOString().slice(0, 10),
      updated_at: new Date().toISOString(),
    })
    .eq("user_id", uid);
}