// Mapa Precoz: una ciudad pequeña con COOPRECOZ en el centro.
// El estudiante trabaja en la cooperativa, viaja en carro (estilo Uber)
// y compra en lugares del día a día usando todo lo que aprendió.
import { COP_DENOMINATIONS, breakdownCOP } from "@/lib/cop";

export type PlaceId = "cooprecoz" | "drogueria" | "utiles" | "mercado" | "plaza";

export type Producto = {
  name: string;
  emoji: string;
  price: number;
  tipo: "necesidad" | "gusto";
};

export type Place = {
  id: PlaceId;
  name: string;
  short: string;
  emoji: string;
  desc: string;
  /** posición en el mapa, en % del ancho/alto */
  x: number;
  y: number;
  tone: string; // clases de color de la tarjeta
  vendedor: string;
  productos: Producto[];
};

export const PLACES: Place[] = [
  {
    id: "cooprecoz",
    name: "COOPRECOZ",
    short: "Cooprecoz",
    emoji: "🏫",
    desc: "Trabaja en la cooperativa: cobra y entrega el vuelto",
    x: 50,
    y: 50,
    tone: "bg-primary text-primary-foreground ring-primary",
    vendedor: "Equipo Cooprecoz",
    productos: [],
  },
  {
    id: "drogueria",
    name: "Droguería",
    short: "Droguería",
    emoji: "💊",
    desc: "Medicinas y cuidado personal",
    x: 20,
    y: 20,
    tone: "bg-mod-finanzas-soft text-mod-finanzas ring-mod-finanzas/40",
    vendedor: "Doña Marta",
    productos: [
      { name: "Acetaminofén", emoji: "💊", price: 3500, tipo: "necesidad" },
      { name: "Curitas", emoji: "🩹", price: 2800, tipo: "necesidad" },
      { name: "Crema dental", emoji: "🪥", price: 5900, tipo: "necesidad" },
      { name: "Jabón", emoji: "🧼", price: 3200, tipo: "necesidad" },
      { name: "Alcohol", emoji: "🧴", price: 6200, tipo: "necesidad" },
      { name: "Chicles", emoji: "🍬", price: 1000, tipo: "gusto" },
      { name: "Gafas de sol", emoji: "🕶️", price: 15000, tipo: "gusto" },
    ],
  },
  {
    id: "utiles",
    name: "Útiles escolares",
    short: "Útiles",
    emoji: "✏️",
    desc: "Papelería para el colegio",
    x: 80,
    y: 20,
    tone: "bg-mod-conocer-soft text-mod-conocer ring-mod-conocer/40",
    vendedor: "Don Jaime",
    productos: [
      { name: "Cuaderno", emoji: "📓", price: 6500, tipo: "necesidad" },
      { name: "Lápiz", emoji: "✏️", price: 1200, tipo: "necesidad" },
      { name: "Borrador", emoji: "🧽", price: 800, tipo: "necesidad" },
      { name: "Colores", emoji: "🖍️", price: 9900, tipo: "necesidad" },
      { name: "Regla", emoji: "📏", price: 2300, tipo: "necesidad" },
      { name: "Tijeras", emoji: "✂️", price: 4500, tipo: "necesidad" },
      { name: "Stickers", emoji: "⭐", price: 3000, tipo: "gusto" },
    ],
  },
  {
    id: "mercado",
    name: "Mercado",
    short: "Mercado",
    emoji: "🛒",
    desc: "Supermercado del barrio",
    x: 20,
    y: 80,
    tone: "bg-mod-tienda-soft text-mod-tienda ring-mod-tienda/40",
    vendedor: "Cajera Luisa",
    productos: [
      { name: "Arroz", emoji: "🍚", price: 3800, tipo: "necesidad" },
      { name: "Leche", emoji: "🥛", price: 4200, tipo: "necesidad" },
      { name: "Huevos", emoji: "🥚", price: 5400, tipo: "necesidad" },
      { name: "Pan", emoji: "🥖", price: 1500, tipo: "necesidad" },
      { name: "Aceite", emoji: "🫗", price: 9800, tipo: "necesidad" },
      { name: "Galletas", emoji: "🍪", price: 2500, tipo: "gusto" },
      { name: "Gaseosa", emoji: "🥤", price: 3200, tipo: "gusto" },
    ],
  },
  {
    id: "plaza",
    name: "Plaza de mercado",
    short: "Plaza",
    emoji: "🍅",
    desc: "Frutas y verduras frescas",
    x: 80,
    y: 80,
    tone: "bg-mod-recibo-soft text-mod-recibo ring-mod-recibo/40",
    vendedor: "Don Pacho",
    productos: [
      { name: "Tomate", emoji: "🍅", price: 2000, tipo: "necesidad" },
      { name: "Papa", emoji: "🥔", price: 1800, tipo: "necesidad" },
      { name: "Plátano", emoji: "🍌", price: 1000, tipo: "necesidad" },
      { name: "Cebolla", emoji: "🧅", price: 1500, tipo: "necesidad" },
      { name: "Aguacate", emoji: "🥑", price: 3000, tipo: "necesidad" },
      { name: "Cilantro", emoji: "🌿", price: 500, tipo: "necesidad" },
      { name: "Mango biche", emoji: "🥭", price: 2500, tipo: "gusto" },
    ],
  },
];

export function getPlace(id: PlaceId): Place {
  return PLACES.find((p) => p.id === id) ?? PLACES[0];
}

/* ----------------------------- Viaje tipo Uber ----------------------------- */

export const CONDUCTORES = [
  { nombre: "Don Luis", carro: "Carro azul", placa: "CPZ 482", color: "#3b82f6" },
  { nombre: "Doña Ana", carro: "Carro rojo", placa: "BGA 315", color: "#ef4444" },
  { nombre: "Don Carlos", carro: "Carro verde", placa: "SAN 207", color: "#22c55e" },
  { nombre: "Doña Rosa", carro: "Carro amarillo", placa: "PRE 640", color: "#eab308" },
];

/** Distancia en km (de mentiras) entre dos lugares del mapa. */
export function distanciaKm(a: PlaceId, b: PlaceId): number {
  const pa = getPlace(a);
  const pb = getPlace(b);
  const d = Math.hypot(pa.x - pb.x, pa.y - pb.y);
  return Math.max(1, Math.round(d / 14));
}

/** Tarifa: 3.500 de arranque + 1.000 por km. */
export function tarifa(a: PlaceId, b: PlaceId): number {
  return 3500 + distanciaKm(a, b) * 1000;
}

export function minutos(a: PlaceId, b: PlaceId): number {
  return distanciaKm(a, b) * 3 + 2;
}

/* --------------------------------- Billetera -------------------------------- */

/** Caja registradora de COOPRECOZ: base con la que empieza el turno. */
export const CAJA_INICIAL: number[] = [
  10000, 10000, 5000, 5000, 5000, 2000, 2000, 2000, 2000, 1000, 1000, 1000, 1000, 500, 500, 500,
  500,
];

/** Sencillo que trae el gerente cuando la caja no alcanza para dar el vuelto. */
export const SENCILLO_GERENTE: number[] = [5000, 2000, 2000, 1000, 1000, 1000, 500, 500];

/** ¿Se puede armar exactamente `valor` con los billetes de la caja? */
export function puedeDarVuelto(caja: number[], valor: number): boolean {
  if (valor === 0) return true;
  const paso = 50;
  const meta = Math.round(valor / paso);
  let alcanzables = new Set<number>([0]);
  for (const b of caja) {
    const v = Math.round(b / paso);
    const nuevos = new Set(alcanzables);
    for (const a of alcanzables) if (a + v <= meta) nuevos.add(a + v);
    alcanzables = nuevos;
    if (alcanzables.has(meta)) return true;
  }
  return alcanzables.has(meta);
}

export const BILLETERA_INICIAL: number[] = [
  20000, 20000, 10000, 5000, 5000, 2000, 2000, 1000, 1000, 500, 500,
];

export function totalDe(bills: number[]): number {
  return bills.reduce((a, b) => a + b, 0);
}

/** Agrupa la billetera: [{value, count}] de mayor a menor. */
export function agrupar(bills: number[]): { value: number; count: number }[] {
  const out: { value: number; count: number }[] = [];
  for (const d of COP_DENOMINATIONS) {
    const count = bills.filter((b) => b === d.value).length;
    if (count > 0) out.push({ value: d.value, count });
  }
  return out;
}

/** Billetes y monedas que recibes de vuelto, como lista. */
export function vueltoEnBilletes(value: number): number[] {
  return breakdownCOP(value).flatMap((p) => Array<number>(p.count).fill(p.value));
}

/** Quita de la billetera los billetes entregados. */
export function sacarDeBilletera(bills: number[], entregados: number[]): number[] {
  const rest = [...bills];
  for (const e of entregados) {
    const i = rest.indexOf(e);
    if (i >= 0) rest.splice(i, 1);
  }
  return rest;
}

/**
 * Si entregas de más, devuelve el billete que sobra (para enseñar a no dar de más).
 * Un billete sobra si al quitarlo todavía alcanza para pagar.
 */
export function billeteQueSobra(entregados: number[], precio: number): number | null {
  const pagado = totalDe(entregados);
  const sobra = [...entregados].sort((a, b) => a - b).find((b) => pagado - b >= precio);
  return sobra ?? null;
}

/** 3 opciones de vuelto: la correcta y 2 parecidas. */
export function opcionesVuelto(correcto: number): number[] {
  const set = new Set<number>([correcto]);
  const deltas = [1000, -1000, 500, -500, 2000, -2000, 5000];
  let i = 0;
  while (set.size < 3 && i < 50) {
    const d = deltas[Math.floor(Math.random() * deltas.length)];
    const c = correcto + d;
    if (c >= 0) set.add(c);
    i++;
  }
  return [...set].sort(() => Math.random() - 0.5);
}

/* ---------------------------------- Misiones --------------------------------- */

export const QUIEN_ENCARGA = [
  "Tu mamá te pidió comprar",
  "Tu profe te encargó",
  "En casa hace falta",
  "Tu abuela necesita",
];

/* --------------------------------- Guardado --------------------------------- */

const KEY = "copprecoz_mapa";

export type MapaState = {
  at: PlaceId;
  billetera: number[];
  caja: number[];
  hechos: PlaceId[];
  viajes: number;
  compras: number;
  turnos: number;
};

export const MAPA_INICIAL: MapaState = {
  at: "cooprecoz",
  billetera: BILLETERA_INICIAL,
  caja: CAJA_INICIAL,
  hechos: [],
  viajes: 0,
  compras: 0,
  turnos: 0,
};

export function cargarMapa(): MapaState {
  if (typeof window === "undefined") return MAPA_INICIAL;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) return { ...MAPA_INICIAL, ...(JSON.parse(raw) as Partial<MapaState>) };
  } catch {
    // sin almacenamiento: se empieza de cero
  }
  return MAPA_INICIAL;
}

export function guardarMapa(s: MapaState) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    // ignorar
  }
}

export function fechaRecibo(): string {
  const d = new Date();
  return d.toLocaleDateString("es-CO", { day: "2-digit", month: "2-digit", year: "numeric" });
}
