// Gamificación local-first: XP, niveles, insignias, retos y rachas.
// Funciona sin conexión y se sincroniza con la nube cuando vuelve internet.
import { addXpAndCoins } from "@/lib/module-progress";

const KEY = "copprecoz_game";
const QUEUE_KEY = "copprecoz_sync_queue";
const EVENT = "copprecoz-game";

export type GameState = {
  xp: number;
  coins: number;
  streak: number;
  lastDay: string;
  badges: string[];
  daily: Record<string, number>; // contadores del día
  dailyDay: string;
  weekly: Record<string, number>; // contadores de la semana
  weeklyWeek: string;
};

export const EMPTY: GameState = {
  xp: 0,
  coins: 0,
  streak: 0,
  lastDay: "",
  badges: [],
  daily: {},
  dailyDay: "",
  weekly: {},
  weeklyWeek: "",
};

function today() {
  return new Date().toISOString().slice(0, 10);
}

function weekId() {
  const d = new Date();
  const onejan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil(((d.getTime() - onejan.getTime()) / 86400000 + onejan.getDay() + 1) / 7);
  return `${d.getFullYear()}-S${week}`;
}

export function levelFromXp(xp: number) {
  return Math.floor(xp / 500) + 1;
}

export function xpInLevel(xp: number) {
  return { actual: xp % 500, meta: 500 };
}

export type Badge = {
  id: string;
  name: string;
  desc: string;
  emoji: string;
  check: (s: GameState) => boolean;
};

export const BADGES: Badge[] = [
  { id: "primer-paso", name: "Primer paso", desc: "Completa tu primera actividad", emoji: "🌱", check: (s) => s.xp > 0 },
  { id: "explorador", name: "Explorador del peso", desc: "Llega a 500 XP", emoji: "🔎", check: (s) => s.xp >= 500 },
  { id: "contador", name: "Buen contador", desc: "Llega a 1.500 XP", emoji: "🧮", check: (s) => s.xp >= 1500 },
  { id: "cajero", name: "Persona cajera", desc: "Llega a 3.000 XP", emoji: "🧾", check: (s) => s.xp >= 3000 },
  { id: "ahorrador", name: "Ahorrador", desc: "Junta 5.000 monedas", emoji: "🐷", check: (s) => s.coins >= 5000 },
  { id: "racha-3", name: "Racha de 3 días", desc: "Practica 3 días seguidos", emoji: "🔥", check: (s) => s.streak >= 3 },
  { id: "racha-7", name: "Racha de 7 días", desc: "Practica 7 días seguidos", emoji: "🏆", check: (s) => s.streak >= 7 },
  { id: "viajero", name: "Viajero de la ciudad", desc: "Cumple 4 misiones de compra en el Mapa Precoz", emoji: "🗺️", check: (s) => (s.weekly["mapa"] ?? 0) >= 4 },
  { id: "finanzas", name: "Mente financiera", desc: "Termina 5 temas de educación financiera", emoji: "💡", check: (s) => (s.weekly["finanzas"] ?? 0) >= 5 || (s.daily["finanzas"] ?? 0) >= 5 },
];

export type Challenge = {
  id: string;
  name: string;
  desc: string;
  meta: number;
  reward: number;
  key: string;
};

export const DAILY_CHALLENGES: Challenge[] = [
  { id: "d1", name: "3 actividades hoy", desc: "Completa 3 actividades de cualquier módulo", meta: 3, reward: 200, key: "actividades" },
  { id: "d2", name: "Atiende 2 clientes", desc: "Cobra bien a 2 clientes en el modo cajero", meta: 2, reward: 300, key: "cajero" },
  { id: "d3", name: "Aprende 1 tema", desc: "Lee un tema de educación financiera", meta: 1, reward: 150, key: "finanzas" },
];

export const WEEKLY_CHALLENGES: Challenge[] = [
  { id: "w1", name: "10 actividades esta semana", desc: "Practica un poquito cada día", meta: 10, reward: 800, key: "actividades" },
  { id: "w2", name: "5 vueltos correctos", desc: "Entrega el vuelto exacto 5 veces", meta: 5, reward: 600, key: "vuelto" },
];

export const MENSAJES = [
  "¡Muy bien! Cada vez cuentas mejor.",
  "¡Excelente! Ya sabes usar los pesos.",
  "¡Lo lograste! Sigue así.",
  "¡Buen trabajo! Estás aprendiendo mucho.",
  "¡Genial! Tu alcancía crece.",
];

export function mensajePositivo() {
  return MENSAJES[Math.floor(Math.random() * MENSAJES.length)];
}

export function getGame(): GameState {
  if (typeof window === "undefined") return EMPTY;
  let s: GameState = EMPTY;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) s = { ...EMPTY, ...(JSON.parse(raw) as Partial<GameState>) };
  } catch {
    s = EMPTY;
  }
  if (s.dailyDay !== today()) {
    s = { ...s, daily: {}, dailyDay: today() };
  }
  if (s.weeklyWeek !== weekId()) {
    s = { ...s, weekly: {}, weeklyWeek: weekId() };
  }
  return s;
}

function save(s: GameState) {
  window.localStorage.setItem(KEY, JSON.stringify(s));
  window.dispatchEvent(new Event(EVENT));
}

export function subscribeGame(cb: () => void) {
  if (typeof window === "undefined") return () => {};
  window.addEventListener(EVENT, cb);
  window.addEventListener("online", cb);
  window.addEventListener("offline", cb);
  return () => {
    window.removeEventListener(EVENT, cb);
    window.removeEventListener("online", cb);
    window.removeEventListener("offline", cb);
  };
}

function touchStreak(s: GameState): GameState {
  const hoy = today();
  if (s.lastDay === hoy) return s;
  const ayer = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  return { ...s, streak: s.lastDay === ayer ? s.streak + 1 : 1, lastDay: hoy };
}

/** Registra una actividad terminada: suma XP/monedas, retos, racha e insignias. */
export function recordActivity(opts: {
  xp: number;
  coins: number;
  keys?: string[];
}): { nuevasInsignias: Badge[]; retosLogrados: Challenge[]; state: GameState } {
  let s = touchStreak(getGame());
  s = { ...s, xp: s.xp + opts.xp, coins: s.coins + opts.coins };

  const keys = ["actividades", ...(opts.keys ?? [])];
  const daily = { ...s.daily };
  const weekly = { ...s.weekly };
  for (const k of keys) {
    daily[k] = (daily[k] ?? 0) + 1;
    weekly[k] = (weekly[k] ?? 0) + 1;
  }
  s = { ...s, daily, weekly };

  const retosLogrados = [
    ...DAILY_CHALLENGES.filter((c) => (s.daily[c.key] ?? 0) === c.meta),
    ...WEEKLY_CHALLENGES.filter((c) => (s.weekly[c.key] ?? 0) === c.meta),
  ];
  if (retosLogrados.length) {
    s = { ...s, coins: s.coins + retosLogrados.reduce((a, c) => a + c.reward, 0) };
  }

  const nuevasInsignias = BADGES.filter((b) => !s.badges.includes(b.id) && b.check(s));
  if (nuevasInsignias.length) {
    s = { ...s, badges: [...s.badges, ...nuevasInsignias.map((b) => b.id)] };
  }

  save(s);
  queueSync(opts.xp, opts.coins);
  return { nuevasInsignias, retosLogrados, state: s };
}

export function resetGame() {
  window.localStorage.removeItem(KEY);
  window.dispatchEvent(new Event(EVENT));
}

/** Gasta monedas de la alcancía (para comprar ropa del personaje). */
export function spendCoins(amount: number): boolean {
  const s = getGame();
  if (s.coins < amount) return false;
  save({ ...s, coins: s.coins - amount });
  queueSync(0, -amount);
  return true;
}

/* ------------------------- Sincronización offline ------------------------- */

type PendingItem = { xp: number; coins: number };

function readQueue(): PendingItem[] {
  try {
    return JSON.parse(window.localStorage.getItem(QUEUE_KEY) ?? "[]") as PendingItem[];
  } catch {
    return [];
  }
}

export function pendingCount() {
  if (typeof window === "undefined") return 0;
  return readQueue().length;
}

function queueSync(xp: number, coins: number) {
  const q = [...readQueue(), { xp, coins }];
  window.localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
  window.dispatchEvent(new Event(EVENT));
  void flushSync();
}

export async function flushSync() {
  if (typeof window === "undefined" || !navigator.onLine) return;
  const q = readQueue();
  if (q.length === 0) return;
  window.localStorage.setItem(QUEUE_KEY, "[]");
  try {
    const xp = q.reduce((a, b) => a + b.xp, 0);
    const coins = q.reduce((a, b) => a + b.coins, 0);
    await addXpAndCoins(xp, coins);
    window.dispatchEvent(new Event(EVENT));
  } catch {
    // si falla, se vuelve a encolar para el próximo intento
    window.localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
  }
}
