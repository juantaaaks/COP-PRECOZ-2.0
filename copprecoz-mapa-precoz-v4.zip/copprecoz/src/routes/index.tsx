import { createFileRoute, Link } from "@tanstack/react-router";
import { Coins, Sparkles, ShieldCheck, Ear } from "lucide-react";
import logo from "@/assets/logo.jpg.asset.json";
import { MoneyFormatPicker, ThemeToggle } from "@/components/app-settings";

export const Route = createFileRoute("/")({
  component: Landing,
  head: () => ({
    meta: [
      { title: "COPprecoz — Aprende a usar los pesos colombianos" },
      {
        name: "description",
        content:
          "Plataforma accesible para estudiantes neurodiversos: aprende a reconocer, contar y usar los pesos colombianos (COP) con juegos, simuladores y misiones diarias.",
      },
      { property: "og:title", content: "COPprecoz — Aprende a usar los pesos colombianos" },
      {
        property: "og:description",
        content:
          "Plataforma accesible para estudiantes neurodiversos: aprende a reconocer, contar y usar los pesos colombianos (COP) con juegos, simuladores y misiones diarias.",
      },
    ],
  }),
});

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-3">
          <img
            src={logo.url}
            alt="Logo Cooprecoz"
            className="size-12 rounded-2xl object-contain"
          />
          <div className="text-lg font-extrabold tracking-tight">COPprecoz</div>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link
            to="/auth"
            className="rounded-2xl bg-foreground px-5 py-2.5 text-sm font-bold text-background hover:opacity-90"
          >
            Entrar
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 pt-8 pb-16">
        <div className="mb-10">
          <MoneyFormatPicker />
        </div>
        <section className="grid gap-10 md:grid-cols-2 md:items-center">
          <div className="space-y-6">
            <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary">
              <Sparkles className="size-3.5" /> Diseñado para aprender jugando
            </span>
            <h1 className="text-balance text-4xl font-extrabold leading-tight tracking-tight md:text-5xl">
              Aprende a usar el dinero colombiano, paso a paso.
            </h1>
            <p className="max-w-prose text-lg text-muted-foreground">
              COPprecoz es una plataforma educativa pensada para estudiantes neurodiversos.
              Reconoce monedas y billetes, cuenta, compra y ahorra con actividades claras,
              accesibles y divertidas.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                to="/auth"
                className="rounded-2xl bg-primary px-6 py-4 text-base font-extrabold text-primary-foreground shadow-lg shadow-primary/25 transition-transform hover:scale-[1.02] active:scale-[0.99]"
              >
                Empezar ahora
              </Link>
              <Link
                to="/auth"
                className="rounded-2xl border border-border bg-card px-6 py-4 text-base font-bold text-foreground hover:bg-accent"
              >
                Soy docente o acudiente
              </Link>
            </div>
            <div className="flex flex-wrap gap-6 pt-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <ShieldCheck className="size-4 text-accent-green" /> Cuenta segura
              </div>
              <div className="flex items-center gap-2">
                <Ear className="size-4 text-accent-blue" /> Accesibilidad activa
              </div>
              <div className="flex items-center gap-2">
                <Coins className="size-4 text-primary" /> 100% pesos colombianos
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="animate-slide-up rounded-[2rem] bg-card p-8 shadow-xl ring-1 ring-black/5">
              <div className="mb-6 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                    Misión del día
                  </p>
                  <h3 className="mt-1 text-2xl font-extrabold">Compra el pan</h3>
                </div>
                <span className="rounded-xl bg-accent-blue/10 px-3 py-1 text-xs font-bold text-accent-blue">
                  +25 XP
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { l: "$ 2.000", c: "bg-accent-blue/10 text-accent-blue" },
                  { l: "$ 5.000", c: "bg-accent-green/10 text-accent-green" },
                  { l: "$ 10.000", c: "bg-accent-red/10 text-accent-red" },
                  { l: "$ 20.000", c: "bg-primary/10 text-primary" },
                ].map((b) => (
                  <div
                    key={b.l}
                    className={`rounded-2xl ${b.c} px-4 py-6 text-center font-mono text-lg font-bold`}
                  >
                    {b.l}
                  </div>
                ))}
              </div>
              <div className="mt-6 h-3 w-full overflow-hidden rounded-full bg-muted">
                <div className="h-full w-[70%] rounded-full bg-primary" />
              </div>
              <p className="mt-2 text-right font-mono text-xs text-muted-foreground">
                700 / 1.000 XP
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}