import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, RotateCw, Trash2 } from "lucide-react";
import { COP_DENOMINATIONS, COP_IMAGES, formatCOP } from "@/lib/cop";
import { clearBackImages, setBackImage, useBackImages } from "@/lib/cop-back";

export const Route = createFileRoute("/reversos")({
  component: Reversos,
  head: () => ({
    meta: [
      { title: "Reversos de billetes y monedas | COPprecoz" },
      {
        name: "description",
        content:
          "Panel para cargar las imágenes de la parte de atrás de los billetes y monedas colombianos usados en COPprecoz.",
      },
      { property: "og:title", content: "Reversos de billetes y monedas | COPprecoz" },
      {
        property: "og:description",
        content: "Carga las imágenes del reverso de cada billete y moneda COP.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

function Reversos() {
  const backs = useBackImages();

  return (
    <main className="mx-auto max-w-4xl px-4 py-8">
      <Link
        to="/"
        className="mb-6 inline-flex items-center gap-2 rounded-full bg-card px-4 py-2 font-bold shadow-sm ring-1 ring-black/5"
      >
        <ArrowLeft className="size-5" /> Volver
      </Link>

      <h1 className="text-3xl font-extrabold">Reversos de billetes y monedas</h1>
      <p className="mt-2 text-muted-foreground">
        Sube o pega la URL de la parte de atrás de cada denominación. Al tocar un billete dentro de
        la app, el educando verá el reverso. Las imágenes quedan guardadas en este dispositivo.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {COP_DENOMINATIONS.map((d) => {
          const back = backs[d.value] ?? "";
          return (
            <div key={d.value} className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-black/5">
              <div className="flex items-center justify-between gap-3">
                <span className="font-mono text-lg font-black">{formatCOP(d.value)}</span>
                <span className="text-sm text-muted-foreground">{d.name}</span>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-3">
                <div>
                  <div className="mb-1 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Frente
                  </div>
                  <img
                    src={COP_IMAGES[d.value]}
                    alt={`Frente de ${d.name}`}
                    className="h-24 w-full rounded-xl bg-muted/40 object-contain"
                  />
                </div>
                <div>
                  <div className="mb-1 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Reverso
                  </div>
                  {back ? (
                    <img
                      src={back}
                      alt={`Reverso de ${d.name}`}
                      className="h-24 w-full rounded-xl bg-muted/40 object-contain"
                    />
                  ) : (
                    <div className="grid h-24 w-full place-items-center rounded-xl bg-muted/40 text-sm text-muted-foreground">
                      Sin imagen
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-2">
                <label className="cursor-pointer rounded-2xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground">
                  Subir imagen
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={async (e) => {
                      const f = e.target.files?.[0];
                      if (f) setBackImage(d.value, await readFileAsDataUrl(f));
                      e.target.value = "";
                    }}
                  />
                </label>
                {back && (
                  <button
                    onClick={() => setBackImage(d.value, "")}
                    className="inline-flex items-center gap-1 rounded-2xl bg-muted px-4 py-2 text-sm font-bold"
                  >
                    <Trash2 className="size-4" /> Quitar
                  </button>
                )}
              </div>

              <input
                type="url"
                defaultValue={back.startsWith("data:") ? "" : back}
                placeholder="…o pega una URL de imagen"
                onBlur={(e) => setBackImage(d.value, e.target.value)}
                className="mt-2 w-full rounded-2xl bg-muted/50 px-4 py-2 text-sm ring-1 ring-black/5"
              />
            </div>
          );
        })}
      </div>

      <button
        onClick={clearBackImages}
        className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-muted px-5 py-3 font-bold"
      >
        <RotateCw className="size-5" /> Borrar todos los reversos
      </button>
    </main>
  );
}
