import { createFileRoute, Link, useNavigate, notFound } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Volume2,
  Check,
  X,
  RotateCcw,
  Sparkles,
  Trophy,
  ShoppingBasket,
} from "lucide-react";
import { toast } from "sonner";
import { COP_DENOMINATIONS, COP_FACTS, formatCOP, type Denomination } from "@/lib/cop";
import {
  BillPicker,
  ChangeHelper,
  Confetti,
  DenomVisual,
  MoneyBreakdown,
  ProgressBar,
  Section,
  speak,
} from "@/components/money-ui";
import { PrecozGame } from "@/components/precoz-game";
import { CajeroGame } from "@/components/cajero-game";
import { FinanzasGame } from "@/components/finanzas-game";
import { SettingsButton } from "@/components/settings-sheet";
import logo from "@/assets/logo.jpg.asset.json";
import { saveModuleProgress, subscribeModuleProgress } from "@/lib/module-progress";
import { supabase } from "@/integrations/supabase/client";
import { recordActivity, mensajePositivo } from "@/lib/gamification";

// Suma XP/monedas, retos e insignias en un solo lugar.
function celebrar(xp: number, coins: number, keys: string[]) {
  const { nuevasInsignias } = recordActivity({ xp, coins, keys });
  toast.success(mensajePositivo());
  nuevasInsignias.forEach((b) => toast.success(`${b.emoji} Nueva insignia: ${b.name}`));
}

type Slug = "conocer" | "contar" | "precoz" | "cajero" | "tienda" | "finanzas" | "recibo";
const VALID: Slug[] = ["conocer", "contar", "precoz", "cajero", "tienda", "finanzas", "recibo"];

const TITLES: Record<Slug, { title: string; desc: string }> = {
  conocer: { title: "Conozco el dinero", desc: "Reconoce cada billete y moneda" },
  contar: { title: "Cuento el dinero", desc: "Suma monedas y billetes" },
  precoz: {
    title: "Calculadora Precoz",
    desc: "Vende hummus y limonada cerezada, cobra y devuelve el vuelto",
  },
  cajero: {
    title: "Soy la persona cajera",
    desc: "Atiende clientes, cobra el pedido y entrega el vuelto",
  },
  tienda: { title: "Simulador de tienda", desc: "Compra y paga con COP" },
  finanzas: {
    title: "Cuido mi dinero",
    desc: "Ahorro, presupuesto, necesidades y formas de pago",
  },
  recibo: {
    title: "Leo mi recibo",
    desc: "Aprende a leer el recibo de compra paso a paso",
  },
};

// (los módulos se renderizan según el slug más abajo)

export const Route = createFileRoute("/_authenticated/modulo/$slug")({
  beforeLoad: ({ params }) => {
    if (!VALID.includes(params.slug as Slug)) throw notFound();
  },
  component: ModulePage,
  head: ({ params }) => {
    const t = TITLES[params.slug as Slug];
    return {
      meta: [
        { title: `${t?.title ?? "Módulo"} — COPprecoz` },
        { name: "description", content: t?.desc ?? "" },
      ],
    };
  },
});

function useModulePercent(slug: string) {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    let alive = true;
    void supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: row } = await supabase
        .from("module_progress")
        .select("percent")
        .eq("user_id", data.user.id)
        .eq("module_slug", slug)
        .maybeSingle();
      if (alive && row) setPct((p) => Math.max(p, row.percent ?? 0));
    });
    const off = subscribeModuleProgress((s, p) => {
      if (s === slug) setPct(p);
    });
    return () => {
      alive = false;
      off();
    };
  }, [slug]);
  return pct;
}

function ModulePage() {
  const { slug } = Route.useParams();
  const t = TITLES[slug as Slug];
  const pct = useModulePercent(slug);

  return (
    <div className="min-h-screen text-foreground">
      <header className="sticky top-0 z-20 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-3 py-3 sm:gap-4 sm:px-5">
          <Link
            to="/panel"
            aria-label="Volver al panel"
            className="grid size-12 shrink-0 place-items-center rounded-full border border-border bg-card shadow-sm transition hover:bg-muted active:scale-95 sm:size-14"
          >
            <ArrowLeft className="size-6" />
          </Link>
          <div className="flex min-w-0 flex-1 items-center justify-center gap-3">
            <img
              src={logo.url}
              alt="Logo Cooprecoz"
              className="size-11 shrink-0 rounded-full object-contain ring-2 ring-card sm:size-12"
            />
            <div className="min-w-0">
              <div className="text-xs font-extrabold uppercase tracking-[0.2em] text-primary">
                Módulo
              </div>
              <h1 className="truncate font-display text-xl font-extrabold leading-tight sm:text-2xl">
                {t.title}
              </h1>
            </div>
          </div>
          <div className="shrink-0 [&_button]:rounded-full">
            <SettingsButton />
          </div>
        </div>
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 pb-2 sm:px-5">
          <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-accent-green transition-all duration-500"
              style={{ width: `${pct}%` }}
            />
          </div>
          <span className="font-mono text-sm font-black text-muted-foreground">{pct}%</span>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-3 py-5 pb-24 sm:px-5 sm:py-7 sm:pb-28">
        {slug === "conocer" && <ConocerGame />}
        {slug === "contar" && <ContarGame />}
        {slug === "precoz" && <PrecozGame />}
        {slug === "cajero" && <CajeroGame />}
        {slug === "tienda" && <TiendaGame />}
        {slug === "finanzas" && <FinanzasGame />}
        {slug === "recibo" && <ReciboGame />}
      </main>
    </div>
  );
}

/* ---------------------------- 1) Conocer ---------------------------- */

function ConocerGame() {
  // De menor a mayor: se empieza por las monedas pequeñas.
  const cards = useMemo(() => [...COP_DENOMINATIONS].sort((a, b) => a.value - b.value), []);
  const [i, setI] = useState(0);
  const [seen, setSeen] = useState<Set<number>>(new Set());
  const [celebrate, setCelebrate] = useState(false);
  const card = cards[i];
  const fact = COP_FACTS[card.value];

  useEffect(() => {
    setSeen((s) => new Set(s).add(i));
  }, [i]);

  const percent = Math.round((seen.size / cards.length) * 100);

  useEffect(() => {
    saveModuleProgress("conocer", percent);
    if (percent === 100) {
      celebrar(120, 500, ["conocer"]);
      setCelebrate(true);
      const t = setTimeout(() => setCelebrate(false), 1800);
      return () => clearTimeout(t);
    }
  }, [percent]);

  return (
    <div className="space-y-6">
      <Confetti show={celebrate} />
      <div>
        <div className="mb-2 flex justify-between text-sm font-bold text-muted-foreground">
          <span>
            Tarjeta {i + 1} de {cards.length}
          </span>
          <span>{percent}%</span>
        </div>
        <ProgressBar value={percent} />
      </div>

      <div className="overflow-hidden rounded-3xl bg-card shadow-playful ring-1 ring-border">
        <div className="relative grid place-items-center bg-mod-conocer-soft px-4 py-8 sm:py-10">
          <span className="absolute left-4 top-4 rounded-full bg-card px-3 py-1 text-xs font-extrabold uppercase tracking-widest text-mod-conocer">
            Ficha {i + 1}
          </span>
          <DenomVisual d={card} size="lg" />
        </div>
        <div className="p-5 text-center sm:p-7">
          <div className="text-lg font-bold text-muted-foreground">
            {card.type === "billete" ? "Billete" : "Moneda"} de {card.value.toLocaleString("es-CO")}{" "}
            pesos
          </div>
          <div className="mt-1 font-mono text-6xl font-black leading-none text-primary sm:text-7xl">
            {formatCOP(card.value)}
          </div>
          <div className="mt-2 text-xl font-extrabold">{card.name}</div>

          {fact && (
            <div className="mt-5 grid gap-3 text-left sm:grid-cols-3">
              {[
                { icon: "🎨", label: "Color", text: fact.color },
                { icon: "🧑", label: "Personaje", text: fact.quien },
                { icon: "💡", label: "Pista", text: fact.pista },
              ].map((f) => (
                <div key={f.label} className="rounded-2xl surface-soft p-4 ring-1 ring-border">
                  <div className="text-3xl">{f.icon}</div>
                  <div className="mt-1 text-xs font-extrabold uppercase tracking-widest text-muted-foreground">
                    {f.label}
                  </div>
                  <div className="text-base font-bold leading-snug">{f.text}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>


      <div className="grid grid-cols-[1fr_auto_1fr] gap-3">
        <button
          onClick={() => setI((n) => Math.max(0, n - 1))}
          disabled={i === 0}
          className="min-h-16 rounded-2xl border-2 border-border bg-card text-xl font-bold transition active:scale-95 disabled:opacity-40"
        >
          ← Anterior
        </button>
        <button
          onClick={() =>
            speak(
              fact
                ? `${card.type === "billete" ? "Billete" : "Moneda"} de ${card.name}. Es de color ${fact.color}. Tiene a ${fact.quien}. ${fact.pista}`
                : card.name,
            )
          }
          aria-label="Escuchar las pistas"
          className="grid size-16 place-items-center rounded-full bg-accent-blue/15 text-accent-blue transition active:scale-95"
        >
          <Volume2 className="size-8" />
        </button>
        <button
          onClick={() => setI((n) => Math.min(cards.length - 1, n + 1))}
          disabled={i === cards.length - 1}
          className="min-h-16 rounded-2xl bg-primary text-xl font-extrabold text-primary-foreground shadow-playful transition active:scale-95 disabled:opacity-40"
        >
          Siguiente →
        </button>
      </div>
    </div>
  );
}

/* ---------------------------- 2) Contar ---------------------------- */

type ContarRound = { items: Denomination[]; total: number; options: number[] };

function makeContarRound(level: number): ContarRound {
  const pool = COP_DENOMINATIONS.filter((d) => (level < 3 ? d.value <= 5000 : d.value <= 50000));
  const count = 2 + Math.min(3, level);
  const items: Denomination[] = [];
  for (let i = 0; i < count; i++) {
    items.push(pool[Math.floor(Math.random() * pool.length)]);
  }
  const total = items.reduce((a, b) => a + b.value, 0);
  const distractors = new Set<number>([total]);
  while (distractors.size < 4) {
    const delta = [-2000, -1000, -500, 500, 1000, 2000][Math.floor(Math.random() * 6)];
    const candidate = Math.max(50, total + delta);
    distractors.add(candidate);
  }
  const options = Array.from(distractors).sort(() => Math.random() - 0.5);
  return { items, total, options };
}

function ContarGame() {
  const [level, setLevel] = useState(1);
  const [round, setRound] = useState<ContarRound>(() => makeContarRound(1));
  const [correct, setCorrect] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [feedback, setFeedback] = useState<"ok" | "no" | null>(null);
  const target = 5;
  const percent = Math.min(100, Math.round((correct / target) * 100));
  const done = correct >= target;

  useEffect(() => {
    saveModuleProgress("contar", percent);
    if (done) {
      celebrar(150, 800, ["contar"]);
    }
  }, [percent, done]);

  function pick(opt: number) {
    if (feedback) return;
    if (opt === round.total) {
      setFeedback("ok");
      setCorrect((c) => c + 1);
      setTimeout(() => {
        setFeedback(null);
        setLevel((l) => l + 1);
        setRound(makeContarRound(level + 1));
      }, 900);
    } else {
      setFeedback("no");
      setWrong((w) => w + 1);
      setTimeout(() => setFeedback(null), 900);
    }
  }

  function reset() {
    setCorrect(0);
    setWrong(0);
    setLevel(1);
    setRound(makeContarRound(1));
  }

  return (
    <div className="space-y-6">
      <div>
        <div className="mb-2 flex justify-between text-sm font-bold text-muted-foreground">
          <span>
            {correct} / {target} correctas
          </span>
          <span>{wrong} errores</span>
        </div>
        <ProgressBar value={percent} />
      </div>

      {done ? (
        <div className="rounded-3xl bg-primary p-8 text-center text-primary-foreground shadow-lg">
          <Trophy className="mx-auto size-12" />
          <h2 className="mt-3 text-2xl font-extrabold">¡Completaste el reto!</h2>
          <p className="mt-1 opacity-90">Ganaste 150 XP y 500 monedas.</p>
          <button
            onClick={reset}
            className="mt-4 rounded-2xl bg-background px-5 py-3 font-extrabold text-foreground"
          >
            <RotateCcw className="mr-2 inline size-4" /> Jugar otra vez
          </button>
        </div>
      ) : (
        <>
          <div className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-black/5">
            <div className="text-center text-xl font-extrabold text-foreground">
              ¿Cuánto dinero hay?
            </div>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-4">
              {round.items.map((it, idx) => (
                <DenomVisual key={idx} d={it} size="sm" />
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {round.options.map((opt) => {
              const isCorrectPick = feedback === "ok" && opt === round.total;
              const isWrongPick = feedback === "no" && opt !== round.total;
              return (
                <button
                  key={opt}
                  onClick={() => pick(opt)}
                  className={`rounded-3xl p-7 text-center font-mono text-3xl font-black shadow-sm ring-1 ring-black/5 transition ${
                    isCorrectPick
                      ? "bg-accent-green text-white"
                      : isWrongPick
                        ? "bg-accent-red/20 text-accent-red"
                        : "bg-card hover:-translate-y-0.5 hover:shadow"
                  }`}
                >
                  {formatCOP(opt)}
                </button>
              );
            })}
          </div>

          {feedback === "ok" && (
            <div className="flex items-center justify-center gap-2 text-lg font-extrabold text-accent-green">
              <Check className="size-6" /> ¡Correcto!
            </div>
          )}
          {feedback === "no" && (
            <div className="flex items-center justify-center gap-2 text-lg font-extrabold text-accent-red">
              <X className="size-6" /> Intenta otra vez
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ---------------------------- 4) Tienda ---------------------------- */

const PRODUCTS = [
  { name: "Pan", emoji: "🥖", price: 1500 },
  { name: "Leche", emoji: "🥛", price: 4200 },
  { name: "Arroz", emoji: "🍚", price: 3800 },
  { name: "Manzana", emoji: "🍎", price: 900 },
  { name: "Cuaderno", emoji: "📓", price: 6500 },
  { name: "Jugo", emoji: "🧃", price: 2700 },
  { name: "Huevos", emoji: "🥚", price: 5400 },
  { name: "Queso", emoji: "🧀", price: 7300 },
  { name: "Banano", emoji: "🍌", price: 1200 },
] as const;

type Product = (typeof PRODUCTS)[number];

const ENCARGOS = [
  "Tu mamá te mandó a comprar",
  "Tu profe te pidió traer",
  "Tu papá te mandó a la tienda por",
  "En casa necesitan",
];

function makeLista() {
  const shuffled = [...PRODUCTS].sort(() => Math.random() - 0.5);
  const n = 2 + Math.floor(Math.random() * 2);
  return {
    quien: ENCARGOS[Math.floor(Math.random() * ENCARGOS.length)],
    items: shuffled.slice(0, n),
  };
}

function TiendaGame() {
  const [lista, setLista] = useState(makeLista);
  const [cesta, setCesta] = useState<Product[]>([]);
  const [wallet, setWallet] = useState<number[]>([]);
  const [rounds, setRounds] = useState(0);

  const target = 3;
  const percent = Math.min(100, Math.round((rounds / target) * 100));
  const listaCompleta = lista.items.every((it) => cesta.some((c) => c.name === it.name));
  const sobra = cesta.filter((c) => !lista.items.some((it) => it.name === c.name));
  const precioLista = cesta.reduce((a, b) => a + b.price, 0);
  const total = wallet.reduce((a, b) => a + b, 0);
  const enough = total >= precioLista && precioLista > 0;
  const change = total - precioLista;

  useEffect(() => {
    saveModuleProgress("tienda", percent);
  }, [percent]);

  function toggle(p: Product) {
    setCesta((c) =>
      c.some((x) => x.name === p.name) ? c.filter((x) => x.name !== p.name) : [...c, p],
    );
    speak(`${p.name}, ${p.price.toLocaleString("es-CO")} pesos`);
  }

  function pay() {
    if (!listaCompleta) {
      toast.error("Aún faltan productos de la lista");
      return;
    }
    if (sobra.length > 0) {
      toast.error(`${sobra[0].name} no está en la lista. Quítalo de la cesta.`);
      return;
    }
    if (!enough) {
      toast.error(`Te faltan ${formatCOP(precioLista - total)}`);
      return;
    }
    toast.success(
      change === 0
        ? "¡Pago exacto! Excelente."
        : `Pagaste ${formatCOP(total)}. Recibes ${formatCOP(change)} de vuelto.`,
    );
    const next = rounds + 1;
    setRounds(next);
    if (next >= target) celebrar(180, 1000, ["tienda", "vuelto"]);
    setTimeout(() => {
      setWallet([]);
      setCesta([]);
      setLista(makeLista());
    }, 900);
  }

  return (
    <div className="space-y-6">
      <div>
        <div className="mb-2 flex justify-between text-sm font-bold text-muted-foreground">
          <span>
            Compras: {rounds} / {target}
          </span>
          <span>{percent}%</span>
        </div>
        <ProgressBar value={percent} />
      </div>

      <div className="rounded-3xl bg-primary p-6 text-primary-foreground shadow-lg shadow-primary/20">
        <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest opacity-90">
          <ShoppingBasket className="size-5" /> Lista de compras
        </div>
        <h2 className="mt-1 text-2xl font-extrabold">{lista.quien}:</h2>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {lista.items.map((it) => {
            const done = cesta.some((c) => c.name === it.name);
            return (
              <li
                key={it.name}
                className={`flex items-center gap-3 rounded-2xl px-4 py-3 ${
                  done ? "bg-background/90 text-foreground" : "bg-white/15"
                }`}
              >
                <span className="text-4xl">{it.emoji}</span>
                <span className="flex-1 text-xl font-extrabold">{it.name}</span>
                {done && <Check className="size-7 text-accent-green" />}
              </li>
            );
          })}
        </ul>
        <button
          onClick={() => speak(`${lista.quien}: ${lista.items.map((i) => i.name).join(", ")}`)}
          className="mt-4 flex items-center gap-2 rounded-2xl bg-background px-5 py-3 text-lg font-extrabold text-foreground"
        >
          <Volume2 className="size-6" /> Escuchar la lista
        </button>
      </div>

      <Section title="Estante de la tienda" hint="Escoge tú los productos">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {PRODUCTS.map((p) => {
            const picked = cesta.some((c) => c.name === p.name);
            return (
              <button
                key={p.name}
                onClick={() => toggle(p)}
                className={`flex flex-col items-center gap-1 rounded-2xl p-4 ring-1 transition active:scale-95 ${
                  picked
                    ? "bg-accent-green/15 ring-accent-green/40"
                    : "bg-muted/40 ring-black/5 hover:bg-muted"
                }`}
              >
                <span className="text-6xl">{p.emoji}</span>
                <span className="text-lg font-extrabold">{p.name}</span>
                <span className="font-mono text-xl font-black text-primary">
                  {formatCOP(p.price)}
                </span>
              </button>
            );
          })}
        </div>
      </Section>

      <Section title="Mi cesta" hint={`${cesta.length} productos`}>
        {cesta.length === 0 ? (
          <p className="text-center text-base font-bold text-muted-foreground">
            Toca los productos de la lista para ponerlos en la cesta
          </p>
        ) : (
          <>
            <div className="flex flex-wrap gap-2">
              {cesta.map((c) => (
                <span
                  key={c.name}
                  className={`rounded-2xl px-4 py-2 text-lg font-bold ${
                    lista.items.some((i) => i.name === c.name)
                      ? "bg-accent-green/15 text-accent-green"
                      : "bg-accent-red/10 text-accent-red"
                  }`}
                >
                  {c.emoji} {c.name}
                </span>
              ))}
            </div>
            <div className="mt-4 flex items-baseline justify-between">
              <span className="text-lg font-bold text-muted-foreground">Total de la cesta</span>
              <span className="font-mono text-4xl font-black text-primary">
                {formatCOP(precioLista)}
              </span>
            </div>
          </>
        )}
      </Section>

      <Section title="Toca para pagar" hint={`${wallet.length} en la mano`}>
        <div className="mb-4 flex justify-end">
          <button
            onClick={() => setWallet((w) => w.slice(0, -1))}
            disabled={wallet.length === 0}
            className="rounded-xl bg-accent-red/10 px-4 py-2 text-base font-bold text-accent-red disabled:opacity-40"
          >
            Quitar último
          </button>
        </div>
        <BillPicker
          picks={wallet}
          onPick={(v) => {
            setWallet((w) => [...w, v]);
            speak(`${v.toLocaleString("es-CO")} pesos`);
          }}
        />
      </Section>

      <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
        <div className="flex items-baseline justify-between">
          <span className="text-lg font-bold text-muted-foreground">Vas pagando</span>
          <span
            className={`font-mono text-4xl font-black ${enough ? "text-accent-green" : "text-foreground"}`}
          >
            {formatCOP(total)}
          </span>
        </div>
        {wallet.length > 0 && (
          <div className="mt-4 rounded-2xl bg-muted/40 p-4">
            <MoneyBreakdown value={total} />
          </div>
        )}
        {enough && change > 0 && (
          <div className="mt-4">
            <ChangeHelper value={change} />
          </div>
        )}
        {!enough && precioLista > 0 && (
          <div className="mt-3 rounded-2xl bg-accent-yellow/20 p-4 text-center text-lg font-extrabold">
            Te faltan {formatCOP(precioLista - total)}
          </div>
        )}
        {enough && change === 0 && (
          <div className="mt-3 rounded-2xl bg-accent-green/15 p-4 text-center text-lg font-extrabold text-accent-green">
            ¡Pago exacto! 🎉
          </div>
        )}
        <button
          onClick={pay}
          className="mt-5 w-full rounded-2xl bg-primary py-6 text-2xl font-black text-primary-foreground shadow-lg shadow-primary/20 disabled:opacity-50"
          disabled={wallet.length === 0}
        >
          <Sparkles className="mr-2 inline size-7" /> Pagar
        </button>
      </div>

      {rounds >= target && (
        <div className="rounded-3xl bg-accent-green/10 p-5 text-center font-bold text-accent-green">
          ¡Terminaste el reto de la tienda! Ganaste 180 XP y 1.000 monedas.
        </div>
      )}
    </div>
  );
}

/* ---------------------------- 5) Recibo ---------------------------- */

type ReciboPaso =
  | { tipo: "leccion"; titulo: string; parrafos: string[] }
  | {
      tipo: "partes";
      titulo: string;
      partes: { icono: string; nombre: string; texto: string }[];
    }
  | { tipo: "ejemplo"; titulo: string }
  | {
      tipo: "quiz";
      pregunta: string;
      opciones: { texto: string; ok: boolean }[];
    };

const RECIBO_PASOS: ReciboPaso[] = [
  {
    tipo: "leccion",
    titulo: "¿Qué es un recibo?",
    parrafos: [
      "Cuando compras algo en la tienda o en el supermercado, la persona de la caja te entrega un papel.",
      "Ese papel se llama recibo (o factura).",
      "El recibo es tu prueba de que ya pagaste por tus productos. Es tuyo y debes guardarlo.",
    ],
  },
  {
    tipo: "partes",
    titulo: "Las 4 partes más importantes de un recibo",
    partes: [
      {
        icono: "🏪",
        nombre: "¿Dónde compraste?",
        texto: "Es el nombre de la tienda. Aparece siempre en la parte de arriba del papel.",
      },
      {
        icono: "🛒",
        nombre: "¿Qué compraste?",
        texto: "Es la lista de productos. Muestra el nombre de cada objeto o alimento que llevas.",
      },
      {
        icono: "💰",
        nombre: "¿Cuánto pagaste en total?",
        texto: "Es el Total: el número más grande y más importante. Es la suma final de todo lo que compraste.",
      },
      {
        icono: "💳",
        nombre: "¿Cómo pagaste?",
        texto: "Es la forma de pago. Dice si entregaste billetes y monedas (efectivo) o si usaste tarjeta.",
      },
    ],
  },
  { tipo: "ejemplo", titulo: "Ejemplo sencillo de un recibo" },
  {
    tipo: "quiz",
    pregunta: "¿En qué parte del recibo ves el dinero total que tuviste que pagar?",
    opciones: [
      { texto: "En la parte del Total", ok: true },
      { texto: "En el nombre de la tienda", ok: false },
    ],
  },
  {
    tipo: "quiz",
    pregunta: "Si compras un jugo y una galleta, ¿para qué te sirve guardar el recibo?",
    opciones: [
      { texto: "Para mostrar que ya los pagaste", ok: true },
      { texto: "Para usarlo como un dibujo", ok: false },
    ],
  },
];

function textoDelPaso(p: ReciboPaso): string {
  if (p.tipo === "leccion") return `${p.titulo}. ${p.parrafos.join(" ")}`;
  if (p.tipo === "partes")
    return `${p.titulo}. ${p.partes.map((x) => `${x.nombre}: ${x.texto}`).join(" ")}`;
  if (p.tipo === "ejemplo")
    return "Ejemplo de un recibo. Supermercado El Sol. Un jugo de fruta, 2.000 pesos. Una galleta, 1.000 pesos. Total a pagar: 3.000 pesos. Pago con efectivo.";
  return `${p.pregunta} ${p.opciones.map((o, i) => `Opción ${i + 1}: ${o.texto}.`).join(" ")}`;
}

function ReciboGame() {
  const [paso, setPaso] = useState(0);
  const [respondidas, setRespondidas] = useState<Set<number>>(new Set());
  const [fallo, setFallo] = useState<number | null>(null);
  const actual = RECIBO_PASOS[paso];
  const total = RECIBO_PASOS.length;
  const esUltimo = paso === total - 1;
  const quizResuelto = actual.tipo !== "quiz" || respondidas.has(paso);
  const completado = esUltimo && quizResuelto;
  const percent = Math.min(100, Math.round(((paso + (quizResuelto ? 1 : 0)) / total) * 100));

  useEffect(() => {
    saveModuleProgress("recibo", percent);
    if (completado) celebrar(120, 500, ["recibo"]);
  }, [percent, completado]);

  function responder(ok: boolean) {
    if (!ok) {
      setFallo(paso);
      toast.error("Intenta otra vez, tú puedes 💪");
      return;
    }
    setFallo(null);
    setRespondidas((s) => new Set(s).add(paso));
    toast.success(mensajePositivo());
  }

  return (
    <div className="space-y-6">
      <div>
        <div className="mb-2 flex justify-between text-sm font-bold text-muted-foreground">
          <span>
            Paso {paso + 1} de {total}
          </span>
          <span>{percent}%</span>
        </div>
        <ProgressBar value={percent} />
      </div>

      <div className="overflow-hidden rounded-3xl bg-card shadow-playful ring-1 ring-border">
        <div className="flex items-center justify-between gap-3 bg-mod-recibo-soft px-5 py-4">
          <h2 className="font-display text-xl font-extrabold text-mod-recibo sm:text-2xl">
            {actual.tipo === "quiz" ? "Pregunta para practicar" : actual.titulo}
          </h2>
          <button
            onClick={() => speak(textoDelPaso(actual))}
            aria-label="Escuchar este paso"
            className="grid size-14 shrink-0 place-items-center rounded-full bg-accent-blue/15 text-accent-blue transition active:scale-95"
          >
            <Volume2 className="size-7" />
          </button>
        </div>

        <div className="p-5 sm:p-7">
          {actual.tipo === "leccion" && (
            <div className="space-y-4">
              <div className="text-center text-6xl">🧾</div>
              {actual.parrafos.map((t) => (
                <p key={t} className="rounded-2xl surface-soft p-4 text-lg font-bold leading-snug ring-1 ring-border">
                  {t}
                </p>
              ))}
            </div>
          )}

          {actual.tipo === "partes" && (
            <div className="grid gap-3 sm:grid-cols-2">
              {actual.partes.map((p, i) => (
                <div key={p.nombre} className="rounded-2xl surface-soft p-4 ring-1 ring-border">
                  <div className="flex items-center gap-2">
                    <span className="text-3xl">{p.icono}</span>
                    <span className="rounded-full bg-mod-recibo-soft px-3 py-1 text-xs font-extrabold uppercase tracking-widest text-mod-recibo">
                      Parte {i + 1}
                    </span>
                  </div>
                  <div className="mt-2 text-lg font-extrabold">{p.nombre}</div>
                  <div className="mt-1 text-base font-bold leading-snug text-muted-foreground">
                    {p.texto}
                  </div>
                </div>
              ))}
            </div>
          )}

          {actual.tipo === "ejemplo" && (
            <div className="mx-auto max-w-sm rounded-2xl bg-muted/50 p-5 font-mono shadow-inner ring-1 ring-border">
              <div className="border-b-2 border-dashed border-border pb-3 text-center">
                <div className="text-xl font-black">Supermercado El Sol</div>
                <div className="text-xs font-bold text-muted-foreground">🏪 Nombre de la tienda</div>
              </div>
              <div className="space-y-2 border-b-2 border-dashed border-border py-3 text-lg font-bold">
                <div className="flex justify-between">
                  <span>1 Jugo de fruta</span>
                  <span>{formatCOP(2000)}</span>
                </div>
                <div className="flex justify-between">
                  <span>1 Galleta</span>
                  <span>{formatCOP(1000)}</span>
                </div>
                <div className="text-xs font-bold text-muted-foreground">🛒 Lista de productos</div>
              </div>
              <div className="flex items-baseline justify-between pt-3">
                <span className="text-sm font-black uppercase tracking-widest">Total a pagar</span>
                <span className="text-3xl font-black text-mod-recibo">{formatCOP(3000)}</span>
              </div>
              <div className="text-xs font-bold text-muted-foreground">💰 El número más importante</div>
              <div className="mt-3 rounded-xl bg-mod-recibo-soft px-3 py-2 text-center text-base font-black text-mod-recibo">
                💳 Pago con: Efectivo
              </div>
            </div>
          )}

          {actual.tipo === "quiz" && (
            <div className="space-y-4">
              <p className="text-center text-xl font-extrabold leading-snug">{actual.pregunta}</p>
              <div className="grid gap-3">
                {actual.opciones.map((o) => {
                  const acertada = respondidas.has(paso) && o.ok;
                  return (
                    <button
                      key={o.texto}
                      onClick={() => !respondidas.has(paso) && responder(o.ok)}
                      className={`rounded-2xl p-5 text-left text-lg font-extrabold ring-1 transition active:scale-[0.98] ${
                        acertada
                          ? "bg-accent-green/15 text-accent-green ring-accent-green/40"
                          : fallo === paso && !o.ok
                            ? "bg-accent-red/10 ring-accent-red/30"
                            : "bg-muted/40 ring-border hover:bg-muted"
                      }`}
                    >
                      {acertada && <Check className="mr-2 inline size-6" />}
                      {o.texto}
                    </button>
                  );
                })}
              </div>
              {respondidas.has(paso) && (
                <div className="flex items-center justify-center gap-2 text-lg font-extrabold text-accent-green">
                  <Check className="size-6" /> ¡Correcto!
                </div>
              )}
              {fallo === paso && !respondidas.has(paso) && (
                <div className="text-center text-lg font-extrabold text-accent-red">
                  Intenta otra vez
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-[1fr_auto_1fr] gap-3">
        <button
          onClick={() => setPaso((n) => Math.max(0, n - 1))}
          disabled={paso === 0}
          className="min-h-16 rounded-2xl border-2 border-border bg-card text-xl font-bold transition active:scale-95 disabled:opacity-40"
        >
          ← Anterior
        </button>
        <button
          onClick={() => speak(textoDelPaso(actual))}
          aria-label="Escuchar"
          className="grid size-16 place-items-center rounded-full bg-accent-blue/15 text-accent-blue transition active:scale-95"
        >
          <Volume2 className="size-8" />
        </button>
        <button
          onClick={() => setPaso((n) => Math.min(total - 1, n + 1))}
          disabled={esUltimo || !quizResuelto}
          className="min-h-16 rounded-2xl bg-primary text-xl font-extrabold text-primary-foreground shadow-playful transition active:scale-95 disabled:opacity-40"
        >
          Siguiente →
        </button>
      </div>

      {completado && (
        <div className="rounded-3xl bg-primary p-8 text-center text-primary-foreground shadow-lg">
          <Trophy className="mx-auto size-12" />
          <h2 className="mt-3 text-2xl font-extrabold">¡Ya sabes leer un recibo!</h2>
          <p className="mt-1 opacity-90">Ganaste 120 XP y 500 monedas.</p>
        </div>
      )}
    </div>
  );
}
