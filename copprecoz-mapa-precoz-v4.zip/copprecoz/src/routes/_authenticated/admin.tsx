import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Check, Crown, FileSpreadsheet, Trash2, X } from "lucide-react";
import logo from "@/assets/logo.jpg.asset.json";
import { SettingsButton } from "@/components/settings-sheet";
import { formatCOP } from "@/lib/cop";
import { listarArqueosEquipo, type Arqueo } from "@/lib/arqueo";
import { exportarExcel } from "@/lib/arqueo-export";
import { listarVentasEquipo, resumenDelDia, type Venta } from "@/lib/ventas";
import {
  agregarDueño,
  cambiarEstado,
  cargarMiEquipo,
  listarDueños,
  listarEquipo,
  quitarDueño,
  quitarIntegrante,
  type Integrante,
} from "@/lib/team";

export const Route = createFileRoute("/_authenticated/admin")({
  component: PanelLider,
  head: () => ({
    meta: [
      { title: "Panel del maestro líder — COPprecoz" },
      {
        name: "description",
        content:
          "Administra las cuentas del equipo Cooprecoz, revisa los arqueos y las ventas de la cooperativa escolar.",
      },
      { property: "og:title", content: "Panel del maestro líder — COPprecoz" },
      {
        property: "og:description",
        content: "Aprueba integrantes, agrega líderes y revisa arqueos y ventas de la cooperativa.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function fecha(iso: string) {
  return new Date(iso).toLocaleString("es-CO", { dateStyle: "medium", timeStyle: "short" });
}

function PanelLider() {
  const [esDueño, setEsDueño] = useState<boolean | null>(null);
  const [equipo, setEquipo] = useState<Integrante[]>([]);
  const [dueños, setDueños] = useState<string[]>([]);
  const [arqueos, setArqueos] = useState<Arqueo[]>([]);
  const [ventas, setVentas] = useState<Venta[]>([]);
  const [nuevoLider, setNuevoLider] = useState("");
  const [aviso, setAviso] = useState("");

  async function recargar() {
    const [e, d, a, v] = await Promise.all([
      listarEquipo(),
      listarDueños(),
      listarArqueosEquipo(),
      listarVentasEquipo(),
    ]);
    setEquipo(e);
    setDueños(d);
    setArqueos(a);
    setVentas(v);
  }

  useEffect(() => {
    void cargarMiEquipo().then((mi) => {
      setEsDueño(mi.esDueño);
      if (mi.esDueño) void recargar();
    });
  }, []);

  const hoy = resumenDelDia(ventas);

  if (esDueño === false) {
    return (
      <div className="grid min-h-screen place-items-center bg-background px-6 text-center">
        <div className="max-w-md space-y-4 rounded-3xl bg-card p-8 shadow-sm ring-2 ring-primary/20">
          <Crown className="mx-auto size-12 text-primary" />
          <h1 className="text-2xl font-extrabold">Solo para el maestro líder</h1>
          <p className="text-lg text-muted-foreground">
            Esta página es para el maestro líder o el gerente de la cooperativa.
          </p>
          <Link
            to="/cooprecoz"
            className="inline-block rounded-2xl bg-primary px-6 py-3 text-lg font-extrabold text-primary-foreground"
          >
            Volver al inicio del equipo
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b border-border/60 bg-card/90 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-3">
          <Link
            to="/cooprecoz"
            className="grid size-11 place-items-center rounded-2xl border border-border"
            aria-label="Volver al inicio del equipo"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <img src={logo.url} alt="Logo Cooprecoz" className="size-10 rounded-2xl object-contain" />
          <h1 className="flex-1 text-lg font-extrabold sm:text-xl">Panel del maestro líder</h1>
          <SettingsButton />
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-5 px-4 py-6 pb-24">
        {aviso && (
          <p className="rounded-2xl bg-accent-yellow/20 px-4 py-3 text-base font-bold">{aviso}</p>
        )}

        {/* Resumen */}
        <section className="grid grid-cols-3 gap-3 text-center">
          <div className="rounded-3xl bg-card p-4 shadow-sm">
            <div className="text-xs font-bold uppercase text-muted-foreground">Ventas hoy</div>
            <div className="font-mono text-3xl font-black">{hoy.cantidad}</div>
          </div>
          <div className="rounded-3xl bg-card p-4 shadow-sm">
            <div className="text-xs font-bold uppercase text-muted-foreground">Se vendió</div>
            <div className="font-mono text-2xl font-black text-accent-green">
              {formatCOP(hoy.vendido)}
            </div>
          </div>
          <div className="rounded-3xl bg-card p-4 shadow-sm">
            <div className="text-xs font-bold uppercase text-muted-foreground">Arqueos</div>
            <div className="font-mono text-3xl font-black">{arqueos.length}</div>
          </div>
        </section>

        {/* Cuentas del equipo */}
        <section className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-primary/20">
          <h2 className="text-xl font-extrabold">Cuentas del equipo</h2>
          <p className="text-sm text-muted-foreground">Aprueba, rechaza o quita integrantes.</p>
          <ul className="mt-4 space-y-3">
            {equipo.length === 0 && (
              <li className="text-muted-foreground">Todavía nadie ha pedido acceso.</li>
            )}
            {equipo.map((m) => (
              <li
                key={m.id}
                className="flex flex-wrap items-center gap-3 rounded-2xl bg-muted/40 p-4"
              >
                <div className="min-w-0 flex-1">
                  <div className="truncate text-lg font-extrabold">{m.full_name || m.email}</div>
                  <div className="truncate text-sm text-muted-foreground">
                    {m.email} · {m.cargo} · {m.status}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      await cambiarEstado(m.id, "aprobado");
                      setAviso(`${m.full_name || m.email} ya tiene acceso.`);
                      void recargar();
                    }}
                    className="grid size-11 place-items-center rounded-2xl bg-accent-green/15 text-accent-green"
                    aria-label={`Aprobar a ${m.full_name || m.email}`}
                  >
                    <Check className="size-5" />
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await cambiarEstado(m.id, "rechazado");
                      setAviso(`Se rechazó a ${m.full_name || m.email}.`);
                      void recargar();
                    }}
                    className="grid size-11 place-items-center rounded-2xl bg-accent-yellow/25 text-foreground"
                    aria-label={`Rechazar a ${m.full_name || m.email}`}
                  >
                    <X className="size-5" />
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await quitarIntegrante(m.id);
                      void recargar();
                    }}
                    className="grid size-11 place-items-center rounded-2xl bg-accent-red/15 text-accent-red"
                    aria-label={`Quitar a ${m.full_name || m.email}`}
                  >
                    <Trash2 className="size-5" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </section>

        {/* Líderes */}
        <section className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-accent-blue/30">
          <h2 className="text-xl font-extrabold">Maestros líderes y gerentes</h2>
          <p className="text-sm text-muted-foreground">
            Estos correos pueden entrar a este panel y aprobar cuentas.
          </p>
          <form
            className="mt-4 flex flex-wrap gap-3"
            onSubmit={async (ev) => {
              ev.preventDefault();
              try {
                await agregarDueño(nuevoLider);
                setNuevoLider("");
                setAviso("Correo agregado como líder.");
                void recargar();
              } catch (err) {
                setAviso(err instanceof Error ? err.message : "No se pudo agregar.");
              }
            }}
          >
            <input
              value={nuevoLider}
              onChange={(e) => setNuevoLider(e.target.value)}
              placeholder="correo@gmail.com"
              aria-label="Correo del nuevo líder"
              className="min-w-52 flex-1 rounded-2xl border-2 border-border bg-background px-4 py-3 text-lg"
            />
            <button
              type="submit"
              className="rounded-2xl bg-primary px-6 py-3 text-lg font-extrabold text-primary-foreground"
            >
              Agregar
            </button>
          </form>
          <ul className="mt-4 space-y-2">
            {dueños.map((e) => (
              <li key={e} className="flex items-center gap-3 rounded-2xl bg-muted/40 p-3">
                <Crown className="size-5 text-primary" />
                <span className="min-w-0 flex-1 truncate text-lg font-bold">{e}</span>
                <button
                  type="button"
                  onClick={async () => {
                    await quitarDueño(e);
                    void recargar();
                  }}
                  className="grid size-10 place-items-center rounded-2xl bg-accent-red/15 text-accent-red"
                  aria-label={`Quitar líder ${e}`}
                >
                  <Trash2 className="size-4" />
                </button>
              </li>
            ))}
          </ul>
        </section>

        {/* Arqueos */}
        <section className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-accent-green/30">
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="flex-1 text-xl font-extrabold">Arqueos de la cooperativa</h2>
            <button
              type="button"
              onClick={() => void exportarExcel(arqueos)}
              className="flex items-center gap-2 rounded-2xl bg-accent-green/15 px-4 py-2 text-base font-extrabold text-accent-green"
            >
              <FileSpreadsheet className="size-5" /> Excel
            </button>
          </div>
          <ul className="mt-4 space-y-2">
            {arqueos.length === 0 && (
              <li className="text-muted-foreground">Todavía no hay arqueos guardados.</li>
            )}
            {arqueos.slice(0, 15).map((a) => (
              <li key={a.id} className="flex items-center gap-3 rounded-2xl bg-muted/40 p-3">
                <div className="min-w-0 flex-1">
                  <div className="truncate font-bold">{a.cashier_name || "Sin nombre"}</div>
                  <div className="text-sm text-muted-foreground">{fecha(a.counted_at)}</div>
                </div>
                <div className="font-mono text-xl font-black">{formatCOP(a.total)}</div>
              </li>
            ))}
          </ul>
        </section>

        {/* Ventas */}
        <section className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-accent-yellow/40">
          <h2 className="text-xl font-extrabold">Últimas ventas</h2>
          <ul className="mt-4 space-y-2">
            {ventas.length === 0 && (
              <li className="text-muted-foreground">Todavía no hay ventas registradas.</li>
            )}
            {ventas.slice(0, 15).map((v) => (
              <li key={v.id} className="flex items-center gap-3 rounded-2xl bg-muted/40 p-3">
                <div className="min-w-0 flex-1">
                  <div className="truncate font-bold">{v.seller_name || "Sin nombre"}</div>
                  <div className="text-sm text-muted-foreground">{fecha(v.sold_at)}</div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-lg font-black text-accent-green">
                    {formatCOP(v.total)}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    vuelto {formatCOP(v.change_given)}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}
