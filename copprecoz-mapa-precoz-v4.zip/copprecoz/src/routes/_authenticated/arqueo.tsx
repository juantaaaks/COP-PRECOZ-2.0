import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Calculator,
  Check,
  ChevronDown,
  FileDown,
  FileSpreadsheet,
  FileText,
  History,
  Minus,
  Plus,
  Save,
  Trash2,
  WifiOff,
} from "lucide-react";
import { toast } from "sonner";
import { COP_DENOMINATIONS, formatCOP } from "@/lib/cop";
import { exportarCSV, exportarExcel, exportarPDF } from "@/lib/arqueo-export";
import { listarVentas, resumenDelDia, type ResumenDia } from "@/lib/ventas";
import { PageHeader } from "@/components/page-header";
import { supabase } from "@/integrations/supabase/client";
import { isGuest } from "@/lib/guest";
import { MoneyImage, speak } from "@/components/money-ui";
import { TeamGate } from "@/components/team-gate";
import {
  clearDraft,
  eliminarArqueo,
  getDraft,
  guardarArqueo,
  listarArqueos,
  saveDraft,
  sincronizar,
  totales,
  type Arqueo,
  type Conteo,
} from "@/lib/arqueo";

export const Route = createFileRoute("/_authenticated/arqueo")({
  component: ArqueoPage,
  head: () => ({
    meta: [
      { title: "Arqueo de caja — COPprecoz" },
      {
        name: "description",
        content:
          "Cuenta el dinero de la cooperativa escolar por denominación, guarda el arqueo y consulta el historial.",
      },
      { property: "og:title", content: "Arqueo de caja — COPprecoz" },
      {
        property: "og:description",
        content: "Conteo de caja en pesos colombianos, fácil y accesible.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function fecha(iso: string) {
  return new Date(iso).toLocaleString("es-CO", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

function ArqueoPage() {
  const [tab, setTab] = useState<"conteo" | "historial">("conteo");
  const [conteo, setConteo] = useState<Conteo>({});
  const [notas, setNotas] = useState("");
  const [nombre, setNombre] = useState("");
  const [historial, setHistorial] = useState<Arqueo[]>([]);
  const [buscaFecha, setBuscaFecha] = useState("");
  const [buscaUsuario, setBuscaUsuario] = useState("");
  const [borrar, setBorrar] = useState<Arqueo | null>(null);
  const [abierto, setAbierto] = useState<string | null>(null);
  const [online, setOnline] = useState(true);
  const [resumen, setResumen] = useState<ResumenDia | null>(null);

  const t = useMemo(() => totales(conteo), [conteo]);

  useEffect(() => {
    setConteo(getDraft());
    setOnline(navigator.onLine);
    const on = () => setOnline(navigator.onLine);
    window.addEventListener("online", on);
    window.addEventListener("offline", on);
    (async () => {
      if (isGuest()) {
        setNombre("Invitado/a");
      } else {
        const { data } = await supabase.auth.getUser();
        const uid = data.user?.id;
        if (uid) {
          const { data: p } = await supabase
            .from("profiles")
            .select("full_name")
            .eq("id", uid)
            .maybeSingle();
          setNombre(p?.full_name || data.user?.email?.split("@")[0] || "Cajero/a");
        }
        await sincronizar();
      }
      setHistorial(await listarArqueos());
      if (!isGuest()) setResumen(resumenDelDia(await listarVentas()));
    })();
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", on);
    };
  }, []);

  function cambiar(value: number, cantidad: number) {
    const n = Math.max(0, Math.min(9999, Math.floor(cantidad || 0)));
    const next = { ...conteo, [value]: n };
    setConteo(next);
    saveDraft(next);
  }

  async function guardar() {
    if (t.total === 0) {
      toast.error("Primero cuenta el dinero de la caja.");
      return;
    }
    await guardarArqueo({
      cashier_name: nombre || "Cajero/a",
      denominations: conteo,
      notes: notas,
    });
    toast.success(`Arqueo guardado: ${formatCOP(t.total)}`);
    speak(`Arqueo guardado. El total en caja es ${t.total} pesos`);
    setConteo({});
    setNotas("");
    clearDraft();
    setHistorial(await listarArqueos());
    setTab("historial");
  }

  async function confirmarBorrado() {
    if (!borrar) return;
    await eliminarArqueo(borrar.id);
    setBorrar(null);
    setHistorial(await listarArqueos());
    toast.success("Arqueo eliminado");
  }

  const filtrado = historial.filter((a) => {
    const okFecha = !buscaFecha || a.counted_at.slice(0, 10) === buscaFecha;
    const okUser =
      !buscaUsuario || a.cashier_name.toLowerCase().includes(buscaUsuario.toLowerCase());
    return okFecha && okUser;
  });
  const anterior = filtrado[1];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <PageHeader
        eyebrow="Cooperativa"
        title="Arqueo de caja"
        extra={
          !online ? (
            <span className="flex items-center gap-1 rounded-xl bg-accent-yellow/25 px-3 py-2 text-sm font-bold text-primary">
              <WifiOff className="size-4" /> Sin conexión
            </span>
          ) : null
        }
      />

      <main className="mx-auto max-w-4xl space-y-5 px-3 py-6 pb-40 sm:px-5">
        <TeamGate titulo="Arqueo de caja">
          <div>
            <h1 className="text-2xl font-extrabold sm:text-3xl">Arqueo de caja</h1>
            <p className="text-base text-muted-foreground">
              Cuenta el dinero de la cooperativa y guarda el registro.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 rounded-3xl bg-muted p-2">
            <button
              onClick={() => setTab("conteo")}
              className={`flex items-center justify-center gap-2 rounded-2xl py-3 text-lg font-extrabold ${tab === "conteo" ? "bg-card shadow ring-1 ring-black/5" : "text-muted-foreground"}`}
            >
              <Calculator className="size-5" /> Conteo
            </button>
            <button
              onClick={() => setTab("historial")}
              className={`flex items-center justify-center gap-2 rounded-2xl py-3 text-lg font-extrabold ${tab === "historial" ? "bg-card shadow ring-1 ring-black/5" : "text-muted-foreground"}`}
            >
              <History className="size-5" /> Historial
            </button>
          </div>

          {tab === "conteo" ? (
            <>
              {resumen && resumen.cantidad > 0 && (
                <div className="rounded-3xl bg-card p-5 shadow-sm ring-2 ring-accent-green/30">
                  <div className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
                    Ventas de hoy en Calculadora Precoz
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-2 text-center">
                    <div>
                      <div className="text-xs font-bold text-muted-foreground">Ventas</div>
                      <div className="font-mono text-2xl font-black">{resumen.cantidad}</div>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-muted-foreground">Se vendió</div>
                      <div className="font-mono text-2xl font-black text-accent-green">
                        {formatCOP(resumen.vendido)}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-muted-foreground">Se devolvió</div>
                      <div className="font-mono text-2xl font-black text-accent-red">
                        {formatCOP(resumen.devuelto)}
                      </div>
                    </div>
                  </div>
                  <p className="mt-3 text-base text-muted-foreground">
                    En la caja debería haber al menos lo vendido hoy. Ahora llevas contado{" "}
                    <b className="text-foreground">{formatCOP(t.total)}</b>
                    {t.total > 0 && (
                      <>
                        {" "}
                        (
                        {t.total >= resumen.vendido
                          ? "alcanza"
                          : `faltan ${formatCOP(resumen.vendido - t.total)}`}
                        )
                      </>
                    )}
                    .
                  </p>
                  <button
                    onClick={() => {
                      setNotas(
                        `Ventas del día: ${resumen.cantidad} · Vendido ${formatCOP(resumen.vendido)} · Devuelto en vueltos ${formatCOP(resumen.devuelto)}`,
                      );
                      toast.success("Ventas del día agregadas a las observaciones");
                    }}
                    className="mt-3 w-full rounded-2xl bg-accent-green/15 py-4 text-lg font-extrabold text-accent-green active:scale-95"
                  >
                    Arquear con las ventas de hoy (opcional)
                  </button>
                </div>
              )}

              <div className="space-y-3">
                {COP_DENOMINATIONS.map((d) => {
                  const n = conteo[d.value] ?? 0;
                  const sub = n * d.value;
                  return (
                    <div
                      key={d.value}
                      className="flex flex-wrap items-center gap-3 rounded-3xl bg-card p-4 shadow-sm ring-1 ring-black/5"
                    >
                      <MoneyImage
                        value={d.value}
                        alt={d.name}
                        className={`${d.type === "billete" ? "h-24 w-40" : "size-20"} shrink-0 rounded-lg object-contain`}
                      />
                      <div className="min-w-24 flex-1">
                        <div className="font-mono text-xl font-black">
                          ${d.value.toLocaleString("es-CO")}
                        </div>
                        <div className="text-sm capitalize text-muted-foreground">{d.type}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => cambiar(d.value, n - 1)}
                          aria-label={`Quitar uno de ${d.name}`}
                          className="grid size-12 place-items-center rounded-2xl bg-muted text-foreground active:scale-95"
                        >
                          <Minus className="size-6" />
                        </button>
                        <input
                          type="number"
                          inputMode="numeric"
                          min={0}
                          value={n === 0 ? "" : n}
                          placeholder="0"
                          onChange={(e) => cambiar(d.value, Number(e.target.value))}
                          aria-label={`Cantidad de ${d.name}`}
                          className="w-20 rounded-2xl border-2 border-border bg-background py-2 text-center font-mono text-xl font-black"
                        />
                        <button
                          onClick={() => cambiar(d.value, n + 1)}
                          aria-label={`Agregar uno de ${d.name}`}
                          className="grid size-12 place-items-center rounded-2xl bg-primary text-primary-foreground active:scale-95"
                        >
                          <Plus className="size-6" />
                        </button>
                      </div>
                      <div className="w-full text-right font-mono text-lg font-black text-primary sm:w-32">
                        {formatCOP(sub)}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
                <label className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
                  Observaciones (opcional)
                </label>
                <textarea
                  value={notas}
                  onChange={(e) => setNotas(e.target.value)}
                  rows={3}
                  placeholder="Ejemplo: faltó una moneda de 500"
                  className="mt-2 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 text-lg"
                />
                <div className="mt-3 text-base text-muted-foreground">
                  Cajero/a: <span className="font-extrabold text-foreground">{nombre || "…"}</span>
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-4">
              <div className="grid gap-3 rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5 sm:grid-cols-2">
                <div>
                  <label className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
                    Buscar por fecha
                  </label>
                  <input
                    type="date"
                    value={buscaFecha}
                    onChange={(e) => setBuscaFecha(e.target.value)}
                    className="mt-2 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 text-lg"
                  />
                </div>
                <div>
                  <label className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
                    Buscar por cajero/a
                  </label>
                  <input
                    value={buscaUsuario}
                    onChange={(e) => setBuscaUsuario(e.target.value)}
                    placeholder="Nombre"
                    className="mt-2 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 text-lg"
                  />
                </div>
              </div>

              {filtrado.length === 0 && (
                <p className="rounded-3xl bg-card p-6 text-center text-lg font-bold text-muted-foreground ring-1 ring-black/5">
                  Todavía no hay arqueos guardados.
                </p>
              )}

              {filtrado.length > 0 && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <button
                    onClick={() => {
                      exportarCSV(filtrado);
                      toast.success("Archivo CSV descargado");
                    }}
                    className="flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-accent-green/15 px-4 text-lg font-extrabold text-accent-green ring-1 ring-accent-green/30 active:scale-95"
                  >
                    <FileDown className="size-6" /> Exportar a CSV
                  </button>
                  <button
                    onClick={async () => {
                      await exportarExcel(filtrado);
                      toast.success("Excel descargado (editable)");
                    }}
                    className="flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-accent-blue/15 px-4 text-lg font-extrabold text-accent-blue ring-1 ring-accent-blue/30 active:scale-95"
                  >
                    <FileSpreadsheet className="size-6" /> Exportar a Excel
                  </button>
                  <button
                    onClick={() => {
                      const ok = exportarPDF(filtrado);
                      if (!ok) toast.error("Permite las ventanas emergentes para crear el PDF");
                    }}
                    className="flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-accent-red/10 px-4 text-lg font-extrabold text-accent-red ring-1 ring-accent-red/30 active:scale-95"
                  >
                    <FileText className="size-6" /> Exportar a PDF
                  </button>
                </div>
              )}

              {filtrado.map((a, i) => {
                const dif = anterior && i === 0 ? a.total - anterior.total : null;
                return (
                  <div key={a.id} className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <div className="text-lg font-extrabold">{fecha(a.counted_at)}</div>
                        <div className="text-base text-muted-foreground">{a.cashier_name}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono text-2xl font-black text-primary">
                          {formatCOP(a.total)}
                        </div>
                        {a.pendiente && (
                          <div className="text-sm font-bold text-muted-foreground">
                            Se guardará al volver internet
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-3">
                      <div className="rounded-2xl bg-muted/50 p-3">
                        <div className="text-sm font-bold uppercase tracking-widest text-muted-foreground">
                          Monedas
                        </div>
                        <div className="font-mono text-lg font-black">
                          {formatCOP(a.coins_total)}
                        </div>
                      </div>
                      <div className="rounded-2xl bg-muted/50 p-3">
                        <div className="text-sm font-bold uppercase tracking-widest text-muted-foreground">
                          Billetes
                        </div>
                        <div className="font-mono text-lg font-black">
                          {formatCOP(a.bills_total)}
                        </div>
                      </div>
                    </div>
                    {dif !== null && (
                      <div className="mt-3 rounded-2xl bg-accent-blue/10 p-3 text-base font-bold text-accent-blue">
                        {dif === 0
                          ? "Igual que el arqueo anterior"
                          : dif > 0
                            ? `${formatCOP(dif)} más que el arqueo anterior`
                            : `${formatCOP(Math.abs(dif))} menos que el arqueo anterior`}
                      </div>
                    )}
                    {a.notes && <p className="mt-3 text-base text-muted-foreground">{a.notes}</p>}

                    <button
                      onClick={() => setAbierto(abierto === a.id ? null : a.id)}
                      className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-muted/60 px-4 py-3 text-lg font-extrabold active:scale-95"
                    >
                      <ChevronDown
                        className={`size-5 transition ${abierto === a.id ? "rotate-180" : ""}`}
                      />
                      {abierto === a.id ? "Ocultar el detalle" : "Ver billetes y monedas"}
                    </button>

                    {abierto === a.id && (
                      <div className="mt-3 space-y-2">
                        {COP_DENOMINATIONS.filter((d) => (a.denominations?.[d.value] ?? 0) > 0).map(
                          (d) => {
                            const n = a.denominations[d.value] ?? 0;
                            return (
                              <div
                                key={d.value}
                                className="flex items-center gap-3 rounded-2xl bg-muted/40 p-3"
                              >
                                <MoneyImage
                                  value={d.value}
                                  alt={d.name}
                                  className={`${d.type === "billete" ? "h-20 w-32" : "size-16"} shrink-0 rounded-lg object-contain`}
                                />
                                <div className="min-w-0 flex-1">
                                  <div className="font-mono text-lg font-black">
                                    {formatCOP(d.value)}
                                  </div>
                                  <div className="text-sm capitalize text-muted-foreground">
                                    {d.type}
                                  </div>
                                </div>
                                <div className="font-mono text-xl font-black">×{n}</div>
                                <div className="w-28 text-right font-mono text-lg font-black text-primary">
                                  {formatCOP(n * d.value)}
                                </div>
                              </div>
                            );
                          },
                        )}
                        {COP_DENOMINATIONS.every((d) => !(a.denominations?.[d.value] ?? 0)) && (
                          <p className="text-base text-muted-foreground">
                            Este arqueo no tiene detalle guardado.
                          </p>
                        )}
                      </div>
                    )}

                    <button
                      onClick={() => setBorrar(a)}
                      className="mt-4 flex items-center gap-2 rounded-2xl bg-accent-red/10 px-4 py-3 font-bold text-accent-red"
                    >
                      <Trash2 className="size-5" /> Eliminar
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </TeamGate>
      </main>

      {tab === "conteo" && (
        <div className="fixed inset-x-0 bottom-0 border-t border-border bg-background/95 backdrop-blur">
          <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-3 px-3 py-4 sm:px-5">
            <div>
              <div className="text-sm font-bold uppercase tracking-widest text-muted-foreground">
                Total en caja
              </div>
              <div className="font-mono text-3xl font-black text-primary">{formatCOP(t.total)}</div>
              <div className="text-sm text-muted-foreground">
                Monedas {formatCOP(t.monedas)} · Billetes {formatCOP(t.billetes)}
              </div>
            </div>
            <button
              onClick={guardar}
              className="flex items-center gap-2 rounded-2xl bg-primary px-6 py-4 text-lg font-extrabold text-primary-foreground shadow active:scale-95"
            >
              <Save className="size-6" /> Guardar arqueo
            </button>
          </div>
        </div>
      )}

      {borrar && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-3xl bg-card p-6 shadow-2xl">
            <h2 className="text-xl font-extrabold">¿Eliminar este arqueo?</h2>
            <p className="mt-2 text-base text-muted-foreground">
              {fecha(borrar.counted_at)} · {formatCOP(borrar.total)}. Esta acción no se puede
              deshacer.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <button
                onClick={() => setBorrar(null)}
                className="rounded-2xl bg-muted py-4 text-lg font-extrabold"
              >
                Cancelar
              </button>
              <button
                onClick={confirmarBorrado}
                className="flex items-center justify-center gap-2 rounded-2xl bg-accent-red py-4 text-lg font-extrabold text-white"
              >
                <Check className="size-5" /> Sí, eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
