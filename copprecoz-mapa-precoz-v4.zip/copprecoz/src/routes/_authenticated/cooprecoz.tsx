import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Calculator, ClipboardList, ShieldCheck, Store, Sparkles } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { formatCOP } from "@/lib/cop";
import { cargarMiEquipo, equipoCache, type MiEquipo } from "@/lib/team";
import { listarVentas, resumenDelDia, type ResumenDia } from "@/lib/ventas";

export const Route = createFileRoute("/_authenticated/cooprecoz")({
  component: InicioEquipo,
  head: () => ({
    meta: [
      { title: "Inicio del equipo Cooprecoz — COPprecoz" },
      {
        name: "description",
        content:
          "Acceso directo del equipo Cooprecoz a la Calculadora Precoz, el Arqueo de caja y las ventas del día.",
      },
      { property: "og:title", content: "Inicio del equipo Cooprecoz — COPprecoz" },
      {
        property: "og:description",
        content: "Vende, registra y cuadra la caja de la cooperativa escolar en un solo lugar.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function InicioEquipo() {
  const [mi, setMi] = useState<MiEquipo | null>(null);
  const [resumen, setResumen] = useState<ResumenDia | null>(null);

  useEffect(() => {
    setMi(equipoCache());
    void cargarMiEquipo().then(async (e) => {
      setMi(e);
      setResumen(resumenDelDia(await listarVentas()));
    });
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <PageHeader eyebrow="Cooperativa" title="Inicio del equipo" width="max-w-3xl" />

      <main className="mx-auto max-w-3xl space-y-5 px-4 py-6 pb-24">
        <section className="rounded-3xl bg-card p-6 shadow-sm ring-2 ring-primary/20">
          <div className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
            Hola de nuevo
          </div>
          <div className="text-2xl font-extrabold">
            {mi?.solicitud?.full_name || mi?.email || "Integrante Cooprecoz"}
          </div>
          <p className="mt-1 text-lg text-muted-foreground">
            {mi?.esDueño
              ? "Eres maestro líder o gerente de la cooperativa."
              : mi?.aprobado
                ? "Tienes acceso completo a las herramientas de caja."
                : "Pide acceso para guardar ventas y arquear la caja."}
          </p>
        </section>

        {resumen && (
          <section className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-accent-green/30">
            <h2 className="text-xl font-extrabold">Hoy en la cooperativa</h2>
            <div className="mt-3 grid grid-cols-3 gap-3 text-center">
              <div className="rounded-2xl bg-muted/40 p-3">
                <div className="text-xs font-bold uppercase text-muted-foreground">Ventas</div>
                <div className="font-mono text-3xl font-black">{resumen.cantidad}</div>
              </div>
              <div className="rounded-2xl bg-muted/40 p-3">
                <div className="text-xs font-bold uppercase text-muted-foreground">Se vendió</div>
                <div className="font-mono text-2xl font-black text-accent-green">
                  {formatCOP(resumen.vendido)}
                </div>
              </div>
              <div className="rounded-2xl bg-muted/40 p-3">
                <div className="text-xs font-bold uppercase text-muted-foreground">Vueltos</div>
                <div className="font-mono text-2xl font-black text-accent-red">
                  {formatCOP(resumen.devuelto)}
                </div>
              </div>
            </div>
          </section>
        )}

        <section className="grid gap-4 sm:grid-cols-2">
          <Link
            to="/mapa"
            className="flex items-center gap-4 rounded-3xl bg-primary p-5 text-primary-foreground shadow-playful transition hover:-translate-y-1 sm:col-span-2"
          >
            <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-background/95 text-4xl">
              🗺️
            </div>
            <div className="min-w-0">
              <div className="text-lg font-extrabold">Mapa Precoz</div>
              <div className="text-sm opacity-90">
                Trabaja aquí, pide un carro y compra en la ciudad
              </div>
            </div>
          </Link>
          <Link
            to="/modulo/$slug"
            params={{ slug: "precoz" }}
            className="flex items-center gap-4 rounded-3xl bg-card p-5 shadow-sm ring-2 ring-accent-yellow/40 transition hover:-translate-y-1 hover:shadow-xl"
          >
            <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-accent-yellow/25 text-primary">
              <Calculator className="size-7" />
            </div>
            <div className="min-w-0">
              <div className="text-lg font-extrabold">Calculadora Precoz</div>
              <div className="text-sm text-muted-foreground">Vende, cobra y entrega el vuelto</div>
            </div>
          </Link>
          <Link
            to="/arqueo"
            className="flex items-center gap-4 rounded-3xl bg-card p-5 shadow-sm ring-2 ring-accent-green/30 transition hover:-translate-y-1 hover:shadow-xl"
          >
            <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-accent-green/10 text-accent-green">
              <ClipboardList className="size-7" />
            </div>
            <div className="min-w-0">
              <div className="text-lg font-extrabold">Arqueo de caja</div>
              <div className="text-sm text-muted-foreground">
                Cuenta el dinero y guarda el registro
              </div>
            </div>
          </Link>
          <Link
            to="/equipo"
            className="flex items-center gap-4 rounded-3xl bg-card p-5 shadow-sm ring-1 ring-primary/20 transition hover:-translate-y-1 hover:shadow-xl"
          >
            <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary">
              <ShieldCheck className="size-7" />
            </div>
            <div className="min-w-0">
              <div className="text-lg font-extrabold">Mi acceso</div>
              <div className="text-sm text-muted-foreground">Estado de tu cuenta en el equipo</div>
            </div>
          </Link>
          {mi?.esDueño ? (
            <Link
              to="/admin"
              className="flex items-center gap-4 rounded-3xl bg-card p-5 shadow-sm ring-2 ring-accent-blue/30 transition hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-accent-blue/10 text-accent-blue">
                <Sparkles className="size-7" />
              </div>
              <div className="min-w-0">
                <div className="text-lg font-extrabold">Panel del maestro líder</div>
                <div className="text-sm text-muted-foreground">Cuentas, arqueos y datos</div>
              </div>
            </Link>
          ) : (
            <Link
              to="/modulo/$slug"
              params={{ slug: "tienda" }}
              className="flex items-center gap-4 rounded-3xl bg-card p-5 shadow-sm ring-1 ring-accent-red/30 transition hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-accent-red/10 text-accent-red">
                <Store className="size-7" />
              </div>
              <div className="min-w-0">
                <div className="text-lg font-extrabold">Practicar en la tienda</div>
                <div className="text-sm text-muted-foreground">Entrena antes de atender</div>
              </div>
            </Link>
          )}
        </section>
      </main>
    </div>
  );
}
