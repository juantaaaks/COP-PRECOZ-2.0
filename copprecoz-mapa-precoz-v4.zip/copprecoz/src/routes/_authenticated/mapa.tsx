import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Check, RotateCcw } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { AvatarView, useAvatar } from "@/components/avatar-view";
import { BilleteraResumen } from "@/components/mapa-ui";
import { ViajeUber, type FaseViaje } from "@/components/mapa-viaje";
import { MisionLugar } from "@/components/mapa-lugar";
import { TrabajoCooprecoz } from "@/components/mapa-cooprecoz";
import { speak } from "@/components/money-ui";
import { formatCOP } from "@/lib/cop";
import logo from "@/assets/logo.jpg.asset.json";
import {
  MAPA_INICIAL,
  PLACES,
  cargarMapa,
  getPlace,
  guardarMapa,
  sacarDeBilletera,
  tarifa,
  vueltoEnBilletes,
  type MapaState,
  type PlaceId,
} from "@/lib/mapa";
import { saveModuleProgress } from "@/lib/module-progress";
import { recordActivity } from "@/lib/gamification";

export const Route = createFileRoute("/_authenticated/mapa")({
  component: MapaPrecoz,
  head: () => ({
    meta: [
      { title: "Mapa Precoz — COPprecoz" },
      {
        name: "description",
        content:
          "Recorre la ciudad desde COOPRECOZ: trabaja, viaja en carro y compra en la droguería, la papelería, el mercado y la plaza usando todo lo que aprendiste.",
      },
    ],
  }),
});

type Vista =
  { tipo: "mapa" } | { tipo: "viaje"; destino: PlaceId; fase: FaseViaje } | { tipo: "lugar" };

function MapaPrecoz() {
  const [s, setS] = useState<MapaState>(MAPA_INICIAL);
  const [vista, setVista] = useState<Vista>({ tipo: "mapa" });
  const [cargado, setCargado] = useState(false);

  useEffect(() => {
    setS(cargarMapa());
    setCargado(true);
  }, []);

  useEffect(() => {
    if (cargado) guardarMapa(s);
  }, [s, cargado]);

  // Al entrar a un lugar o volver al mapa, empezar desde arriba.
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [vista.tipo]);

  const aqui = getPlace(s.at);
  const enViaje = vista.tipo === "viaje";
  const carroMoviendo =
    enViaje && (vista.fase === "enCamino" || vista.fase === "pagar" || vista.fase === "vuelto");

  function pagar(entregados: number[]) {
    setS((x) => ({ ...x, billetera: sacarDeBilletera(x.billetera, entregados) }));
  }
  function recibir(valor: number) {
    if (valor <= 0) return;
    setS((x) => ({ ...x, billetera: [...x.billetera, ...vueltoEnBilletes(valor)] }));
  }
  function marcarHecho(id: PlaceId) {
    setS((x) => {
      const hechos = x.hechos.includes(id) ? x.hechos : [...x.hechos, id];
      void saveModuleProgress("mapa", Math.round((hechos.length / PLACES.length) * 100));
      return { ...x, hechos };
    });
  }

  function elegirDestino(id: PlaceId) {
    if (vista.tipo === "viaje" && vista.fase !== "cotizar") return;
    if (id === s.at) {
      setVista({ tipo: "lugar" });
      return;
    }
    setVista({ tipo: "viaje", destino: id, fase: "cotizar" });
    speak(`¿Quieres ir a ${getPlace(id).name}?`);
  }

  function reiniciar() {
    setS(MAPA_INICIAL);
    setVista({ tipo: "mapa" });
    toast.success("Empezaste de nuevo en COOPRECOZ");
  }

  const destino = vista.tipo === "viaje" ? getPlace(vista.destino) : null;
  const carro = carroMoviendo && destino ? destino : aqui;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <PageHeader eyebrow="Usa todo lo que aprendiste" title="Mapa Precoz" width="max-w-3xl" />

      <main className="mx-auto max-w-3xl space-y-5 px-4 py-5 pb-24">
        {vista.tipo !== "lugar" && (
          <>
            <section className="relative mx-auto aspect-square w-full max-w-xl overflow-hidden rounded-4xl bg-[oklch(0.93_0.06_140)] shadow-sm ring-1 ring-border dark:bg-[oklch(0.32_0.05_140)]">
              <MapaFondo />
              {PLACES.map((p) => (
                <Edificio
                  key={p.id}
                  id={p.id}
                  aqui={s.at === p.id}
                  hecho={s.hechos.includes(p.id)}
                  elegido={destino?.id === p.id}
                  onClick={() => elegirDestino(p.id)}
                />
              ))}
              <Carro
                x={carro.x}
                y={carro.y}
                visible={enViaje && vista.fase !== "cotizar" && vista.fase !== "buscando"}
              />
              {!enViaje && <Yo x={aqui.x} y={aqui.y} />}
            </section>

            {vista.tipo === "mapa" && (
              <>
                <div className="rounded-3xl bg-card p-4 text-center shadow-sm ring-1 ring-border/70">
                  <div className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
                    Estás en
                  </div>
                  <div className="text-2xl font-black">
                    {aqui.emoji} {aqui.name}
                  </div>
                  <button
                    onClick={() => setVista({ tipo: "lugar" })}
                    className="mt-3 min-h-16 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground shadow-playful active:scale-[0.98]"
                  >
                    {s.at === "cooprecoz" ? "Trabajar en COOPRECOZ" : `Entrar a ${aqui.name}`}
                  </button>
                  <p className="mt-3 text-base font-bold text-muted-foreground">
                    O toca otro lugar del mapa para pedir un carro 🚗
                  </p>
                </div>
                <BilleteraResumen bills={s.billetera} />
                <Progreso hechos={s.hechos} />
                <button
                  onClick={reiniciar}
                  className="mx-auto flex items-center gap-2 rounded-2xl px-4 py-2 text-sm font-bold text-muted-foreground hover:bg-muted"
                >
                  <RotateCcw className="size-4" /> Empezar de nuevo
                </button>
              </>
            )}

            {vista.tipo === "viaje" && (
              <>
                <ViajeUber
                  key={vista.destino}
                  origen={s.at}
                  destino={vista.destino}
                  billetera={s.billetera}
                  fase={vista.fase}
                  setFase={(f) => setVista((v) => (v.tipo === "viaje" ? { ...v, fase: f } : v))}
                  onPagar={pagar}
                  onRecibirVuelto={recibir}
                  onCancelar={() => setVista({ tipo: "mapa" })}
                  onLlegar={() => {
                    const dest = vista.destino;
                    setS((x) => ({ ...x, at: dest, viajes: x.viajes + 1 }));
                    recordActivity({ xp: 40, coins: 100, keys: ["vuelto", "viaje"] });
                    toast.success(`¡Llegaste a ${getPlace(dest).name}!`);
                    setVista({ tipo: "lugar" });
                  }}
                />
                <BilleteraResumen bills={s.billetera} />
              </>
            )}
          </>
        )}

        {vista.tipo === "lugar" && (
          <>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setVista({ tipo: "mapa" })}
                className="flex min-h-12 items-center gap-2 rounded-2xl border-2 border-border bg-card px-4 text-base font-extrabold"
              >
                <ArrowLeft className="size-5" /> Mapa
              </button>
              <div className="min-w-0 flex-1 text-right">
                <div className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">
                  Estás en
                </div>
                <div className="truncate text-xl font-black">
                  {aqui.emoji} {aqui.name}
                </div>
              </div>
            </div>
            <BilleteraResumen bills={s.billetera} />
            {s.at === "cooprecoz" ? (
              <TrabajoCooprecoz
                caja={s.caja}
                setCaja={(caja) => setS((x) => ({ ...x, caja }))}
                onSueldo={(v) => {
                  recibir(v);
                  setS((x) => ({ ...x, turnos: x.turnos + 1 }));
                  recordActivity({ xp: 40, coins: 100, keys: ["cajero", "vuelto"] });
                }}
                onTurnoCompleto={() => marcarHecho("cooprecoz")}
              />
            ) : (
              <MisionLugar
                key={`${s.at}-${s.compras}`}
                place={aqui}
                billetera={s.billetera}
                onPagar={pagar}
                onRecibirVuelto={recibir}
                onTerminar={() => {
                  marcarHecho(aqui.id);
                  setS((x) => ({ ...x, compras: x.compras + 1 }));
                  const r = recordActivity({
                    xp: 100,
                    coins: 300,
                    keys: ["mapa", "tienda", "recibo"],
                  });
                  r.nuevasInsignias.forEach((b) =>
                    toast.success(`${b.emoji} Nueva insignia: ${b.name}`),
                  );
                  setVista({ tipo: "mapa" });
                }}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}

/* ------------------------------ Dibujo del mapa ------------------------------ */

function MapaFondo() {
  const centro = { x: 50, y: 50 };
  return (
    <svg viewBox="0 0 100 100" className="absolute inset-0 size-full" aria-hidden="true">
      {/* manzanas */}
      {[
        [32, 6, 36, 14],
        [6, 34, 14, 32],
        [80, 34, 14, 32],
        [32, 80, 36, 14],
      ].map(([x, y, w, h], i) => (
        <rect
          key={i}
          x={x}
          y={y}
          width={w}
          height={h}
          rx={3}
          className="fill-black/5 dark:fill-white/5"
        />
      ))}
      {/* árboles */}
      {[
        [38, 10],
        [62, 10],
        [10, 44],
        [10, 58],
        [90, 44],
        [90, 58],
        [40, 90],
        [60, 90],
      ].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={2.6} className="fill-[oklch(0.62_0.15_145)]" />
      ))}
      {/* anillo vial */}
      <rect
        x={20}
        y={20}
        width={60}
        height={60}
        rx={8}
        fill="none"
        className="stroke-[oklch(0.55_0.01_250)]"
        strokeWidth={6}
      />
      {/* avenidas al centro */}
      {PLACES.filter((p) => p.id !== "cooprecoz").map((p) => (
        <line
          key={p.id}
          x1={centro.x}
          y1={centro.y}
          x2={p.x}
          y2={p.y}
          className="stroke-[oklch(0.55_0.01_250)]"
          strokeWidth={6}
          strokeLinecap="round"
        />
      ))}
      {/* líneas de carril */}
      <rect
        x={20}
        y={20}
        width={60}
        height={60}
        rx={8}
        fill="none"
        stroke="white"
        strokeWidth={0.5}
        strokeDasharray="2 2"
        opacity={0.8}
      />
      {PLACES.filter((p) => p.id !== "cooprecoz").map((p) => (
        <line
          key={`c-${p.id}`}
          x1={centro.x}
          y1={centro.y}
          x2={p.x}
          y2={p.y}
          stroke="white"
          strokeWidth={0.5}
          strokeDasharray="2 2"
          opacity={0.8}
        />
      ))}
      {/* plaza central */}
      <circle
        cx={50}
        cy={50}
        r={13}
        className="fill-[oklch(0.88_0.08_80)] dark:fill-[oklch(0.4_0.06_80)]"
      />
    </svg>
  );
}

function Edificio({
  id,
  aqui,
  hecho,
  elegido,
  onClick,
}: {
  id: PlaceId;
  aqui: boolean;
  hecho: boolean;
  elegido: boolean;
  onClick: () => void;
}) {
  const p = getPlace(id);
  const centro = id === "cooprecoz";
  return (
    <button
      onClick={onClick}
      style={{ left: `${p.x}%`, top: `${p.y}%` }}
      aria-label={`${p.name}. ${p.desc}${aqui ? ". Estás aquí" : ""}`}
      className={`absolute z-10 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-0.5 rounded-2xl px-1.5 py-1.5 shadow-md ring-2 transition hover:scale-105 active:scale-95 sm:px-2.5 sm:py-2 ${p.tone} ${
        centro ? "w-[30%]" : "w-[25%]"
      } ${elegido ? "scale-110 ring-4 ring-foreground" : ""}`}
    >
      {centro ? (
        <img
          src={logo.url}
          alt=""
          className="size-9 rounded-full bg-white object-contain ring-2 ring-white sm:size-14"
        />
      ) : (
        <span className="text-2xl leading-none sm:text-4xl">{p.emoji}</span>
      )}
      <span
        className={`w-full truncate text-center font-black leading-tight ${centro ? "text-[11px] sm:text-base" : "text-[10px] sm:text-sm"}`}
      >
        {centro ? p.name : p.short}
      </span>
      {hecho && (
        <span className="absolute -right-2 -top-2 grid size-6 place-items-center rounded-full bg-accent-green text-white ring-2 ring-card">
          <Check className="size-4" />
        </span>
      )}
    </button>
  );
}

function Yo({ x, y }: { x: number; y: number }) {
  const avatar = useAvatar();
  // Se ubica en la esquina superior izquierda del edificio, sin tapar su logo.
  const mitad = x === 50 && y === 50 ? 15 : 12.5;
  return (
    <div
      className="pointer-events-none absolute z-20 -translate-x-1/2 -translate-y-full transition-all duration-700"
      style={{ left: `${x - mitad + 2}%`, top: `calc(${y}% - 0.5rem)` }}
      aria-hidden="true"
    >
      <div className="animate-float flex flex-col items-center">
        <div className="rounded-full bg-card p-0.5 shadow-lg ring-2 ring-primary">
          <AvatarView state={avatar} size={34} />
        </div>
        <div className="-mt-0.5 rounded-full bg-primary px-1.5 text-[9px] font-black uppercase text-primary-foreground">
          Tú
        </div>
      </div>
    </div>
  );
}

function Carro({ x, y, visible }: { x: number; y: number; visible: boolean }) {
  if (!visible) return null;
  return (
    <div
      className="pointer-events-none absolute z-30 -translate-x-1/2 -translate-y-1/2 text-3xl drop-shadow-lg transition-all ease-in-out sm:text-4xl"
      style={{ left: `${x}%`, top: `${y}%`, transitionDuration: "3000ms" }}
      aria-hidden="true"
    >
      🚗
    </div>
  );
}

function Progreso({ hechos }: { hechos: PlaceId[] }) {
  return (
    <div className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border/70">
      <div className="flex items-baseline justify-between">
        <div className="text-base font-extrabold">Misiones de la ciudad</div>
        <div className="font-mono text-sm font-bold text-muted-foreground">
          {hechos.length} / {PLACES.length}
        </div>
      </div>
      <div className="mt-3 grid gap-2">
        {PLACES.map((p) => {
          const ok = hechos.includes(p.id);
          return (
            <div
              key={p.id}
              className={`flex items-center gap-3 rounded-2xl px-3 py-2 ${ok ? "bg-accent-green/10" : "bg-muted/40"}`}
            >
              <span className="text-2xl">{p.emoji}</span>
              <span className="min-w-0 flex-1">
                <span className="block text-base font-extrabold leading-tight">{p.name}</span>
                <span className="block text-sm text-muted-foreground">
                  {p.id === "cooprecoz" ? "Atiende 3 clientes" : p.desc}
                </span>
              </span>
              {ok ? (
                <Check className="size-6 text-accent-green" />
              ) : p.id !== "cooprecoz" ? (
                <span className="font-mono text-xs font-bold text-muted-foreground">
                  🚗 desde {formatCOP(tarifa("cooprecoz", p.id))}
                </span>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
