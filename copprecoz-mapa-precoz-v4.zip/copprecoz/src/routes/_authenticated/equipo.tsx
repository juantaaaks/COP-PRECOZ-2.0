import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, ShieldCheck, Check, X, Trash2, Clock, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import {
  cambiarEstado,
  cargarMiEquipo,
  listarEquipo,
  pedirAcceso,
  quitarIntegrante,
  type Integrante,
  type MiEquipo,
} from "@/lib/team";

export const Route = createFileRoute("/_authenticated/equipo")({
  component: EquipoPage,
  head: () => ({
    meta: [
      { title: "Equipo Cooprecoz — COPprecoz" },
      {
        name: "description",
        content:
          "Gestiona quién del equipo Cooprecoz puede usar la Calculadora Precoz y el Arqueo de caja.",
      },
      { property: "og:title", content: "Equipo Cooprecoz — COPprecoz" },
      {
        property: "og:description",
        content: "Solicita y aprueba el acceso del equipo Cooprecoz a las herramientas de caja.",
      },
    ],
  }),
});

const ESTADO_TXT: Record<string, string> = {
  pendiente: "Pendiente",
  aprobado: "Aprobado",
  rechazado: "Rechazado",
};

function EquipoPage() {
  const [mi, setMi] = useState<MiEquipo | null>(null);
  const [lista, setLista] = useState<Integrante[]>([]);
  const [nombre, setNombre] = useState("");
  const [cargo, setCargo] = useState("cajero");
  const [cargando, setCargando] = useState(true);

  const recargar = async () => {
    const e = await cargarMiEquipo();
    setMi(e);
    if (e.esDueño) setLista(await listarEquipo());
    setCargando(false);
  };

  useEffect(() => {
    void recargar();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <PageHeader eyebrow="Cooperativa" title="Equipo Cooprecoz" width="max-w-3xl" />

      <main className="mx-auto max-w-3xl space-y-5 px-4 py-6 pb-24">
        <section className="rounded-3xl bg-card p-6 shadow-sm ring-2 ring-primary/20">
          <div className="flex items-center gap-3">
            <div className="grid size-12 place-items-center rounded-2xl bg-primary/10 text-primary">
              <ShieldCheck className="size-6" />
            </div>
            <div>
              <div className="text-xl font-extrabold">Tu acceso</div>
              <div className="text-muted-foreground">{mi?.email || "Sin sesión"}</div>
            </div>
          </div>
          <p className="mt-3 text-lg font-bold">
            {cargando
              ? "Revisando…"
              : mi?.esDueño
                ? "Eres maestro líder o gerente: puedes aprobar al equipo."
                : mi?.aprobado
                  ? "Aprobado: ya puedes usar Calculadora Precoz y Arqueo de caja."
                  : mi?.solicitud?.status === "pendiente"
                    ? "Solicitud enviada. Espera la aprobación."
                    : "Aún no tienes acceso a las herramientas de caja."}
          </p>
        </section>

        {!cargando && !mi?.esDueño && !mi?.aprobado && !mi?.solicitud && (
          <section className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-black/5">
            <h2 className="flex items-center gap-2 text-xl font-extrabold">
              <UserPlus className="size-6 text-primary" /> Pedir acceso
            </h2>
            <div className="mt-4 space-y-3">
              <input
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Tu nombre completo"
                className="w-full rounded-2xl border-2 border-border bg-background px-4 py-3 text-lg"
              />
              <select
                value={cargo}
                onChange={(e) => setCargo(e.target.value)}
                className="w-full rounded-2xl border-2 border-border bg-background px-4 py-3 text-lg"
              >
                <option value="cajero">Persona cajera</option>
                <option value="gerente">Gerente</option>
                <option value="maestro">Maestro líder</option>
                <option value="apoyo">Apoyo</option>
              </select>
              <button
                onClick={async () => {
                  try {
                    await pedirAcceso(nombre.trim() || (mi?.email ?? ""), cargo);
                    toast.success("Solicitud enviada");
                    await recargar();
                  } catch (e) {
                    toast.error((e as Error).message);
                  }
                }}
                className="w-full rounded-2xl bg-primary px-5 py-4 text-lg font-extrabold text-primary-foreground active:scale-95"
              >
                Enviar solicitud
              </button>
            </div>
          </section>
        )}

        {mi?.esDueño && (
          <section className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-black/5">
            <h2 className="text-xl font-extrabold">Integrantes</h2>
            {lista.length === 0 && (
              <p className="mt-3 text-muted-foreground">Todavía no hay solicitudes.</p>
            )}
            <div className="mt-4 space-y-3">
              {lista.map((i) => (
                <div key={i.id} className="rounded-2xl bg-muted/40 p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-lg font-extrabold">
                        {i.full_name || i.email}
                      </div>
                      <div className="truncate text-sm text-muted-foreground">
                        {i.email} · {i.cargo}
                      </div>
                    </div>
                    <span className="inline-flex items-center gap-1 rounded-full bg-background px-3 py-1 text-sm font-bold">
                      <Clock className="size-4" /> {ESTADO_TXT[i.status] ?? i.status}
                    </span>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={async () => {
                        await cambiarEstado(i.id, "aprobado");
                        toast.success("Aprobado");
                        await recargar();
                      }}
                      className="flex-1 rounded-xl bg-primary px-3 py-3 font-extrabold text-primary-foreground active:scale-95"
                    >
                      <Check className="mx-auto size-5" />
                    </button>
                    <button
                      onClick={async () => {
                        await cambiarEstado(i.id, "rechazado");
                        await recargar();
                      }}
                      className="flex-1 rounded-xl border-2 border-border px-3 py-3 font-extrabold active:scale-95"
                    >
                      <X className="mx-auto size-5" />
                    </button>
                    <button
                      onClick={async () => {
                        await quitarIntegrante(i.id);
                        await recargar();
                      }}
                      className="rounded-xl border-2 border-destructive/40 px-3 py-3 text-destructive active:scale-95"
                      aria-label="Quitar"
                    >
                      <Trash2 className="size-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
