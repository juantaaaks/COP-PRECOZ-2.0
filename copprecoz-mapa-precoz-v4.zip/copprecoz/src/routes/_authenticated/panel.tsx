import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { formatCOP } from "@/lib/cop";
import { isGuest, disableGuest } from "@/lib/guest";
import logo from "@/assets/logo.jpg.asset.json";
import { SettingsButton } from "@/components/settings-sheet";
import { LogrosSection, useGame } from "@/components/gamification-ui";
import { levelFromXp } from "@/lib/gamification";
import {
  Coins,
  Flame,
  Star,
  Trophy,
  BookOpen,
  Store,
  Hand,
  LogOut,
  ChevronRight,
  ShieldCheck,
  ShoppingBasket,
  PiggyBank,
  CheckCircle2,
  PlayCircle,
  Circle,
} from "lucide-react";
import { ClipboardList, Receipt, User } from "lucide-react";
import { AvatarView, useAvatar } from "@/components/avatar-view";
import { pullAvatar } from "@/lib/avatar";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/panel")({
  component: Panel,
  head: () => ({
    meta: [
      { title: "Mi panel — COPprecoz" },
      {
        name: "description",
        content: "Sigue tu progreso y continúa aprendiendo con los módulos de COPprecoz.",
      },
      { property: "og:title", content: "Mi panel — COPprecoz" },
      {
        property: "og:description",
        content: "Tu progreso, tus logros y los módulos para aprender a usar el dinero colombiano.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type Stats = {
  level: number;
  xp: number;
  coins: number;
  streak_days: number;
  full_name: string;
};

const MODULES = [
  {
    id: "conocer",
    emoji: "🖐️",
    title: "Conozco el dinero",
    desc: "Monedas y billetes de Colombia",
    icon: Hand,
    soft: "bg-mod-conocer-soft",
    text: "text-mod-conocer",
    bar: "bg-mod-conocer",
    ring: "ring-mod-conocer/25",
  },
  {
    id: "contar",
    emoji: "📖",
    title: "Cuento el dinero",
    desc: "Suma monedas y billetes",
    icon: BookOpen,
    soft: "bg-mod-contar-soft",
    text: "text-mod-contar",
    bar: "bg-mod-contar",
    ring: "ring-mod-contar/25",
  },
  {
    id: "precoz",
    emoji: "🧮",
    title: "Calculadora Precoz",
    desc: "Cobra y devuelve el vuelto",
    icon: ShoppingBasket,
    soft: "bg-mod-precoz-soft",
    text: "text-mod-precoz",
    bar: "bg-mod-precoz",
    ring: "ring-mod-precoz/25",
  },
  {
    id: "cajero",
    emoji: "💰",
    title: "Soy la persona cajera",
    desc: "Atiende y entrega el vuelto",
    icon: Coins,
    soft: "bg-mod-cajero-soft",
    text: "text-mod-cajero",
    bar: "bg-mod-cajero",
    ring: "ring-mod-cajero/25",
  },
  {
    id: "tienda",
    emoji: "🏪",
    title: "Simulador de tienda",
    desc: "Compra, paga y recibe vuelto",
    icon: Store,
    soft: "bg-mod-tienda-soft",
    text: "text-mod-tienda",
    bar: "bg-mod-tienda",
    ring: "ring-mod-tienda/25",
  },
  {
    id: "finanzas",
    emoji: "🐷",
    title: "Cuido mi dinero",
    desc: "Ahorro y presupuesto",
    icon: PiggyBank,
    soft: "bg-mod-finanzas-soft",
    text: "text-mod-finanzas",
    bar: "bg-mod-finanzas",
    ring: "ring-mod-finanzas/25",
  },
  {
    id: "recibo",
    emoji: "🧾",
    title: "Leo mi recibo",
    desc: "Aprende a leer el recibo de compra",
    icon: Receipt,
    soft: "bg-mod-recibo-soft",
    text: "text-mod-recibo",
    bar: "bg-mod-recibo",
    ring: "ring-mod-recibo/25",
  },
] as const;

function Panel() {
  const navigate = useNavigate();
  const game = useGame();
  const avatar = useAvatar();
  const [stats, setStats] = useState<Stats | null>(null);
  const [guest, setGuest] = useState(false);
  const [progreso, setProgreso] = useState<Record<string, number>>({});
  const [verLogros, setVerLogros] = useState(false);

  useEffect(() => {
    void pullAvatar();
  }, []);

  useEffect(() => {
    (async () => {
      if (isGuest()) {
        setGuest(true);
        setStats({ full_name: "Invitado/a", level: 1, xp: 0, coins: 0, streak_days: 0 });
        return;
      }
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id;
      if (!uid) return;

      const [{ data: profile }, { data: progress }, { data: mods }] = await Promise.all([
        supabase.from("profiles").select("full_name").eq("id", uid).maybeSingle(),
        supabase
          .from("student_progress")
          .select("level, xp, coins, streak_days")
          .eq("user_id", uid)
          .maybeSingle(),
        supabase.from("module_progress").select("module_slug, percent").eq("user_id", uid),
      ]);

      setStats({
        full_name: profile?.full_name ?? userData.user?.email?.split("@")[0] ?? "Estudiante",
        level: progress?.level ?? 1,
        xp: progress?.xp ?? 0,
        coins: progress?.coins ?? 0,
        streak_days: progress?.streak_days ?? 0,
      });
      const mapa: Record<string, number> = {};
      for (const m of mods ?? []) mapa[m.module_slug] = m.percent ?? 0;
      setProgreso(mapa);
    })();
  }, []);

  async function handleSignOut() {
    if (guest) {
      disableGuest();
      navigate({ to: "/auth", replace: true });
      return;
    }
    await supabase.auth.signOut();
    toast.success("¡Hasta pronto!");
    navigate({ to: "/auth", replace: true });
  }

  const xp = Math.max(stats?.xp ?? 0, game.xp);
  const nextLevel = 1000;
  const pct = Math.min(100, Math.round((xp / nextLevel) * 100));
  const nivel = Math.max(stats?.level ?? 1, levelFromXp(game.xp));
  const racha = Math.max(stats?.streak_days ?? 0, game.streak);
  const monedas = Math.max(stats?.coins ?? 0, game.coins);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-20 border-b border-border/70 bg-background/85 backdrop-blur">
        <div className="mx-auto grid max-w-5xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <img
              src={logo.url}
              alt="Logo Cooprecoz"
              className="size-11 shrink-0 rounded-2xl object-contain ring-1 ring-border"
            />
            <div className="min-w-0">
              <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                COPprecoz
              </div>
              <div className="truncate text-base font-extrabold leading-tight sm:text-lg">
                {stats?.full_name ?? "…"}
              </div>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <SettingsButton />
            <button
              onClick={handleSignOut}
              aria-label="Cerrar sesión"
              className="flex min-h-12 items-center gap-2 rounded-2xl border-2 border-border bg-card px-3 py-2 text-base font-extrabold transition hover:bg-muted active:scale-95"
            >
              <LogOut className="size-5" />
              <span className="hidden sm:inline">Salir</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-8 px-4 py-6 pb-24 sm:px-6 sm:py-8 sm:pb-28">
        {/* Bienvenida */}
        <section className="rounded-4xl bg-card p-6 shadow-sm ring-1 ring-border/70 sm:p-8">
          <div className="grid gap-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
            <div className="min-w-0">
              {guest && (
                <span className="mb-2 inline-block rounded-full bg-accent-yellow/25 px-3 py-1 text-xs font-extrabold uppercase tracking-widest text-primary">
                  Modo invitado
                </span>
              )}
              <div className="text-base font-bold text-muted-foreground">Bienvenido/a</div>
              <h1 className="text-2xl font-black leading-tight tracking-tight sm:text-4xl">
                {stats?.full_name ?? "…"}
              </h1>
              <p className="mt-2 max-w-prose text-lg text-muted-foreground">
                Elige un módulo y sigue aprendiendo a usar el dinero colombiano.
              </p>
            </div>
            <Link
              to="/personaje"
              className="flex items-center gap-3 justify-self-start rounded-3xl bg-muted/50 p-3 pr-5 ring-1 ring-border/70 transition duration-200 hover:bg-muted sm:justify-self-end"
            >
              <AvatarView state={avatar} size={72} />
              <span className="text-left">
                <span className="block text-base font-extrabold">Mi personaje</span>
                <span className="block text-sm text-muted-foreground">Cámbialo aquí</span>
              </span>
            </Link>
          </div>

          <button
            onClick={() => setVerLogros((v) => !v)}
            aria-expanded={verLogros}
            className="mt-6 flex min-h-16 w-full items-center justify-between gap-3 rounded-3xl bg-muted/50 px-5 py-4 text-left ring-1 ring-border/70 transition hover:bg-muted active:scale-[0.99]"
          >
            <span className="flex items-center gap-3">
              <Trophy className="size-7 text-primary" />
              <span>
                <span className="block text-lg font-extrabold">Mis logros y progreso</span>
                <span className="block text-sm text-muted-foreground">
                  Racha {racha} d · Nivel {nivel} · Toca para {verLogros ? "ocultar" : "ver"}
                </span>
              </span>
            </span>
            <span className="text-2xl font-black text-muted-foreground">
              {verLogros ? "▲" : "▼"}
            </span>
          </button>

          {verLogros && (
            <>
              <div className="mt-4 grid grid-cols-3 gap-3">
                <StatCard
                  icon={<Flame className="size-5" />}
                  label="Racha"
                  value={`${racha} d`}
                  tone="bg-accent-red/10 text-accent-red"
                />
                <StatCard
                  icon={<Star className="size-5" />}
                  label="Nivel"
                  value={`${nivel}`}
                  tone="bg-primary/10 text-primary"
                />
                <StatCard
                  icon={<Trophy className="size-5" />}
                  label="Alcancía"
                  value={formatCOP(monedas)}
                  tone="bg-accent-green/10 text-accent-green"
                />
              </div>

              <div className="mt-4 rounded-3xl bg-muted/40 p-5 ring-1 ring-border/60">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div className="text-lg font-extrabold">Progreso a nivel {nivel + 1}</div>
                  <div className="font-mono text-sm text-muted-foreground">
                    {xp} / {nextLevel} XP
                  </div>
                </div>
                <div
                  className="mt-3 h-5 w-full overflow-hidden rounded-full bg-background ring-1 ring-border/70"
                  role="progressbar"
                  aria-valuenow={pct}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-label={`Progreso a nivel ${nivel + 1}`}
                >
                  <div
                    className="h-full rounded-full bg-primary transition-[width] duration-500 ease-out"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
              <div className="mt-4">
                <LogrosSection />
              </div>
            </>
          )}
        </section>

        {/* Mapa Precoz */}
        <Link
          to="/mapa"
          className="group relative flex items-center gap-4 overflow-hidden rounded-4xl bg-primary p-5 text-primary-foreground shadow-playful transition duration-200 hover:-translate-y-1 sm:p-6"
        >
          <div className="grid size-20 shrink-0 place-items-center rounded-3xl bg-background/95 text-5xl shadow-sm sm:size-24">
            🗺️
          </div>
          <div className="min-w-0 flex-1">
            <span className="inline-block rounded-full bg-background/20 px-2.5 py-0.5 text-xs font-extrabold uppercase tracking-widest">
              Nuevo
            </span>
            <div className="mt-1 text-2xl font-black leading-tight tracking-tight">Mapa Precoz</div>
            <div className="text-base opacity-90">
              Sal de COOPRECOZ, pide un carro y compra en la droguería, la papelería, el mercado y
              la plaza.
            </div>
          </div>
          <ChevronRight className="size-7 shrink-0 transition group-hover:translate-x-1" />
        </Link>

        {/* Módulos */}
        <section>
          <div className="mb-4 flex items-baseline justify-between gap-3">
            <h2 className="text-xl font-black tracking-tight sm:text-2xl">
              Módulos de aprendizaje
            </h2>
            <span className="text-sm font-bold text-muted-foreground">Toca uno para empezar</span>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {MODULES.map((m) => (
              <ModuleCard key={m.id} m={m} percent={progreso[m.id] ?? 0} />
            ))}
          </div>
        </section>

        {/* Cooperativa */}
        <section>
          <h2 className="mb-4 text-xl font-black tracking-tight sm:text-2xl">La cooperativa</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <BigLink
              to="/arqueo"
              icon={<ClipboardList className="size-7" />}
              tone="bg-accent-green/10 text-accent-green"
              title="Arqueo de caja"
              desc="Cuenta el dinero y guarda el registro"
            />
            <BigLink
              to="/cooprecoz"
              icon={<ShieldCheck className="size-7" />}
              tone="bg-accent-blue/10 text-accent-blue"
              title="Inicio del equipo"
              desc="Caja, ventas del día y panel del líder"
            />
            <BigLink
              to="/equipo"
              icon={<User className="size-7" />}
              tone="bg-primary/10 text-primary"
              title="Mi acceso al equipo"
              desc="Pide o aprueba el acceso del equipo"
            />
          </div>
        </section>
      </main>
    </div>
  );
}

function BigLink({
  to,
  icon,
  tone,
  title,
  desc,
}: {
  to: "/arqueo" | "/cooprecoz" | "/equipo";
  icon: React.ReactNode;
  tone: string;
  title: string;
  desc: string;
}) {
  return (
    <Link
      to={to}
      className="flex min-h-24 items-center gap-4 rounded-3xl bg-card p-5 shadow-sm ring-1 ring-border/70 transition duration-200 ease-out hover:-translate-y-0.5 hover:shadow-md focus-visible:-translate-y-0.5"
    >
      <div className={`grid size-14 shrink-0 place-items-center rounded-2xl ${tone}`}>{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="text-lg font-extrabold leading-tight">{title}</div>
        <div className="text-sm text-muted-foreground">{desc}</div>
      </div>
      <ChevronRight className="size-5 shrink-0 text-muted-foreground" />
    </Link>
  );
}

function ModuleCard({ m, percent }: { m: (typeof MODULES)[number]; percent: number }) {
  const Icon = m.icon;
  const completado = percent >= 100;
  const enProgreso = percent > 0 && percent < 100;
  const estado = completado ? "Completado" : enProgreso ? "En progreso" : "Por comenzar";
  const EstadoIcon = completado ? CheckCircle2 : enProgreso ? PlayCircle : Circle;

  return (
    <Link
      to="/modulo/$slug"
      params={{ slug: m.id }}
      aria-label={`${m.title}. ${estado}. ${percent}% completado`}
      className={`group flex h-full flex-col gap-4 rounded-4xl ${m.soft} p-5 text-left ring-1 ${m.ring} transition duration-200 ease-out hover:-translate-y-1 hover:shadow-lg focus-visible:-translate-y-1 sm:p-6`}
    >
      <div className="flex items-start justify-between gap-3">
        <div
          className={`grid size-16 shrink-0 place-items-center rounded-3xl bg-card text-3xl shadow-sm ring-1 ring-border/60 transition duration-200 group-hover:scale-105 ${m.text}`}
          aria-hidden="true"
        >
          <span className="sr-only">{m.emoji}</span>
          <Icon className="size-8" />
        </div>
        <span
          className={`inline-flex items-center gap-1.5 rounded-full bg-card px-3 py-1.5 text-xs font-extrabold ring-1 ring-border/60 ${completado ? "text-accent-green" : enProgreso ? m.text : "text-muted-foreground"}`}
        >
          <EstadoIcon className="size-4" />
          {estado}
        </span>
      </div>

      <div className="min-w-0 flex-1">
        <div className="text-xl font-black leading-tight tracking-tight">
          <span aria-hidden="true">{m.emoji} </span>
          {m.title}
        </div>
        <div className="mt-1 text-base text-muted-foreground">{m.desc}</div>
      </div>

      <div>
        <div className="mb-1.5 flex items-center justify-between text-sm font-bold text-muted-foreground">
          <span>Tu avance</span>
          <span className="font-mono">{percent}%</span>
        </div>
        <div
          className="h-4 w-full overflow-hidden rounded-full bg-card ring-1 ring-border/60"
          role="progressbar"
          aria-valuenow={percent}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label={`Avance de ${m.title}`}
        >
          <div
            className={`h-full rounded-full ${m.bar} transition-[width] duration-500 ease-out`}
            style={{ width: `${Math.max(percent, 2)}%` }}
          />
        </div>
      </div>
    </Link>
  );
}

function StatCard({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone: string;
}) {
  return (
    <div className="rounded-3xl bg-muted/40 p-4 ring-1 ring-border/60">
      <div className={`grid size-10 place-items-center rounded-xl ${tone}`}>{icon}</div>
      <div className="mt-3 text-xs font-bold uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <div className="text-xl font-extrabold">{value}</div>
    </div>
  );
}
