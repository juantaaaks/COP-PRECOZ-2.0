import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Coins, Lock, Shirt, Check } from "lucide-react";
import { toast } from "sonner";
import { AvatarView, useAvatar } from "@/components/avatar-view";
import { SettingsButton } from "@/components/settings-sheet";
import {
  PELOS,
  PEINADOS,
  PIELES,
  TIENDA_ROPA,
  getAvatar,
  pullAvatar,
  saveAvatar,
  type Genero,
  type Peinado,
  type Slot,
} from "@/lib/avatar";
import { useGame } from "@/components/gamification-ui";
import { levelFromXp, spendCoins } from "@/lib/gamification";
import { formatCOP } from "@/lib/cop";
import { speak } from "@/components/money-ui";

export const Route = createFileRoute("/_authenticated/personaje")({
  component: PersonajePage,
  head: () => ({
    meta: [
      { title: "Mi personaje — COPprecoz" },
      {
        name: "description",
        content: "Crea tu personaje y cómprale ropa con las monedas que ganas en las misiones diarias.",
      },
      { property: "og:title", content: "Mi personaje — COPprecoz" },
      { property: "og:description", content: "Viste tu personaje con las monedas que ganas aprendiendo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const GRUPOS: { slot: Slot; titulo: string }[] = [
  { slot: "camiseta", titulo: "Camisetas" },
  { slot: "sombrero", titulo: "Sombreros" },
  { slot: "gafas", titulo: "Gafas" },
  { slot: "mascota", titulo: "Mascotas" },
  { slot: "fondo", titulo: "Fondos" },
];

function PersonajePage() {
  const avatar = useAvatar();
  const game = useGame();
  const nivel = levelFromXp(game.xp);
  const [tab, setTab] = useState<"editar" | "tienda">("editar");

  useEffect(() => {
    void pullAvatar();
  }, []);

  function set<K extends keyof typeof avatar.config>(k: K, v: (typeof avatar.config)[K]) {
    const s = getAvatar();
    saveAvatar({ ...s, config: { ...s.config, [k]: v } });
  }

  function equipar(slot: Slot, id: string) {
    const s = getAvatar();
    const quitar = s.config[slot as keyof typeof s.config] === id && slot !== "camiseta" && slot !== "fondo";
    saveAvatar({ ...s, config: { ...s.config, [slot]: quitar ? null : id } });
  }

  function comprar(id: string, precio: number, nombre: string) {
    const s = getAvatar();
    if (s.owned.includes(id)) return;
    if (!spendCoins(precio)) {
      toast.error("Te faltan monedas. ¡Completa misiones para ganar más!");
      speak("Te faltan monedas. Completa una misión para ganar más.");
      return;
    }
    saveAvatar({ ...s, owned: [...s.owned, id] });
    toast.success(`¡Compraste ${nombre}!`);
    speak(`Compraste ${nombre}`);
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-2 px-3 py-3 sm:px-5">
          <Link to="/panel" className="flex items-center gap-2 font-extrabold">
            <ArrowLeft className="size-5" /> Volver
          </Link>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-2 rounded-2xl bg-accent-yellow/25 px-3 py-2 font-mono font-black text-primary">
              <Coins className="size-5" /> {formatCOP(game.coins)}
            </span>
            <SettingsButton />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-6 px-3 py-6 pb-24 sm:px-5">
        <h1 className="text-2xl font-extrabold sm:text-3xl">Mi personaje</h1>

        <div className="grid gap-5 sm:grid-cols-[auto_minmax(0,1fr)] sm:items-start">
          <div className="mx-auto">
            <AvatarView state={avatar} size={220} />
          </div>
          <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
            <label className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
              Nombre
            </label>
            <input
              value={avatar.config.nombre}
              onChange={(e) => set("nombre", e.target.value)}
              className="mt-2 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 text-lg font-extrabold"
              maxLength={24}
            />
            <div className="mt-4 text-sm font-bold text-muted-foreground">
              Nivel {nivel} · gana monedas con las misiones diarias para comprar más ropa.
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 rounded-3xl bg-muted p-2">
          {(["editar", "tienda"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-2xl py-3 text-lg font-extrabold transition ${
                tab === t ? "bg-card shadow ring-1 ring-black/5" : "text-muted-foreground"
              }`}
            >
              {t === "editar" ? "Editar" : "Tienda de ropa"}
            </button>
          ))}
        </div>

        {tab === "editar" ? (
          <div className="space-y-5">
            <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
              <div className="mb-3 font-extrabold">¿Cómo eres?</div>
              <div className="grid grid-cols-2 gap-3">
                {(
                  [
                    { id: "mujer", label: "Mujer", emoji: "👩" },
                    { id: "hombre", label: "Hombre", emoji: "👨" },
                  ] as { id: Genero; label: string; emoji: string }[]
                ).map((g) => (
                  <button
                    key={g.id}
                    onClick={() => set("genero", g.id)}
                    className={`rounded-2xl p-3 text-center ring-2 transition active:scale-95 ${
                      (avatar.config.genero ?? "mujer") === g.id
                        ? "bg-primary/10 ring-primary"
                        : "bg-muted/40 ring-transparent"
                    }`}
                  >
                    <div className="text-3xl">{g.emoji}</div>
                    <div className="mt-1 text-sm font-extrabold leading-tight">{g.label}</div>
                  </button>
                ))}
              </div>

              <div className="mb-3 mt-5 font-extrabold">Peinado</div>
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-5">
                {PEINADOS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => set("peinado", p.id as Peinado)}
                    className={`rounded-2xl p-3 text-center ring-2 transition active:scale-95 ${
                      (avatar.config.peinado ?? "corto") === p.id
                        ? "bg-primary/10 ring-primary"
                        : "bg-muted/40 ring-transparent"
                    }`}
                  >
                    <div className="text-2xl">{p.emoji}</div>
                    <div className="mt-1 text-sm font-extrabold leading-tight">{p.nombre}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
              <div className="mb-3 font-extrabold">Color de piel</div>
              <div className="flex flex-wrap gap-3">
                {PIELES.map((c) => (
                  <button
                    key={c}
                    aria-label={`Piel ${c}`}
                    onClick={() => set("piel", c)}
                    className={`size-14 rounded-2xl ring-2 ${avatar.config.piel === c ? "ring-primary" : "ring-black/10"}`}
                    style={{ background: c }}
                  />
                ))}
              </div>
              <div className="mb-3 mt-5 font-extrabold">Color de pelo</div>
              <div className="flex flex-wrap gap-3">
                {PELOS.map((c) => (
                  <button
                    key={c}
                    aria-label={`Pelo ${c}`}
                    onClick={() => set("pelo", c)}
                    className={`size-14 rounded-2xl ring-2 ${avatar.config.pelo === c ? "ring-primary" : "ring-black/10"}`}
                    style={{ background: c }}
                  />
                ))}
              </div>
            </div>

            {GRUPOS.map((g) => {
              const items = TIENDA_ROPA.filter(
                (p) => p.slot === g.slot && avatar.owned.includes(p.id),
              );
              return (
                <div key={g.slot} className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
                  <div className="mb-3 flex items-center gap-2 font-extrabold">
                    <Shirt className="size-5 text-primary" /> {g.titulo}
                  </div>
                  {items.length === 0 ? (
                    <p className="text-base text-muted-foreground">
                      Todavía no tienes. Ve a la tienda de ropa.
                    </p>
                  ) : (
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                      {items.map((p) => {
                        const puesto = avatar.config[g.slot as keyof typeof avatar.config] === p.id;
                        return (
                          <button
                            key={p.id}
                            onClick={() => equipar(g.slot, p.id)}
                            className={`rounded-2xl p-4 text-center ring-2 transition ${
                              puesto ? "bg-primary/10 ring-primary" : "bg-muted/40 ring-transparent"
                            }`}
                          >
                            <div className="mx-auto grid size-14 place-items-center rounded-xl text-3xl" style={{ background: p.color ?? "transparent" }}>
                              {p.emoji ?? ""}
                            </div>
                            <div className="mt-2 text-base font-extrabold leading-tight">{p.nombre}</div>
                            {puesto && (
                              <div className="mt-1 flex items-center justify-center gap-1 text-sm font-bold text-primary">
                                <Check className="size-4" /> Puesto
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="space-y-5">
            {GRUPOS.map((g) => (
              <div key={g.slot} className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
                <div className="mb-3 font-extrabold">{g.titulo}</div>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {TIENDA_ROPA.filter((p) => p.slot === g.slot).map((p) => {
                    const tiene = avatar.owned.includes(p.id);
                    const bloqueada = (p.nivel ?? 1) > nivel;
                    return (
                      <div
                        key={p.id}
                        className={`rounded-2xl p-4 text-center ring-1 ring-black/5 ${
                          tiene ? "bg-accent-green/10" : "bg-muted/40"
                        }`}
                      >
                        <div
                          className="mx-auto grid size-14 place-items-center rounded-xl text-3xl"
                          style={{ background: p.color ?? "transparent" }}
                        >
                          {p.emoji ?? ""}
                        </div>
                        <div className="mt-2 text-base font-extrabold leading-tight">{p.nombre}</div>
                        {tiene ? (
                          <div className="mt-2 text-sm font-bold text-accent-green">Ya es tuya</div>
                        ) : bloqueada ? (
                          <div className="mt-2 flex items-center justify-center gap-1 text-sm font-bold text-muted-foreground">
                            <Lock className="size-4" /> Nivel {p.nivel}
                          </div>
                        ) : (
                          <button
                            onClick={() => comprar(p.id, p.precio, p.nombre)}
                            className="mt-2 w-full rounded-xl bg-primary py-2 font-mono text-base font-black text-primary-foreground"
                          >
                            {p.precio === 0 ? "Gratis" : formatCOP(p.precio)}
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}