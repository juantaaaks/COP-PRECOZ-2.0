import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { toast } from "sonner";
import { Coins, GraduationCap, Users, User, Rocket } from "lucide-react";
import { enableGuest, disableGuest } from "@/lib/guest";

export const Route = createFileRoute("/auth")({
  component: AuthPage,
  head: () => ({
    meta: [
      { title: "Entrar o crear cuenta — COPprecoz" },
      { name: "description", content: "Inicia sesión o crea tu cuenta en COPprecoz como estudiante, docente o acudiente." },
    ],
  }),
});

type Role = "estudiante" | "docente" | "acudiente";
type Mode = "signin" | "signup";

const ROLES: { value: Role; label: string; icon: typeof User; desc: string }[] = [
  { value: "estudiante", label: "Estudiante", icon: User, desc: "Voy a aprender" },
  { value: "docente", label: "Docente", icon: GraduationCap, desc: "Enseño a estudiantes" },
  { value: "acudiente", label: "Acudiente", icon: Users, desc: "Acompaño a un estudiante" },
];

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<Role>("estudiante");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/panel", replace: true });
    });
  }, [navigate]);

  function handleGuest() {
    enableGuest();
    toast.success("Entraste en modo invitado");
    navigate({ to: "/panel", replace: true });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        disableGuest();
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { full_name: fullName, role },
          },
        });
        if (error) throw error;
        toast.success("¡Cuenta creada! Ya puedes empezar a aprender.");
        navigate({ to: "/panel", replace: true });
      } else {
        disableGuest();
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("¡Hola de nuevo!");
        navigate({ to: "/panel", replace: true });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "No pudimos completar la acción");
    } finally {
      setLoading(false);
    }
  }

  async function handleGoogle() {
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      toast.error("No pudimos entrar con Google");
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/panel", replace: true });
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <Link to="/" className="flex items-center gap-3">
          <div className="grid size-11 place-items-center rounded-2xl bg-primary text-primary-foreground">
            <Coins className="size-5" />
          </div>
          <div className="text-lg font-extrabold tracking-tight">COPprecoz</div>
        </Link>
      </header>

      <main className="mx-auto flex max-w-md flex-col gap-6 px-6 py-8">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold tracking-tight">
            {mode === "signin" ? "¡Hola de nuevo!" : "Crea tu cuenta"}
          </h1>
          <p className="mt-2 text-muted-foreground">
            {mode === "signin"
              ? "Entra para seguir aprendiendo."
              : "Es rápido y gratis. Elige tu perfil."}
          </p>
        </div>

        <div className="rounded-3xl bg-card p-6 shadow-sm ring-1 ring-black/5">
          <div className="mb-5 grid grid-cols-2 gap-1 rounded-2xl bg-muted p-1">
            {(["signin", "signup"] as Mode[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                className={`rounded-xl py-2 text-sm font-bold transition ${
                  mode === m ? "bg-background shadow" : "text-muted-foreground"
                }`}
              >
                {m === "signin" ? "Entrar" : "Crear cuenta"}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "signup" && (
              <>
                <div>
                  <label className="mb-1 block text-sm font-bold" htmlFor="fullName">
                    Nombre completo
                  </label>
                  <input
                    id="fullName"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full rounded-xl border border-input bg-background px-4 py-3 text-base outline-none focus:ring-2 focus:ring-primary"
                    placeholder="María García"
                  />
                </div>
                <div>
                  <span className="mb-2 block text-sm font-bold">¿Cómo vas a usar COPprecoz?</span>
                  <div className="grid gap-2">
                    {ROLES.map((r) => {
                      const Icon = r.icon;
                      const active = role === r.value;
                      return (
                        <button
                          key={r.value}
                          type="button"
                          onClick={() => setRole(r.value)}
                          className={`flex items-center gap-3 rounded-xl border p-3 text-left transition ${
                            active
                              ? "border-primary bg-primary/5 ring-2 ring-primary/30"
                              : "border-border hover:bg-muted"
                          }`}
                        >
                          <div
                            className={`grid size-10 place-items-center rounded-lg ${
                              active ? "bg-primary text-primary-foreground" : "bg-muted"
                            }`}
                          >
                            <Icon className="size-5" />
                          </div>
                          <div>
                            <div className="font-bold">{r.label}</div>
                            <div className="text-xs text-muted-foreground">{r.desc}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
            <div>
              <label className="mb-1 block text-sm font-bold" htmlFor="email">
                Correo
              </label>
              <input
                id="email"
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-input bg-background px-4 py-3 text-base outline-none focus:ring-2 focus:ring-primary"
                placeholder="tu@correo.com"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-bold" htmlFor="password">
                Contraseña
              </label>
              <input
                id="password"
                type="password"
                required
                minLength={6}
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-input bg-background px-4 py-3 text-base outline-none focus:ring-2 focus:ring-primary"
                placeholder="••••••••"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-primary py-4 text-base font-extrabold text-primary-foreground shadow-lg shadow-primary/20 transition hover:brightness-105 disabled:opacity-60"
            >
              {loading ? "Un momento…" : mode === "signin" ? "Entrar" : "Crear mi cuenta"}
            </button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs font-bold uppercase tracking-widest text-muted-foreground">
            <div className="h-px flex-1 bg-border" /> o <div className="h-px flex-1 bg-border" />
          </div>

          <button
            type="button"
            onClick={handleGoogle}
            className="flex w-full items-center justify-center gap-3 rounded-2xl border border-border bg-background py-3 text-sm font-bold hover:bg-muted"
          >
            <GoogleIcon /> Continuar con Google
          </button>

          <button
            type="button"
            onClick={handleGuest}
            className="mt-3 flex w-full items-center justify-center gap-3 rounded-2xl bg-accent-green/15 py-4 text-lg font-extrabold text-accent-green hover:brightness-105"
          >
            <Rocket className="size-6" /> Entrar como invitado
          </button>
          <p className="mt-2 text-center text-xs text-muted-foreground">
            En modo invitado puedes practicar todos los módulos, pero el progreso no se guarda.
          </p>
        </div>

        <p className="text-center text-sm text-muted-foreground">
          <Link to="/" className="underline">
            Volver al inicio
          </Link>
        </p>
      </main>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 48 48" width="20" height="20" aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.3-.4-3.5z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.6 16 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.3 34.9 26.8 36 24 36c-5.3 0-9.7-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.1-4.1 5.5l6.2 5.2C41.8 35.2 44 30 44 24c0-1.2-.1-2.3-.4-3.5z" />
    </svg>
  );
}