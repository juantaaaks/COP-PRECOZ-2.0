import type { ErrorComponentProps } from "@tanstack/react-router";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { supabase } from "@/integrations/supabase/client";
import { Toaster } from "sonner";
import { applyA11y, applyTheme, getA11y, getTheme, subscribeSettings } from "@/lib/settings";
import { OfflineBadge } from "@/components/settings-sheet";
import { InstallPrompt } from "@/components/install-prompt";
import { flushSync as flushProgressSync } from "@/lib/gamification";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "COPprecoz — Aprende a usar los pesos colombianos" },
      {
        name: "description",
        content:
          "Plataforma accesible para estudiantes neurodiversos: aprende a reconocer, contar y usar los pesos colombianos (COP) con juegos y simuladores. Funciona sin conexión y se puede instalar como app.",
      },
      { name: "author", content: "COPprecoz" },
      { name: "theme-color", content: "#f97316" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-title", content: "COPprecoz" },
      { property: "og:title", content: "COPprecoz — Aprende a usar los pesos colombianos" },
      {
        property: "og:description",
        content:
          "Plataforma accesible para estudiantes neurodiversos: aprende a reconocer, contar y usar los pesos colombianos (COP) con juegos y simuladores. Funciona sin conexión y se puede instalar como app.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "COPprecoz — Aprende a usar los pesos colombianos" },
      { name: "twitter:description", content: "Plataforma accesible para estudiantes neurodiversos: aprende a reconocer, contar y usar los pesos colombianos (COP) con juegos y simuladores. Funciona sin conexión y se puede instalar como app." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/78364264-e1c4-4865-80f8-d2cd7ac00961/id-preview-44933a49--4a5e3743-8de2-4fa3-9b0c-aaef516bc3e3.lovable.app-1785345187298.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/78364264-e1c4-4865-80f8-d2cd7ac00961/id-preview-44933a49--4a5e3743-8de2-4fa3-9b0c-aaef516bc3e3.lovable.app-1785345187298.png" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.png", type: "image/png" },
      { rel: "apple-touch-icon", href: "/apple-touch-icon.png" },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=Baloo+2:wght@600;700;800&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();
  const [settingsVersion, setSettingsVersion] = useState(0);

  // Tema claro/oscuro y refresco cuando cambian las preferencias de dinero.
  useEffect(() => {
    applyTheme(getTheme());
    applyA11y(getA11y());
    return subscribeSettings(() => setSettingsVersion((v) => v + 1));
  }, []);

  // Registra el service worker (solo en la app publicada) para que funcione sin conexión.
  useEffect(() => {
    if (!("serviceWorker" in navigator)) return;
    const h = window.location.hostname;
    const bloqueado =
      !import.meta.env.PROD ||
      window.self !== window.top ||
      h.startsWith("id-preview--") ||
      h.startsWith("preview--") ||
      h.endsWith("lovableproject.com") ||
      h.endsWith("lovableproject-dev.com") ||
      h.endsWith("beta.lovable.dev") ||
      new URL(window.location.href).searchParams.get("sw") === "off";
    if (bloqueado) {
      void navigator.serviceWorker.getRegistrations().then((rs) =>
        rs.forEach((r) => {
          if (r.active?.scriptURL.endsWith("/sw.js")) void r.unregister();
        }),
      );
      return;
    }
    const onLoad = () => void navigator.serviceWorker.register("/sw.js").catch(() => {});
    if (document.readyState === "complete") onLoad();
    else window.addEventListener("load", onLoad);
    return () => window.removeEventListener("load", onLoad);
  }, []);

  // Reintenta guardar el avance cuando vuelve la conexión.
  useEffect(() => {
    void flushProgressSync();
    const onOnline = () => void flushProgressSync();
    window.addEventListener("online", onOnline);
    return () => window.removeEventListener("online", onOnline);
  }, []);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      router.invalidate();
      if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
    });
    return () => sub.subscription.unsubscribe();
  }, [queryClient, router]);

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <div key={settingsVersion} className="contents">
        <Outlet />
      </div>
      <InstallPrompt />
      <OfflineBadge />
      <Toaster position="top-center" richColors closeButton />
    </QueryClientProvider>
  );
}
