import { useEffect, useState } from "react";
import { Flame, Medal, Target } from "lucide-react";
import {
  BADGES,
  EMPTY,
  WEEKLY_CHALLENGES,
  getGame,
  levelFromXp,
  subscribeGame,
  xpInLevel,
  type GameState,
} from "@/lib/gamification";

export function useGame(): GameState {
  const [s, setS] = useState<GameState>(EMPTY);
  useEffect(() => {
    setS(getGame());
    return subscribeGame(() => setS(getGame()));
  }, []);
  return s;
}

function Reto({
  nombre,
  desc,
  hecho,
  meta,
  premio,
}: {
  nombre: string;
  desc: string;
  hecho: number;
  meta: number;
  premio: number;
}) {
  const pct = Math.min(100, Math.round((hecho / meta) * 100));
  const listo = hecho >= meta;
  return (
    <div className={`rounded-2xl p-4 ring-1 ${listo ? "bg-accent-green/10 ring-accent-green/30" : "bg-muted/40 ring-black/5"}`}>
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3">
        <div className="min-w-0">
          <div className="truncate text-lg font-extrabold">{nombre}</div>
          <div className="text-sm text-muted-foreground">{desc}</div>
        </div>
        <div className="shrink-0 whitespace-nowrap font-mono text-base font-black">
          {Math.min(hecho, meta)}/{meta}
        </div>
      </div>
      <div className="mt-3 h-3 w-full overflow-hidden rounded-full bg-background">
        <div
          className={`h-full rounded-full ${listo ? "bg-accent-green" : "bg-primary"}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="mt-2 text-sm font-bold text-muted-foreground">
        {listo ? "¡Reto logrado!" : `Premio: ${premio} monedas`}
      </div>
    </div>
  );
}

export function LogrosSection() {
  const g = useGame();
  const nivel = levelFromXp(g.xp);
  const { actual, meta } = xpInLevel(g.xp);

  return (
    <section className="space-y-4">
      <h2 className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
        Mis logros y retos
      </h2>

      <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
          <div className="min-w-0">
            <div className="text-xl font-extrabold">Nivel {nivel}</div>
            <div className="text-base text-muted-foreground">
              {actual} de {meta} XP para el siguiente nivel
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2 rounded-2xl bg-accent-red/10 px-4 py-3 text-accent-red">
            <Flame className="size-6" />
            <span className="font-mono text-xl font-black">{g.streak}</span>
          </div>
        </div>
        <div className="mt-3 h-4 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-primary transition-all"
            style={{ width: `${Math.round((actual / meta) * 100)}%` }}
          />
        </div>
      </div>

      <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
        <div className="mb-3 flex items-center gap-2 text-base font-extrabold">
          <Target className="size-5 text-accent-blue" /> Retos de la semana
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {WEEKLY_CHALLENGES.map((c) => (
            <Reto
              key={c.id}
              nombre={c.name}
              desc={c.desc}
              hecho={g.weekly[c.key] ?? 0}
              meta={c.meta}
              premio={c.reward}
            />
          ))}
        </div>
      </div>

      <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
        <div className="mb-3 flex items-center gap-2 text-base font-extrabold">
          <Medal className="size-5 text-primary" /> Insignias ({g.badges.length}/{BADGES.length})
        </div>
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {BADGES.map((b) => {
            const ganada = g.badges.includes(b.id);
            return (
              <li
                key={b.id}
                className={`rounded-2xl p-4 text-center ring-1 ${
                  ganada ? "bg-accent-yellow/20 ring-accent-yellow/40" : "bg-muted/40 opacity-60 ring-black/5"
                }`}
              >
                <div className="text-4xl" aria-hidden>
                  {ganada ? b.emoji : "🔒"}
                </div>
                <div className="mt-2 text-base font-extrabold leading-tight">{b.name}</div>
                <div className="text-sm text-muted-foreground">{b.desc}</div>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
