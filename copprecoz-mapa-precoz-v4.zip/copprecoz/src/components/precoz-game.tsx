import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, Minus, RotateCcw, Volume2, Sparkles, Check } from "lucide-react";
import { formatCOP } from "@/lib/cop";
import {
  BillPicker,
  ChangeHelper,
  MoneyBreakdown,
  Section,
  changeSpeech,
  speak,
} from "@/components/money-ui";
import { saveModuleProgress } from "@/lib/module-progress";
import { recordActivity, mensajePositivo } from "@/lib/gamification";
import { cargarMiEquipo, equipoCache } from "@/lib/team";
import { guardarVenta, listarVentas, resumenDelDia, type ResumenDia } from "@/lib/ventas";
import { Link } from "@tanstack/react-router";
import { ClipboardList } from "lucide-react";
import hummusAsset from "@/assets/tienda/hummus.jpg.asset.json";
import limonadaAsset from "@/assets/tienda/limonada.jpg.asset.json";

const NUM_WORDS = [
  "cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve",
  "diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete",
  "dieciocho", "diecinueve", "veinte",
];

function numberWord(n: number) {
  return NUM_WORDS[n] ?? String(n);
}

type Item = {
  id: "hummus" | "limonada";
  name: string;
  singular: string;
  plural: string;
  price: number;
  img: string;
  tone: string;
};

const ITEMS: Item[] = [
  {
    id: "hummus",
    name: "Hummus",
    singular: "hummus",
    plural: "hummus",
    price: 10000,
    img: hummusAsset.url,
    tone: "bg-accent-yellow/20 ring-accent-yellow/40",
  },
  {
    id: "limonada",
    name: "Limonada cerezada",
    singular: "limonada cerezada",
    plural: "limonadas cerezadas",
    price: 3500,
    img: limonadaAsset.url,
    tone: "bg-accent-red/10 ring-accent-red/30",
  },
];

export function PrecozGame() {
  const [stock, setStock] = useState<Record<string, number>>({ hummus: 10, limonada: 12 });
  const [stockInput, setStockInput] = useState<Record<string, string>>({
    hummus: "",
    limonada: "",
  });
  const [cart, setCart] = useState<Record<string, number>>({ hummus: 0, limonada: 0 });
  const [wallet, setWallet] = useState<number[]>([]);
  const [changePicks, setChangePicks] = useState<number[]>([]);
  const [ventas, setVentas] = useState(0);
  const [equipo, setEquipo] = useState(false);
  const [nombre, setNombre] = useState("Cajero/a");
  const [resumen, setResumen] = useState<ResumenDia | null>(null);

  useEffect(() => {
    const cache = equipoCache();
    if (cache?.aprobado) {
      setEquipo(true);
      setNombre(cache.email || "Cajero/a");
    }
    void cargarMiEquipo().then(async (e) => {
      setEquipo(e.aprobado);
      if (e.solicitud?.full_name) setNombre(e.solicitud.full_name);
      else if (e.email) setNombre(e.email.split("@")[0]);
      if (e.aprobado) setResumen(resumenDelDia(await listarVentas()));
    });
  }, []);

  async function registrarVenta(recibido: number, vuelto: number) {
    await guardarVenta({
      seller_name: nombre,
      items: { ...cart },
      total,
      received: recibido,
      change_given: vuelto,
    });
    setResumen(resumenDelDia(await listarVentas()));
    toast.success("Venta guardada para el arqueo");
  }

  const total = useMemo(
    () => ITEMS.reduce((sum, it) => sum + it.price * (cart[it.id] ?? 0), 0),
    [cart],
  );
  const paid = wallet.reduce((a, b) => a + b, 0);
  const change = Math.max(0, paid - total);
  const changeGiven = changePicks.reduce((a, b) => a + b, 0);
  const enough = total > 0 && paid >= total;
  const changeOk = enough && changeGiven === change;

  function addToCart(it: Item) {
    if ((stock[it.id] ?? 0) <= 0) {
      toast.error(`No quedan ${it.plural}. Agrega más al estante.`);
      speak(`No quedan ${it.plural}`);
      return;
    }
    const next = (cart[it.id] ?? 0) + 1;
    setCart((c) => ({ ...c, [it.id]: next }));
    setStock((s) => ({ ...s, [it.id]: s[it.id] - 1 }));
    speak(`${numberWord(next)} ${next === 1 ? it.singular : it.plural}`);
  }

  function removeFromCart(it: Item) {
    if ((cart[it.id] ?? 0) <= 0) return;
    setCart((c) => ({ ...c, [it.id]: c[it.id] - 1 }));
    setStock((s) => ({ ...s, [it.id]: (s[it.id] ?? 0) + 1 }));
  }

  // El educando escribe directamente cuántas unidades hay (ej: 62).
  function aplicarStock(it: Item) {
    const raw = stockInput[it.id] ?? "";
    if (raw === "") return;
    const next = Math.max(0, Math.min(999, Number(raw)));
    setStock((s) => ({ ...s, [it.id]: next }));
    setStockInput((s) => ({ ...s, [it.id]: "" }));
    speak(`Ahora hay ${next} ${next === 1 ? it.singular : it.plural}`);
    toast.success(`${it.name}: ${next} en la tienda`);
  }

  function reset() {
    setCart({ hummus: 0, limonada: 0 });
    setWallet([]);
    setChangePicks([]);
  }

  function cobrar() {
    if (total === 0) {
      toast.error("Primero escoge productos");
      return;
    }
    if (!enough) {
      toast.error(`Falta dinero: aún faltan ${formatCOP(total - paid)}`);
      return;
    }
    if (changeGiven !== change) {
      toast.error(
        change === 0
          ? "El pago es exacto: no debes devolver nada"
          : `El vuelto debe ser ${formatCOP(change)} y escogiste ${formatCOP(changeGiven)}`,
      );
      return;
    }
    speak(change === 0 ? "Pago exacto, muy bien" : changeSpeech(change));
    toast.success(
      change === 0 ? "¡Pago exacto! Excelente." : `¡Correcto! Devolviste ${formatCOP(change)}.`,
    );
    const next = ventas + 1;
    setVentas(next);
    saveModuleProgress("precoz", Math.min(100, next * 34));
    {
      const { nuevasInsignias } = recordActivity({ xp: 80, coins: 400, keys: ["precoz", "vuelto"] });
      toast.success(mensajePositivo());
      nuevasInsignias.forEach((b) => toast.success(`${b.emoji} Nueva insignia: ${b.name}`));
    }
    if (equipo) void registrarVenta(paid, change);
    setTimeout(reset, 800);
  }

  return (
    <div className="space-y-6">
      <Section title="Productos" hint="Usa + y −">
        <div className="grid gap-4 sm:grid-cols-2">
          {ITEMS.map((it) => {
            const count = cart[it.id] ?? 0;
            const left = stock[it.id] ?? 0;
            return (
              <div
                key={it.id}
                className={`flex min-w-0 flex-col rounded-3xl bg-card p-4 ring-2 transition ${count > 0 ? "ring-primary/40 shadow-playful" : "ring-border"}`}
              >
                <div className="relative grid h-36 place-items-center rounded-2xl surface-soft sm:h-40">
                  <img
                    src={it.img}
                    alt={it.name}
                    loading="lazy"
                    width={768}
                    height={768}
                    draggable={false}
                    className="h-32 w-32 object-contain drop-shadow sm:h-36 sm:w-36"
                  />
                  <span
                    className={`absolute left-2 top-2 rounded-full bg-card px-3 py-1 text-sm font-extrabold ${left === 0 ? "text-accent-red" : "text-accent-green"}`}
                  >
                    Quedan {left}
                  </span>
                </div>
                <div className="mt-3 flex items-baseline justify-between gap-2">
                  <span className="truncate text-xl font-extrabold">{it.name}</span>
                  <span className="shrink-0 font-mono text-2xl font-black text-primary">
                    {formatCOP(it.price)}
                  </span>
                </div>
                <div className="mt-3 flex items-center gap-3">
                  <button
                    onClick={() => removeFromCart(it)}
                    disabled={count === 0}
                    aria-label={`Quitar un ${it.singular}`}
                    className="grid size-14 place-items-center rounded-2xl bg-muted text-foreground transition active:scale-95 disabled:opacity-40"
                  >
                    <Minus className="size-7" />
                  </button>
                  <div className="flex-1 text-center">
                    <div className="font-mono text-4xl font-black leading-none">{count}</div>
                    <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                      en el pedido
                    </div>
                  </div>
                  <button
                    onClick={() => addToCart(it)}
                    aria-label={`Agregar un ${it.singular}`}
                    className="grid size-14 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-playful transition active:scale-95"
                  >
                    <Plus className="size-7" />
                  </button>
                </div>
                <details className="mt-3 rounded-2xl surface-soft px-3 py-2">
                  <summary className="cursor-pointer text-sm font-bold text-muted-foreground">
                    Cambiar inventario
                  </summary>
                  <div className="mt-2 flex gap-2">
                    <input
                      id={`stock-${it.id}`}
                      aria-label="Escribe cuántos hay"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={stockInput[it.id] ?? ""}
                      onChange={(e) =>
                        setStockInput((s) => ({
                          ...s,
                          [it.id]: e.target.value.replace(/\D/g, "").slice(0, 3),
                        }))
                      }
                      onKeyDown={(e) => {
                        if (e.key === "Enter") aplicarStock(it);
                      }}
                      placeholder="62"
                      className="min-w-0 flex-1 rounded-xl border-2 border-border bg-background px-3 py-2 text-center font-mono text-2xl font-black outline-none focus:border-primary"
                    />
                    <button
                      onClick={() => aplicarStock(it)}
                      className="shrink-0 rounded-xl bg-accent-green/15 px-4 py-2 text-base font-extrabold text-accent-green active:scale-95"
                    >
                      Guardar
                    </button>
                  </div>
                </details>
              </div>
            );
          })}
        </div>
      </Section>

      <div className="sticky top-[5.5rem] z-10 rounded-3xl bg-card/95 p-4 shadow-playful ring-1 ring-primary/15 backdrop-blur sm:p-5">
        <div className="flex items-center gap-3">
          <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-primary/10 text-2xl">🛒</span>
          <div className="min-w-0 flex-1">
            <div className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">
              Total a pagar · {Object.values(cart).reduce((a, b) => a + b, 0)} productos
            </div>
            <div className="font-mono text-4xl font-black leading-none text-primary sm:text-5xl">
              {formatCOP(total)}
            </div>
          </div>
          <button
            onClick={() => speak(`El total es ${total} pesos`)}
            aria-label="Escuchar el total"
            className="grid size-14 shrink-0 place-items-center rounded-full bg-accent-blue/10 text-accent-blue active:scale-95"
          >
            <Volume2 className="size-7" />
          </button>
        </div>
        {total > 0 && (
          <div className="mt-3 rounded-2xl surface-soft p-3">
            <MoneyBreakdown value={total} />
          </div>
        )}
      </div>

      <Section title="1. ¿Con cuáles billetes pagaron?" hint="Toca los billetes">
        <div className="mb-4 flex items-center justify-between rounded-2xl bg-accent-blue/10 px-4 py-3">
          <span className="text-base font-extrabold text-accent-blue">Has seleccionado:</span>
          <span className="font-mono text-3xl font-black">{formatCOP(paid)}</span>
        </div>
        <BillPicker picks={wallet} onPick={(v) => setWallet((w) => [...w, v])} />
        <div className="mt-4 flex items-center justify-between gap-3">
          <span className={`text-lg font-extrabold ${enough && total > 0 ? "text-accent-green" : "text-muted-foreground"}`}>
            {total === 0 ? "Escoge productos" : enough ? "✓ El pago alcanza" : `Faltan ${formatCOP(total - paid)}`}
          </span>
          <button
            onClick={() => setWallet((w) => w.slice(0, -1))}
            disabled={wallet.length === 0}
            className="min-h-12 rounded-xl bg-accent-red/10 px-4 py-2 text-base font-bold text-accent-red disabled:opacity-40"
          >
            Quitar último
          </button>
        </div>
        {wallet.length > 0 && (
          <div className="mt-4 rounded-2xl surface-soft p-4">
            <MoneyBreakdown value={paid} />
          </div>
        )}
      </Section>

      <Section
        title="2. ¿Cuánto hay que devolver?"
        hint={enough ? formatCOP(change) : "Primero recibe el pago"}
      >
        {!enough ? (
          <p className="text-center text-base font-bold text-muted-foreground">
            Cuando el pago alcance, aquí escoges los billetes del vuelto.
          </p>
        ) : (
          <>
            <div className="mb-4 rounded-2xl bg-primary/5 p-4 text-center">
              <div className="text-sm font-bold uppercase tracking-widest text-muted-foreground">
                Vuelto correcto
              </div>
              <div className="font-mono text-4xl font-black text-primary">
                {formatCOP(change)}
              </div>
            </div>
            <div className="mb-4">
              <ChangeHelper value={change} />
            </div>
            <BillPicker picks={changePicks} onPick={(v) => setChangePicks((c) => [...c, v])} />
            <div className="mt-4 flex items-center justify-between gap-3">
              <span
                className={`font-mono text-2xl font-black ${changeOk ? "text-accent-green" : "text-foreground"}`}
              >
                Devuelves {formatCOP(changeGiven)}
              </span>
              <button
                onClick={() => setChangePicks((c) => c.slice(0, -1))}
                disabled={changePicks.length === 0}
                className="rounded-xl bg-accent-red/10 px-4 py-2 text-base font-bold text-accent-red disabled:opacity-40"
              >
                Quitar último
              </button>
            </div>
            {changeOk && (
              <div className="mt-3 flex items-center justify-center gap-2 text-lg font-extrabold text-accent-green">
                <Check className="size-6" /> ¡El vuelto está bien!
              </div>
            )}
          </>
        )}
      </Section>

      <div className="flex gap-3">
        <button
          onClick={reset}
          className="rounded-2xl border border-border bg-card px-5 py-6 text-lg font-bold"
        >
          <RotateCcw className="mr-2 inline size-5" /> Reiniciar
        </button>
        <button
          onClick={cobrar}
          className="flex-1 rounded-2xl bg-primary py-6 text-2xl font-black text-primary-foreground shadow-lg shadow-primary/20"
        >
          <Sparkles className="mr-2 inline size-7" /> Cobrar
        </button>
      </div>

      {equipo && resumen && (
        <div className="rounded-3xl bg-card p-5 shadow-sm ring-2 ring-accent-green/30">
          <div className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
            Ventas de hoy (equipo Cooprecoz)
          </div>
          <div className="mt-2 grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-xs font-bold text-muted-foreground">Ventas</div>
              <div className="font-mono text-2xl font-black">{resumen.cantidad}</div>
            </div>
            <div>
              <div className="text-xs font-bold text-muted-foreground">Se vendió</div>
              <div className="font-mono text-2xl font-black text-accent-green">
                {formatCOP(resumen.vendido)}
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-muted-foreground">Se devolvió</div>
              <div className="font-mono text-2xl font-black text-accent-red">
                {formatCOP(resumen.devuelto)}
              </div>
            </div>
          </div>
          <Link
            to="/arqueo"
            className="mt-4 flex items-center justify-center gap-2 rounded-2xl bg-accent-green/15 py-4 text-lg font-extrabold text-accent-green active:scale-95"
          >
            <ClipboardList className="size-6" /> Arquear la caja con estas ventas
          </Link>
          <p className="mt-2 text-center text-sm text-muted-foreground">
            Es opcional: puedes seguir vendiendo y arquear cuando quieras.
          </p>
        </div>
      )}

      {ventas > 0 && (
        <p className="text-center text-base font-bold text-muted-foreground">
          Ventas completadas: {ventas}
        </p>
      )}
    </div>
  );
}
