import { RotateCw, Trophy, Volume2 } from "lucide-react";
import { useState } from "react";
import { COP_DENOMINATIONS, COP_IMAGES, breakdownCOP, formatCOP, type Denomination } from "@/lib/cop";
import { useBackImages } from "@/lib/cop-back";
import { getA11y, moneyWords } from "@/lib/settings";

export function speak(text: string) {
  try {
    const a = getA11y();
    if (!a.readAloud || !a.sounds) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "es-CO";
    u.rate = a.speechRate;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  } catch {
    // ignore
  }
}

/**
 * Imagen de un billete o moneda. Al hacer clic muestra el reverso
 * (si el desarrollador ya cargó la imagen de atrás en /reversos).
 */
export function MoneyImage({
  value,
  alt,
  className,
  flippable = true,
}: {
  value: number;
  alt: string;
  className?: string;
  flippable?: boolean;
}) {
  const backs = useBackImages();
  const [back, setBack] = useState(false);
  const backSrc = backs[value];
  const canFlip = flippable && Boolean(backSrc);
  const showBack = canFlip && back;

  return (
    <span className="relative inline-block">
      <img
        src={showBack ? backSrc : COP_IMAGES[value]}
        alt={showBack ? `${alt} (parte de atrás)` : alt}
        loading="lazy"
        draggable={false}
        onClick={
          canFlip
            ? (e) => {
                e.stopPropagation();
                setBack((b) => !b);
              }
            : undefined
        }
        className={`${className ?? ""} ${canFlip ? "cursor-pointer transition-transform hover:scale-105 active:scale-95" : ""}`}
      />
      {canFlip && (
        <span className="pointer-events-none absolute -bottom-1 -right-1 grid size-6 place-items-center rounded-full bg-accent-blue text-primary-foreground shadow">
          <RotateCw className="size-3.5" />
        </span>
      )}
    </span>
  );
}

export function DenomVisual({ d, size = "md" }: { d: Denomination; size?: "sm" | "md" | "lg" }) {
  const isBill = d.type === "billete";
  const dims =
    size === "lg"
      ? isBill
        ? "h-48 w-80 sm:h-56 sm:w-96"
        : "size-44 sm:size-52"
      : size === "sm"
        ? isBill
          ? "h-20 w-36"
          : "size-20"
        : isBill
          ? "h-32 w-52"
          : "size-28";
  return (
    <MoneyImage
      value={d.value}
      alt={`${isBill ? "Billete" : "Moneda"} de ${d.name}`}
      className={`${dims} rounded-xl object-contain drop-shadow-lg select-none`}
    />
  );
}


export function ProgressBar({ value }: { value: number }) {
  return (
    <div className="h-5 w-full overflow-hidden rounded-full bg-muted">
      <div
        className="h-full rounded-full bg-primary transition-all"
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

export function Section({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
      <div className="mb-4 flex items-baseline justify-between gap-3">
        <h2 className="text-base font-extrabold uppercase tracking-widest text-muted-foreground">
          {title}
        </h2>
        {hint && <span className="text-sm text-muted-foreground">{hint}</span>}
      </div>
      {children}
    </section>
  );
}

export function MoneyBreakdown({ value }: { value: number }) {
  const parts = breakdownCOP(value);
  if (parts.length === 0) {
    return (
      <p className="text-center text-base font-bold text-muted-foreground">
        Escribe o suma dinero para ver los billetes y monedas
      </p>
    );
  }
  return (
    <div className="flex flex-wrap items-end justify-center gap-3">
      {parts.map((p) => {
        const isBill = p.value >= 2000;
        return (
          <div key={p.value} className="flex flex-col items-center gap-1">
            <div className="relative">
              <MoneyImage
                value={p.value}
                alt={`${p.count} de ${p.value.toLocaleString("es-CO")} pesos`}
                className={`${isBill ? "h-16 w-28" : "size-16"} rounded-lg object-contain drop-shadow`}
              />

              {p.count > 1 && (
                <span className="absolute -right-2 -top-2 grid size-8 place-items-center rounded-full bg-primary font-mono text-sm font-black text-primary-foreground shadow">
                  ×{p.count}
                </span>
              )}
            </div>
            <span className="font-mono text-sm font-bold text-muted-foreground">
              {formatCOP(p.value)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function denomName(value: number) {
  return COP_DENOMINATIONS.find((d) => d.value === value);
}

// Frase hablada: "Devuelve 1 billete de 5 mil y 2 monedas de 100".
export function changeSpeech(value: number): string {
  const parts = breakdownCOP(value);
  if (parts.length === 0) return "No debes devolver nada, el pago es exacto";
  const frases = parts.map((p) => {
    const d = denomName(p.value);
    const tipo = d?.type === "billete" ? "billete" : "moneda";
    const plural = p.count > 1 ? (tipo === "billete" ? "billetes" : "monedas") : tipo;
    return `${p.count} ${plural} de ${moneyWords(p.value)}`;
  });
  const last = frases.pop();
  return `Devuelve ${frases.length ? `${frases.join(", ")} y ${last}` : last}`;
}

// Muestra con imágenes exactamente qué billetes y monedas hay que devolver.
export function ChangeHelper({ value }: { value: number }) {
  return (
    <div className="rounded-2xl bg-accent-green/10 p-4">
      <div className="text-center text-sm font-bold uppercase tracking-widest text-muted-foreground">
        Debes devolver
      </div>
      <div className="mt-3">
        {value === 0 ? (
          <p className="text-center text-lg font-extrabold text-accent-green">
            Nada: el pago es exacto
          </p>
        ) : (
          <MoneyBreakdown value={value} />
        )}
      </div>
      <button
        onClick={() => speak(changeSpeech(value))}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-accent-blue/10 py-4 text-lg font-bold text-accent-blue"
      >
        <Volume2 className="size-6" /> Escuchar el vuelto
      </button>
    </div>
  );
}

export function Confetti({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <div className="pointer-events-none fixed inset-0 z-50 grid place-items-center">
      <div className="animate-slide-up rounded-3xl bg-card px-8 py-6 text-center shadow-2xl ring-1 ring-black/10">
        <Trophy className="mx-auto size-10 text-primary" />
        <div className="mt-2 text-xl font-extrabold">¡Muy bien!</div>
        <div className="text-sm text-muted-foreground">Ganaste XP y monedas</div>
      </div>
    </div>
  );
}

// Selector de billetes y monedas, compartido por los simuladores.
export function BillPicker({
  picks,
  onPick,
  min = 100,
}: {
  picks: number[];
  onPick: (v: number) => void;
  min?: number;
}) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
      {COP_DENOMINATIONS.filter((d) => d.value >= min).map((d) => {
        const used = picks.filter((p) => p === d.value).length;
        return (
          <button
            key={d.value}
            onClick={() => onPick(d.value)}
            className={`relative flex flex-col items-center gap-2 rounded-2xl p-3 ring-2 transition duration-300 hover:-translate-y-0.5 active:scale-95 ${
              used > 0 ? "bg-primary/10 ring-primary shadow-playful" : "bg-card ring-border hover:ring-primary/30"
            }`}
            aria-label={`Escoger ${d.name}`}
            aria-pressed={used > 0}
          >
            <span className="grid h-20 w-full place-items-center sm:h-24">
              <img
                src={COP_IMAGES[d.value]}
                alt={d.name}
                loading="lazy"
                draggable={false}
                className={`${d.type === "billete" ? "h-16 w-28 sm:h-20 sm:w-36" : "size-16 sm:size-20"} rounded-lg object-contain drop-shadow`}
              />
            </span>
            <span className="font-mono text-lg font-black sm:text-xl">
              ${d.value.toLocaleString("es-CO")}
            </span>
            {used > 0 && (
              <span className="absolute right-2 top-2 flex animate-pop items-center gap-0.5 rounded-full bg-primary px-2 py-0.5 font-mono text-sm font-black text-primary-foreground shadow">
                ✓{used > 1 ? ` ×${used}` : ""}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

