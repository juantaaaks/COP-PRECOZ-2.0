import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Lock, ShieldCheck, Clock } from "lucide-react";
import { cargarMiEquipo, equipoCache, type MiEquipo } from "@/lib/team";
import { isGuest } from "@/lib/guest";

/** Protege Calculadora Precoz y Arqueo: solo el equipo Cooprecoz aprobado. */
export function TeamGate({ children, titulo }: { children: ReactNode; titulo: string }) {
  const [estado, setEstado] = useState<MiEquipo | null>(null);
  const [cargando, setCargando] = useState(true);
  const invitado = typeof window !== "undefined" && isGuest();

  useEffect(() => {
    setEstado(equipoCache());
    if (invitado) {
      setCargando(false);
      return;
    }
    void cargarMiEquipo().then((e) => {
      setEstado(e);
      setCargando(false);
    });
  }, [invitado]);

  if (cargando && !estado) {
    return (
      <div className="rounded-3xl bg-card p-8 text-center text-lg font-bold text-muted-foreground ring-1 ring-black/5">
        Revisando tu acceso…
      </div>
    );
  }

  if (estado?.aprobado) return <>{children}</>;

  const pendiente = estado?.solicitud?.status === "pendiente";

  return (
    <div className="rounded-3xl bg-card p-7 text-center shadow-sm ring-2 ring-primary/20">
      <div className="mx-auto grid size-16 place-items-center rounded-2xl bg-primary/10 text-primary">
        {pendiente ? <Clock className="size-8" /> : <Lock className="size-8" />}
      </div>
      <h2 className="mt-4 text-2xl font-extrabold">{titulo} es del equipo Cooprecoz</h2>
      <p className="mx-auto mt-2 max-w-md text-lg text-muted-foreground">
        {invitado
          ? "Entra con tu cuenta del colegio y pide acceso al maestro líder o al gerente de Cooprecoz."
          : pendiente
            ? "Ya enviaste tu solicitud. El maestro líder o el gerente debe aprobarla."
            : "Pide acceso al maestro líder o al gerente de Cooprecoz para usar esta herramienta."}
      </p>
      <Link
        to="/equipo"
        className="mt-5 inline-flex items-center gap-2 rounded-2xl bg-primary px-6 py-4 text-lg font-extrabold text-primary-foreground active:scale-95"
      >
        <ShieldCheck className="size-6" /> Ir a Equipo Cooprecoz
      </Link>
    </div>
  );
}
