import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Check, Flame, PiggyBank, RotateCcw, Sparkles, Timer, Trophy, Volume2 } from "lucide-react";
import {
  BillPicker,
  MoneyBreakdown,
  MoneyImage,
  ProgressBar,
  Section,
  speak,
} from "@/components/money-ui";
import { formatCOP } from "@/lib/cop";
import { saveModuleProgress } from "@/lib/module-progress";
import { recordActivity, mensajePositivo } from "@/lib/gamification";

/* ---------------- Datos del juego ---------------- */

type Opcion = { texto: string; emoji?: string; money?: number; ok: boolean };

type Mision =
  | {
      tipo: "quiz";
      id: string;
      titulo: string;
      emoji: string;
      pasos: string[];
      pregunta: string;
      opciones: Opcion[];
    }
  | {
      tipo: "clasificar";
      id: string;
      titulo: string;
      emoji: string;
      pasos: string[];
      cartas: { texto: string; emoji: string; necesidad: boolean }[];
    }
  | {
      tipo: "ahorro";
      id: string;
      titulo: string;
      emoji: string;
      pasos: string[];
      meta: number;
      premio: { texto: string; emoji: string };
    }
  | {
      tipo: "reto";
      id: string;
      titulo: string;
      emoji: string;
      pasos: string[];
      segundos: number;
    };

const MISIONES: Mision[] = [
  {
    tipo: "quiz",
    id: "ahorro",
    titulo: "El ahorro",
    emoji: "🐷",
    pasos: [
      "Ahorrar es guardar un poquito de dinero para después.",
      "Si cada día guardas 1.000 pesos, en una semana tienes 7.000 pesos.",
      "Guarda tu ahorro en la alcancía o en el banco.",
    ],
    pregunta: "¿Qué es ahorrar?",
    opciones: [
      { texto: "Guardar dinero para después", emoji: "🐷", ok: true },
      { texto: "Gastar todo hoy", emoji: "🛍️", ok: false },
    ],
  },
  {
    tipo: "ahorro",
    id: "alcancia",
    titulo: "Llena la alcancía",
    emoji: "🏦",
    pasos: [
      "Vamos a ahorrar para comprar unos audífonos.",
      "Toca los billetes y monedas hasta llegar a la meta.",
      "Si te pasas, puedes quitar el último.",
    ],
    meta: 25000,
    premio: { texto: "Audífonos", emoji: "🎧" },
  },
  {
    tipo: "quiz",
    id: "presupuesto",
    titulo: "Mi presupuesto",
    emoji: "🧾",
    pasos: [
      "Un presupuesto es un plan de tu dinero.",
      "Escribe cuánto tienes, cuánto gastas y cuánto ahorras.",
      `Ejemplo: tengo ${formatCOP(20000)}, gasto ${formatCOP(15000)} y ahorro ${formatCOP(5000)}.`,
    ],
    pregunta: "Tengo 20.000 y gasto 15.000. ¿Cuánto puedo ahorrar?",
    opciones: [
      { texto: "5.000 pesos", money: 5000, ok: true },
      { texto: "20.000 pesos", money: 20000, ok: false },
      { texto: "10.000 pesos", money: 10000, ok: false },
    ],
  },
  {
    tipo: "clasificar",
    id: "necesidad",
    titulo: "Necesidad o deseo",
    emoji: "⚖️",
    pasos: [
      "Una necesidad es algo que sí o sí necesito: comida, transporte, salud.",
      "Un deseo es algo que quiero, pero puede esperar.",
      "Primero pago las necesidades y después los deseos.",
    ],
    cartas: [
      { texto: "Almuerzo", emoji: "🍽️", necesidad: true },
      { texto: "Videojuego", emoji: "🎮", necesidad: false },
      { texto: "Bus al colegio", emoji: "🚌", necesidad: true },
      { texto: "Dulces", emoji: "🍬", necesidad: false },
      { texto: "Medicinas", emoji: "💊", necesidad: true },
      { texto: "Peluche", emoji: "🧸", necesidad: false },
    ],
  },
  {
    tipo: "quiz",
    id: "pagos",
    titulo: "Formas de pagar",
    emoji: "💳",
    pasos: [
      "Puedes pagar con efectivo: billetes y monedas.",
      "También con tarjeta débito: usa el dinero que ya tienes.",
      "O con el celular (Nequi, Daviplata).",
    ],
    pregunta: "Si pagas con billetes y monedas, pagas con…",
    opciones: [
      { texto: "Efectivo", emoji: "💵", ok: true },
      { texto: "Tarjeta", emoji: "💳", ok: false },
      { texto: "Celular", emoji: "📱", ok: false },
    ],
  },
  {
    tipo: "quiz",
    id: "compras",
    titulo: "Compras responsables",
    emoji: "🛒",
    pasos: [
      "Antes de comprar pregúntate: ¿lo necesito?",
      "Compara precios en otras tiendas.",
      "Revisa el vuelto antes de irte de la caja.",
    ],
    pregunta: "¿Qué haces antes de salir de la tienda?",
    opciones: [
      { texto: "Contar el vuelto", emoji: "🔎", ok: true },
      { texto: "Salir corriendo", emoji: "🏃", ok: false },
    ],
  },
  {
    tipo: "reto",
    id: "reto-rapido",
    titulo: "Reto rápido",
    emoji: "⚡",
    pasos: [
      "Vas a responder muchas preguntas cortas de dinero.",
      "Tienes un tiempo: ¡suma tantos puntos como puedas!",
      "Si te equivocas no pasa nada, sigue intentando.",
    ],
    segundos: 45,
  },
];

/* ---------------- Componente principal ---------------- */

export function FinanzasGame() {
  const [i, setI] = useState(0);
  const [hechos, setHechos] = useState<string[]>([]);
  const [puntos, setPuntos] = useState(0);
  const [combo, setCombo] = useState(0);
  const [celebra, setCelebra] = useState(false);
  const m = MISIONES[i];
  const percent = Math.round((hechos.length / MISIONES.length) * 100);
  const terminado = hechos.length === MISIONES.length;

  function acierto(p = 10) {
    setCombo((c) => c + 1);
    setPuntos((v) => v + p + combo * 2);
  }

  function fallo() {
    setCombo(0);
  }

  function completar(id: string) {
    setCelebra(true);
    setTimeout(() => setCelebra(false), 1200);
    if (!hechos.includes(id)) {
      const next = [...hechos, id];
      setHechos(next);
      saveModuleProgress("finanzas", Math.round((next.length / MISIONES.length) * 100));
      const { nuevasInsignias } = recordActivity({ xp: 80, coins: 300, keys: ["finanzas"] });
      toast.success(mensajePositivo());
      nuevasInsignias.forEach((b) => toast.success(`${b.emoji} Nueva insignia: ${b.name}`));
    }
    setTimeout(() => setI((n) => Math.min(MISIONES.length - 1, n + 1)), 700);
  }

  return (
    <div className="space-y-5">
      <div className="relative overflow-hidden rounded-3xl bg-hero-animated p-5 text-primary-foreground shadow-lg shadow-primary/25 sm:p-6">
        {celebra && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center text-7xl animate-pop">
            🎉
          </div>
        )}
        <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest opacity-90">
          <PiggyBank className="size-5" /> Educación financiera
        </div>
        <h2 className="mt-1 text-2xl font-extrabold sm:text-3xl">Cuido mi dinero</h2>
        <p className="mt-1 text-base opacity-90">
          Misión {i + 1} de {MISIONES.length} · {hechos.length} completadas
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <span className="flex items-center gap-2 rounded-2xl bg-white/20 px-3 py-2 font-mono text-lg font-black">
            <Trophy className="size-5" /> {puntos} pts
          </span>
          <span className="flex items-center gap-2 rounded-2xl bg-white/20 px-3 py-2 font-mono text-lg font-black">
            <Flame className="size-5" /> x{combo}
          </span>
        </div>
        <div className="mt-4">
          <ProgressBar value={percent} />
        </div>
      </div>

      {/* Mapa de misiones con imágenes */}
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
        {MISIONES.map((mm, idx) => {
          const done = hechos.includes(mm.id);
          const activa = idx === i;
          return (
            <button
              key={mm.id}
              onClick={() => setI(idx)}
              aria-label={`Ir a ${mm.titulo}`}
              className={`flex flex-col items-center gap-1 rounded-2xl p-3 text-center transition active:scale-95 ${
                activa
                  ? "bg-primary/15 ring-2 ring-primary"
                  : done
                    ? "bg-accent-green/15 ring-1 ring-accent-green/40"
                    : "bg-muted/40 ring-1 ring-black/5"
              }`}
            >
              <span className="text-3xl">{done ? "✅" : mm.emoji}</span>
              <span className="text-xs font-bold leading-tight">{mm.titulo}</span>
            </button>
          );
        })}
      </div>

      <Section title={`${m.emoji} ${m.titulo}`} hint={hechos.includes(m.id) ? "Listo ✅" : undefined}>
        <ol className="space-y-3">
          {m.pasos.map((p, idx) => (
            <li key={idx} className="flex items-start gap-3 rounded-2xl bg-muted/30 p-4">
              <span className="grid size-10 shrink-0 place-items-center rounded-full bg-primary font-mono text-lg font-black text-primary-foreground">
                {idx + 1}
              </span>
              <span className="text-lg leading-relaxed">{p}</span>
            </li>
          ))}
        </ol>
        <button
          onClick={() => speak(`${m.titulo}. ${m.pasos.join(" ")}`)}
          className="mt-4 flex min-h-14 w-full items-center justify-center gap-2 rounded-2xl bg-accent-blue/10 py-4 text-lg font-bold text-accent-blue"
        >
          <Volume2 className="size-6" /> Escuchar el tema
        </button>
      </Section>

      {m.tipo === "quiz" && (
        <QuizMision key={m.id} m={m} onOk={() => completar(m.id)} onAcierto={acierto} onFallo={fallo} />
      )}
      {m.tipo === "clasificar" && (
        <ClasificarMision key={m.id} m={m} onOk={() => completar(m.id)} onAcierto={acierto} onFallo={fallo} />
      )}
      {m.tipo === "ahorro" && (
        <AhorroMision key={m.id} m={m} onOk={() => completar(m.id)} onAcierto={acierto} />
      )}
      {m.tipo === "reto" && (
        <RetoMision key={m.id} m={m} onOk={() => completar(m.id)} onAcierto={acierto} onFallo={fallo} />
      )}

      {terminado && (
        <div className="rounded-3xl bg-accent-green/10 p-6 text-center">
          <div className="text-6xl">🏆</div>
          <p className="mt-2 text-xl font-extrabold text-accent-green">
            ¡Terminaste todas las misiones de Cuido mi dinero!
          </p>
        </div>
      )}
    </div>
  );
}

/* ---------------- Mini juego: quiz con imágenes ---------------- */

function QuizMision({
  m,
  onOk,
  onAcierto,
  onFallo,
}: {
  m: Extract<Mision, { tipo: "quiz" }>;
  onOk: () => void;
  onAcierto: (p?: number) => void;
  onFallo: () => void;
}) {
  const [elegida, setElegida] = useState<string | null>(null);

  function responder(o: Opcion) {
    setElegida(o.texto);
    if (!o.ok) {
      onFallo();
      toast.error("Casi. Lee otra vez los pasos y prueba de nuevo.");
      speak("Casi. Lee otra vez y prueba de nuevo.");
      setTimeout(() => setElegida(null), 900);
      return;
    }
    onAcierto(15);
    speak("¡Correcto!");
    onOk();
  }

  return (
    <Section title="Pregunta">
      <p className="text-xl font-extrabold">{m.pregunta}</p>
      <button
        onClick={() => speak(m.pregunta)}
        className="mt-2 text-base font-bold text-accent-blue"
      >
        🔊 Escuchar la pregunta
      </button>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {m.opciones.map((o) => {
          const sel = elegida === o.texto;
          return (
            <button
              key={o.texto}
              onClick={() => responder(o)}
              className={`flex min-h-20 items-center gap-3 rounded-2xl px-4 py-4 text-left text-lg font-extrabold ring-1 transition hover:-translate-y-0.5 active:scale-95 ${
                sel && o.ok
                  ? "bg-accent-green/20 ring-accent-green/50"
                  : sel
                    ? "bg-accent-red/15 ring-accent-red/40"
                    : "bg-muted/40 ring-black/5"
              }`}
            >
              {o.money ? (
                <MoneyImage
                  value={o.money}
                  alt={`Billete de ${o.money} pesos`}
                  className="h-14 w-24 shrink-0 rounded-lg object-contain"
                />
              ) : (
                <span className="text-4xl">{o.emoji}</span>
              )}
              <span className="min-w-0">{o.texto}</span>
            </button>
          );
        })}
      </div>
    </Section>
  );
}

/* ---------------- Mini juego: necesidad o deseo ---------------- */

function ClasificarMision({
  m,
  onOk,
  onAcierto,
  onFallo,
}: {
  m: Extract<Mision, { tipo: "clasificar" }>;
  onOk: () => void;
  onAcierto: (p?: number) => void;
  onFallo: () => void;
}) {
  const cartas = useMemo(() => [...m.cartas].sort(() => Math.random() - 0.5), [m]);
  const [idx, setIdx] = useState(0);
  const [aciertos, setAciertos] = useState(0);
  const carta = cartas[idx];
  const fin = idx >= cartas.length;

  function clasificar(necesidad: boolean) {
    if (!carta) return;
    if (necesidad === carta.necesidad) {
      onAcierto(10);
      speak("¡Muy bien!");
      setAciertos((a) => a + 1);
      const siguiente = idx + 1;
      setIdx(siguiente);
      if (siguiente >= cartas.length) onOk();
    } else {
      onFallo();
      toast.error(
        carta.necesidad
          ? `${carta.texto} sí es una necesidad`
          : `${carta.texto} es un deseo, puede esperar`,
      );
      speak(carta.necesidad ? "Es una necesidad" : "Es un deseo");
    }
  }

  return (
    <Section title="Clasifica" hint={`${aciertos} de ${cartas.length}`}>
      {fin ? (
        <div className="rounded-2xl bg-accent-green/10 p-6 text-center text-xl font-extrabold text-accent-green">
          <Check className="mx-auto mb-2 size-10" /> ¡Clasificaste todas!
        </div>
      ) : (
        <>
          <div className="grid place-items-center rounded-3xl bg-muted/40 p-8">
            <span className="text-8xl">{carta.emoji}</span>
            <span className="mt-2 text-2xl font-extrabold">{carta.texto}</span>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <button
              onClick={() => clasificar(true)}
              className="min-h-20 rounded-2xl bg-accent-green/15 text-xl font-black text-accent-green ring-1 ring-accent-green/40 active:scale-95"
            >
              ✅ Necesidad
            </button>
            <button
              onClick={() => clasificar(false)}
              className="min-h-20 rounded-2xl bg-accent-blue/10 text-xl font-black text-accent-blue ring-1 ring-accent-blue/30 active:scale-95"
            >
              ⭐ Deseo
            </button>
          </div>
          <div className="mt-4">
            <ProgressBar value={(idx / cartas.length) * 100} />
          </div>
        </>
      )}
    </Section>
  );
}

/* ---------------- Mini juego: llena la alcancía ---------------- */

function AhorroMision({
  m,
  onOk,
  onAcierto,
}: {
  m: Extract<Mision, { tipo: "ahorro" }>;
  onOk: () => void;
  onAcierto: (p?: number) => void;
}) {
  const [picks, setPicks] = useState<number[]>([]);
  const total = picks.reduce((a, b) => a + b, 0);
  const falta = m.meta - total;
  const logrado = total === m.meta;

  return (
    <Section title="Llena la alcancía" hint={`Meta: ${formatCOP(m.meta)}`}>
      <div className="grid place-items-center rounded-3xl bg-accent-yellow/15 p-6 text-center">
        <span className="text-7xl">{logrado ? "🎉" : "🐷"}</span>
        <span className="mt-2 text-lg font-bold text-muted-foreground">
          Ahorras para: {m.premio.emoji} {m.premio.texto}
        </span>
        <span className="font-mono text-4xl font-black text-primary">{formatCOP(total)}</span>
        <div className="mt-3 w-full">
          <ProgressBar value={(total / m.meta) * 100} />
        </div>
        <p className="mt-3 text-lg font-extrabold">
          {logrado
            ? "¡Llegaste a la meta!"
            : falta > 0
              ? `Te faltan ${formatCOP(falta)}`
              : `Te pasaste por ${formatCOP(-falta)}`}
        </p>
      </div>

      {picks.length > 0 && (
        <div className="mt-4 rounded-2xl bg-muted/30 p-4">
          <MoneyBreakdown value={total} />
        </div>
      )}

      <div className="mt-4">
        <BillPicker
          picks={picks}
          onPick={(v) => {
            setPicks((p) => [...p, v]);
            speak(`${v.toLocaleString("es-CO")} pesos`);
          }}
        />
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <button
          onClick={() => setPicks([])}
          className="min-h-14 rounded-2xl bg-accent-red/10 text-lg font-extrabold text-accent-red active:scale-95"
        >
          <RotateCcw className="mr-2 inline size-5" /> Vaciar
        </button>
        <button
          onClick={() => {
            if (!logrado) {
              toast.error(
                falta > 0 ? `Aún faltan ${formatCOP(falta)}` : "Te pasaste, quita dinero",
              );
              return;
            }
            speak("¡Lograste tu meta de ahorro!");
            onAcierto(25);
            onOk();
          }}
          className="min-h-14 rounded-2xl bg-primary text-lg font-black text-primary-foreground shadow active:scale-95"
        >
          <Sparkles className="mr-2 inline size-5" /> Guardar ahorro
        </button>
      </div>
    </Section>
  );
}

/* ---------------- Mini juego: reto rápido con cronómetro ---------------- */

type Pregunta = { texto: string; opciones: number[]; correcta: number };

function nuevaPregunta(): Pregunta {
  const valores = [1000, 2000, 5000, 10000, 20000];
  const a = valores[Math.floor(Math.random() * valores.length)];
  const b = valores[Math.floor(Math.random() * valores.length)];
  const suma = Math.random() > 0.5;
  const correcta = suma ? a + b : Math.abs(a - b);
  const opciones = new Set<number>([correcta]);
  while (opciones.size < 3) {
    const delta = [1000, 2000, 5000, 10000][Math.floor(Math.random() * 4)];
    const alt = Math.random() > 0.5 ? correcta + delta : Math.max(500, correcta - delta);
    if (alt !== correcta) opciones.add(alt);
  }
  return {
    texto: suma
      ? `Tienes ${formatCOP(a)} y te dan ${formatCOP(b)}. ¿Cuánto tienes?`
      : `Tienes ${formatCOP(Math.max(a, b))} y gastas ${formatCOP(Math.min(a, b))}. ¿Cuánto te queda?`,
    opciones: [...opciones].sort(() => Math.random() - 0.5),
    correcta,
  };
}

function RetoMision({
  m,
  onOk,
  onAcierto,
  onFallo,
}: {
  m: Extract<Mision, { tipo: "reto" }>;
  onOk: () => void;
  onAcierto: (p?: number) => void;
  onFallo: () => void;
}) {
  const [jugando, setJugando] = useState(false);
  const [seg, setSeg] = useState(m.segundos);
  const [aciertos, setAciertos] = useState(0);
  const [q, setQ] = useState<Pregunta>(() => nuevaPregunta());
  const finRef = useRef(false);

  useEffect(() => {
    if (!jugando) return;
    const t = setInterval(() => {
      setSeg((s) => {
        if (s <= 1) {
          clearInterval(t);
          setJugando(false);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [jugando]);

  useEffect(() => {
    if (!jugando && seg === 0 && !finRef.current) {
      finRef.current = true;
      speak(`Se acabó el tiempo. Lograste ${aciertos} respuestas correctas.`);
      if (aciertos > 0) onOk();
    }
  }, [jugando, seg, aciertos, onOk]);

  function responder(v: number) {
    if (v === q.correcta) {
      onAcierto(20);
      setAciertos((a) => a + 1);
      speak("¡Correcto!");
      setQ(nuevaPregunta());
    } else {
      onFallo();
      toast.error(`Era ${formatCOP(q.correcta)}`);
    }
  }

  return (
    <Section title="Reto rápido" hint={`${aciertos} correctas`}>
      {!jugando && seg === m.segundos ? (
        <button
          onClick={() => setJugando(true)}
          className="min-h-20 w-full rounded-2xl bg-primary text-2xl font-black text-primary-foreground shadow active:scale-95"
        >
          ⚡ ¡Empezar el reto!
        </button>
      ) : (
        <>
          <div className="flex items-center justify-between rounded-2xl bg-accent-yellow/20 px-4 py-3">
            <span className="flex items-center gap-2 text-lg font-extrabold text-primary">
              <Timer className="size-6" /> {seg}s
            </span>
            <span className="font-mono text-xl font-black text-primary">{aciertos} ✅</span>
          </div>
          {seg > 0 ? (
            <>
              <p className="mt-4 text-xl font-extrabold">{q.texto}</p>
              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                {q.opciones.map((o) => (
                  <button
                    key={o}
                    onClick={() => responder(o)}
                    className="min-h-20 rounded-2xl bg-muted/50 font-mono text-2xl font-black ring-1 ring-black/5 transition hover:-translate-y-0.5 active:scale-95"
                  >
                    {formatCOP(o)}
                  </button>
                ))}
              </div>
            </>
          ) : (
            <div className="mt-4 rounded-2xl bg-accent-green/10 p-6 text-center">
              <div className="text-6xl animate-pop">🏁</div>
              <p className="mt-2 text-xl font-extrabold text-accent-green">
                ¡Lograste {aciertos} respuestas correctas!
              </p>
              <button
                onClick={() => {
                  finRef.current = false;
                  setAciertos(0);
                  setSeg(m.segundos);
                  setQ(nuevaPregunta());
                }}
                className="mt-4 min-h-14 w-full rounded-2xl bg-primary text-lg font-black text-primary-foreground active:scale-95"
              >
                Jugar otra vez
              </button>
            </div>
          )}
        </>
      )}
    </Section>
  );
}
