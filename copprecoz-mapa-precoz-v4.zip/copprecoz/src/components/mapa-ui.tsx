import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Check, Volume2, Wallet, X } from "lucide-react";
import { COP_DENOMINATIONS, COP_IMAGES, formatCOP } from "@/lib/cop";
import { MoneyBreakdown, speak } from "@/components/money-ui";
import { agrupar, billeteQueSobra, fechaRecibo, opcionesVuelto, totalDe } from "@/lib/mapa";
import { mensajePositivo } from "@/lib/gamification";

function esBillete(v: number) {
  return v >= 2000;
}

function nombreDenom(v: number) {
  const d = COP_DENOMINATIONS.find((x) => x.value === v);
  return `${d?.type === "billete" ? "billete" : "moneda"} de ${v.toLocaleString("es-CO")}`;
}

/* --------------------------------- Pasos --------------------------------- */

export function Pasos({ pasos, actual }: { pasos: string[]; actual: number }) {
  return (
    <ol className="flex flex-wrap items-center gap-2" aria-label="Pasos de la misión">
      {pasos.map((p, i) => {
        const hecho = i < actual;
        const ahora = i === actual;
        return (
          <li
            key={p}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-extrabold ring-1 ${
              hecho
                ? "bg-accent-green/15 text-accent-green ring-accent-green/30"
                : ahora
                  ? "bg-primary text-primary-foreground ring-primary"
                  : "bg-muted/50 text-muted-foreground ring-border"
            }`}
            aria-current={ahora ? "step" : undefined}
          >
            {hecho ? <Check className="size-4" /> : <span className="font-mono">{i + 1}</span>}
            {p}
          </li>
        );
      })}
    </ol>
  );
}

/* ------------------------------- Billetera ------------------------------- */

export function BilleteraResumen({ bills }: { bills: number[] }) {
  const grupos = agrupar(bills);
  return (
    <div className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border/70">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-base font-extrabold">
          <Wallet className="size-5 text-accent-green" /> Mi cartera
        </div>
        <div className="font-mono text-2xl font-black text-accent-green">
          {formatCOP(totalDe(bills))}
        </div>
      </div>
      {grupos.length > 0 ? (
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {grupos.map((g) => (
            <div key={g.value} className="relative shrink-0">
              <img
                src={COP_IMAGES[g.value]}
                alt={`${g.count} ${nombreDenom(g.value)}`}
                className={`${esBillete(g.value) ? "h-10 w-[4.5rem]" : "size-10"} rounded-md object-contain`}
                draggable={false}
              />
              {g.count > 1 && (
                <span className="absolute -right-1.5 -top-1.5 grid size-6 place-items-center rounded-full bg-primary font-mono text-xs font-black text-primary-foreground">
                  ×{g.count}
                </span>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="mt-2 text-sm font-bold text-muted-foreground">
          Está vacía. Ve a COOPRECOZ a trabajar para ganar dinero.
        </p>
      )}
    </div>
  );
}

/* --------------------------- Pagar con la billetera --------------------------- */

export function PagarConBilletera({
  precio,
  billetera,
  titulo = "Paga con tu cartera",
  onPagado,
}: {
  precio: number;
  billetera: number[];
  titulo?: string;
  onPagado: (entregados: number[]) => void;
}) {
  const [mano, setMano] = useState<number[]>([]);
  const disponibles = useMemo(() => {
    const rest = [...billetera];
    for (const m of mano) {
      const i = rest.indexOf(m);
      if (i >= 0) rest.splice(i, 1);
    }
    return agrupar(rest);
  }, [billetera, mano]);
  const pagado = totalDe(mano);
  const alcanza = pagado >= precio;
  const noAlcanzaBilletera = totalDe(billetera) < precio;

  function pagar() {
    if (!alcanza) {
      toast.error(`Te faltan ${formatCOP(precio - pagado)}`);
      speak(`Te faltan ${precio - pagado} pesos`);
      return;
    }
    const sobra = billeteQueSobra(mano, precio);
    if (sobra !== null) {
      toast.error(`Estás dando de más. Puedes quitar la ${nombreDenom(sobra)}.`);
      speak(`Estás dando de más. Puedes quitar la ${nombreDenom(sobra)}`);
      return;
    }
    onPagado(mano);
    setMano([]);
  }

  return (
    <div className="space-y-4">
      <div className="rounded-3xl bg-primary p-5 text-center text-primary-foreground shadow-playful">
        <div className="text-sm font-extrabold uppercase tracking-widest opacity-90">{titulo}</div>
        <div className="mt-1 font-mono text-5xl font-black">{formatCOP(precio)}</div>
        <button
          onClick={() => speak(`Debes pagar ${precio} pesos`)}
          className="mx-auto mt-3 flex items-center gap-2 rounded-2xl bg-background px-4 py-2 text-base font-extrabold text-foreground"
        >
          <Volume2 className="size-5" /> Escuchar
        </button>
      </div>

      {noAlcanzaBilletera && (
        <div className="rounded-2xl bg-accent-yellow/25 p-4 text-center text-lg font-extrabold">
          No te alcanza: tienes {formatCOP(totalDe(billetera))}. Ve a COOPRECOZ a trabajar.
        </div>
      )}

      <div className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border/70">
        <div className="mb-3 text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
          Toca los billetes y monedas que vas a entregar
        </div>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {disponibles.map((g) => (
            <button
              key={g.value}
              onClick={() => {
                setMano((m) => [...m, g.value]);
                speak(`${g.value} pesos`);
              }}
              className="relative flex flex-col items-center gap-1 rounded-2xl bg-muted/40 p-2 ring-1 ring-border transition hover:bg-muted active:scale-95"
              aria-label={`Entregar ${nombreDenom(g.value)}. Tienes ${g.count}`}
            >
              <img
                src={COP_IMAGES[g.value]}
                alt=""
                className={`${esBillete(g.value) ? "h-12 w-20" : "size-12"} rounded-md object-contain`}
                draggable={false}
              />
              <span className="font-mono text-sm font-black">
                ${g.value.toLocaleString("es-CO")}
              </span>
              <span className="absolute right-1 top-1 rounded-full bg-card px-1.5 font-mono text-xs font-black ring-1 ring-border">
                {g.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border/70">
        <div className="flex items-baseline justify-between">
          <span className="text-base font-extrabold text-muted-foreground">En tu mano</span>
          <span
            className={`font-mono text-3xl font-black ${alcanza ? "text-accent-green" : "text-foreground"}`}
          >
            {formatCOP(pagado)}
          </span>
        </div>
        {mano.length > 0 ? (
          <div className="mt-3 flex flex-wrap gap-2">
            {mano.map((v, i) => (
              <button
                key={`${v}-${i}`}
                onClick={() => setMano((m) => m.filter((_, j) => j !== i))}
                className="relative rounded-xl bg-muted/40 p-1 ring-1 ring-border"
                aria-label={`Devolver a la cartera ${nombreDenom(v)}`}
              >
                <img
                  src={COP_IMAGES[v]}
                  alt=""
                  className={`${esBillete(v) ? "h-10 w-16" : "size-10"} rounded object-contain`}
                />
                <X className="absolute -right-1.5 -top-1.5 size-5 rounded-full bg-accent-red p-0.5 text-white" />
              </button>
            ))}
          </div>
        ) : (
          <p className="mt-2 text-sm font-bold text-muted-foreground">
            Aún no has escogido dinero.
          </p>
        )}
        {!alcanza && pagado > 0 && (
          <div className="mt-3 rounded-2xl bg-accent-yellow/20 p-3 text-center text-base font-extrabold">
            Te faltan {formatCOP(precio - pagado)}
          </div>
        )}
        <button
          onClick={pagar}
          disabled={mano.length === 0}
          className="mt-4 min-h-16 w-full rounded-2xl bg-primary text-2xl font-black text-primary-foreground shadow-playful transition active:scale-[0.98] disabled:opacity-40"
        >
          Pagar
        </button>
      </div>
    </div>
  );
}

/* ------------------------------ ¿Cuánto vuelto? ------------------------------ */

export function VueltoQuiz({
  precio,
  pagado,
  quien,
  onListo,
}: {
  precio: number;
  pagado: number;
  quien: string;
  onListo: (vuelto: number) => void;
}) {
  const vuelto = pagado - precio;
  const [opciones] = useState(() => opcionesVuelto(vuelto));
  const [ok, setOk] = useState(false);
  const [fallo, setFallo] = useState<number | null>(null);

  if (vuelto === 0) {
    return (
      <div className="space-y-4 rounded-3xl bg-card p-6 text-center shadow-sm ring-1 ring-border/70">
        <div className="text-5xl">🎯</div>
        <div className="text-2xl font-black">¡Pago exacto!</div>
        <p className="text-lg text-muted-foreground">No te tienen que devolver nada.</p>
        <button
          onClick={() => onListo(0)}
          className="min-h-16 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground"
        >
          Continuar →
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-3xl bg-card p-5 text-center shadow-sm ring-1 ring-border/70">
        <div className="text-lg font-bold text-muted-foreground">
          Costaba <b className="font-mono text-foreground">{formatCOP(precio)}</b> y entregaste{" "}
          <b className="font-mono text-foreground">{formatCOP(pagado)}</b>
        </div>
        <div className="mt-2 text-2xl font-black">¿Cuánto te debe devolver {quien}?</div>
        <button
          onClick={() =>
            speak(`Costaba ${precio} pesos y entregaste ${pagado}. ¿Cuánto te deben devolver?`)
          }
          className="mx-auto mt-3 flex items-center gap-2 rounded-2xl bg-accent-blue/10 px-4 py-2 text-base font-extrabold text-accent-blue"
        >
          <Volume2 className="size-5" /> Escuchar
        </button>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        {opciones.map((o) => (
          <button
            key={o}
            disabled={ok}
            onClick={() => {
              if (o === vuelto) {
                setOk(true);
                setFallo(null);
                toast.success(mensajePositivo());
                speak(`Correcto. Te devuelven ${vuelto} pesos`);
              } else {
                setFallo(o);
                toast.error("Revisa la resta otra vez 💪");
              }
            }}
            className={`min-h-20 rounded-3xl font-mono text-3xl font-black ring-2 transition active:scale-95 ${
              ok && o === vuelto
                ? "bg-accent-green text-white ring-accent-green"
                : fallo === o
                  ? "bg-accent-red/10 text-accent-red ring-accent-red/40"
                  : "bg-card ring-border hover:ring-primary/40"
            }`}
          >
            {formatCOP(o)}
          </button>
        ))}
      </div>
      {ok && (
        <div className="space-y-4 rounded-3xl bg-accent-green/10 p-5">
          <div className="text-center text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
            Te devuelven
          </div>
          <MoneyBreakdown value={vuelto} />
          <button
            onClick={() => onListo(vuelto)}
            className="min-h-16 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground shadow-playful"
          >
            Guardar en mi cartera →
          </button>
        </div>
      )}
    </div>
  );
}

/* --------------------------------- Recibo --------------------------------- */

export type LineaRecibo = { name: string; emoji: string; qty: number; price: number };

export function Recibo({
  tienda,
  lineas,
  recibido,
}: {
  tienda: string;
  lineas: LineaRecibo[];
  recibido: number;
}) {
  const total = lineas.reduce((a, l) => a + l.qty * l.price, 0);
  return (
    <div className="mx-auto w-full max-w-sm rounded-2xl bg-white p-5 font-mono text-neutral-900 shadow-lg ring-1 ring-black/10">
      <div className="border-b-2 border-dashed border-neutral-300 pb-3 text-center">
        <div className="text-xl font-black uppercase">{tienda}</div>
        <div className="text-xs font-bold text-neutral-500">Bucaramanga · {fechaRecibo()}</div>
      </div>
      <div className="space-y-1.5 border-b-2 border-dashed border-neutral-300 py-3 text-base font-bold">
        {lineas.map((l) => (
          <div key={l.name} className="flex justify-between gap-2">
            <span className="truncate">
              {l.qty} {l.name}
            </span>
            <span>{formatCOP(l.qty * l.price)}</span>
          </div>
        ))}
      </div>
      <div className="flex items-baseline justify-between pt-3">
        <span className="text-sm font-black uppercase">Total</span>
        <span className="text-2xl font-black">{formatCOP(total)}</span>
      </div>
      <div className="mt-1 flex justify-between text-sm font-bold">
        <span>Efectivo recibido</span>
        <span>{formatCOP(recibido)}</span>
      </div>
      <div className="flex justify-between text-sm font-bold">
        <span>Cambio</span>
        <span>{formatCOP(recibido - total)}</span>
      </div>
      <div className="mt-3 rounded-lg bg-neutral-100 py-1.5 text-center text-sm font-black">
        Forma de pago: EFECTIVO
      </div>
      <div className="mt-2 text-center text-xs font-bold text-neutral-500">
        ¡Gracias por su compra!
      </div>
    </div>
  );
}

type Pregunta = { pregunta: string; correcta: string; opciones: string[] };

export function ReciboQuiz({
  tienda,
  lineas,
  recibido,
  onListo,
}: {
  tienda: string;
  lineas: LineaRecibo[];
  recibido: number;
  onListo: () => void;
}) {
  const total = lineas.reduce((a, l) => a + l.qty * l.price, 0);
  const vuelto = recibido - total;
  const preguntas = useMemo<Pregunta[]>(() => {
    const otrasTiendas = [
      "Droguería",
      "Útiles escolares",
      "Mercado",
      "Plaza de mercado",
      "COOPRECOZ",
    ]
      .filter((t) => t !== tienda)
      .sort(() => Math.random() - 0.5)
      .slice(0, 2);
    return [
      {
        pregunta: "Mira el recibo: ¿cuánto fue el TOTAL?",
        correcta: formatCOP(total),
        opciones: opcionesVuelto(total).map(formatCOP),
      },
      {
        pregunta: "¿Cuánto te dieron de CAMBIO?",
        correcta: formatCOP(vuelto),
        opciones: opcionesVuelto(vuelto).map(formatCOP),
      },
      {
        pregunta: "¿En qué lugar compraste?",
        correcta: tienda,
        opciones: [tienda, ...otrasTiendas].sort(() => Math.random() - 0.5),
      },
    ];
  }, [tienda, total, vuelto]);
  const [i, setI] = useState(0);
  const [ok, setOk] = useState(false);
  const [fallo, setFallo] = useState<string | null>(null);
  const p = preguntas[i];

  return (
    <div className="space-y-4">
      <Recibo tienda={tienda} lineas={lineas} recibido={recibido} />
      <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-border/70">
        <div className="text-xs font-extrabold uppercase tracking-widest text-mod-recibo">
          Pregunta {i + 1} de {preguntas.length}
        </div>
        <div className="mt-1 text-xl font-black">{p.pregunta}</div>
        <div className="mt-4 grid gap-3">
          {p.opciones.map((o) => (
            <button
              key={o}
              disabled={ok}
              onClick={() => {
                if (o === p.correcta) {
                  setOk(true);
                  setFallo(null);
                  toast.success(mensajePositivo());
                } else {
                  setFallo(o);
                  toast.error("Busca esa parte en el recibo 🔎");
                }
              }}
              className={`min-h-14 rounded-2xl px-4 text-left text-xl font-extrabold ring-2 transition active:scale-[0.98] ${
                ok && o === p.correcta
                  ? "bg-accent-green/15 text-accent-green ring-accent-green/40"
                  : fallo === o
                    ? "bg-accent-red/10 text-accent-red ring-accent-red/30"
                    : "bg-muted/40 ring-border hover:bg-muted"
              }`}
            >
              {o}
            </button>
          ))}
        </div>
        {ok && (
          <button
            onClick={() => {
              setOk(false);
              setFallo(null);
              if (i + 1 < preguntas.length) setI(i + 1);
              else onListo();
            }}
            className="mt-4 min-h-16 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground shadow-playful"
          >
            {i + 1 < preguntas.length ? "Siguiente pregunta →" : "Terminar →"}
          </button>
        )}
      </div>
    </div>
  );
}
