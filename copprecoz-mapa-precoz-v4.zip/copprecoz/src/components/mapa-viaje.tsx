import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Car, Clock, MapPin, Navigation, ShieldCheck, Volume2 } from "lucide-react";
import { formatCOP } from "@/lib/cop";
import { speak } from "@/components/money-ui";
import { PagarConBilletera, Pasos, VueltoQuiz } from "@/components/mapa-ui";
import {
  CONDUCTORES,
  distanciaKm,
  getPlace,
  minutos,
  tarifa,
  totalDe,
  type PlaceId,
} from "@/lib/mapa";

export type FaseViaje = "cotizar" | "buscando" | "placa" | "enCamino" | "pagar" | "vuelto";

const PASOS = ["Pide", "Revisa la placa", "Viaja", "Paga", "Vuelto"];
const PASO_DE: Record<FaseViaje, number> = {
  cotizar: 0,
  buscando: 0,
  placa: 1,
  enCamino: 2,
  pagar: 3,
  vuelto: 4,
};

export function ViajeUber({
  origen,
  destino,
  billetera,
  fase,
  setFase,
  onPagar,
  onRecibirVuelto,
  onLlegar,
  onCancelar,
}: {
  origen: PlaceId;
  destino: PlaceId;
  billetera: number[];
  fase: FaseViaje;
  setFase: (f: FaseViaje) => void;
  onPagar: (entregados: number[]) => void;
  onRecibirVuelto: (v: number) => void;
  onLlegar: () => void;
  onCancelar: () => void;
}) {
  const precio = tarifa(origen, destino);
  const km = distanciaKm(origen, destino);
  const min = minutos(origen, destino);
  const d = getPlace(destino);
  const [conductor] = useState(() => CONDUCTORES[Math.floor(Math.random() * CONDUCTORES.length)]);
  const [otraPlaca] = useState(() => {
    const otros = CONDUCTORES.filter((c) => c.placa !== conductor.placa);
    return otros[Math.floor(Math.random() * otros.length)];
  });
  const [placas] = useState(() => [conductor, otraPlaca].sort(() => Math.random() - 0.5));
  const [falloPlaca, setFalloPlaca] = useState<string | null>(null);
  const [pagado, setPagado] = useState(0);

  useEffect(() => {
    if (fase === "buscando") {
      const t = setTimeout(() => setFase("placa"), 1600);
      return () => clearTimeout(t);
    }
    if (fase === "enCamino") {
      const t = setTimeout(() => {
        setFase("pagar");
        speak(`Llegaste a ${d.name}. El viaje cuesta ${precio} pesos`);
      }, 3200);
      return () => clearTimeout(t);
    }
  }, [fase, setFase, d.name, precio]);

  const alcanza = totalDe(billetera) >= precio;

  return (
    <div className="space-y-4">
      <Pasos pasos={PASOS} actual={PASO_DE[fase]} />

      {fase === "cotizar" && (
        <div className="space-y-4 rounded-3xl bg-card p-5 shadow-sm ring-1 ring-border/70">
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <span className="grid size-10 place-items-center rounded-full bg-muted">
                <MapPin className="size-5" />
              </span>
              <div>
                <div className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">
                  Desde
                </div>
                <div className="text-lg font-extrabold">{getPlace(origen).name}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="grid size-10 place-items-center rounded-full bg-primary text-primary-foreground">
                <Navigation className="size-5" />
              </span>
              <div>
                <div className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">
                  Hasta
                </div>
                <div className="text-lg font-extrabold">
                  {d.emoji} {d.name}
                </div>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-2xl bg-muted/50 p-3">
              <div className="text-xs font-bold uppercase text-muted-foreground">Distancia</div>
              <div className="font-mono text-xl font-black">{km} km</div>
            </div>
            <div className="rounded-2xl bg-muted/50 p-3">
              <div className="flex items-center justify-center gap-1 text-xs font-bold uppercase text-muted-foreground">
                <Clock className="size-3" /> Tiempo
              </div>
              <div className="font-mono text-xl font-black">{min} min</div>
            </div>
            <div className="rounded-2xl bg-primary/10 p-3">
              <div className="text-xs font-bold uppercase text-muted-foreground">Precio</div>
              <div className="font-mono text-xl font-black text-primary">{formatCOP(precio)}</div>
            </div>
          </div>
          <button
            onClick={() =>
              speak(`Viaje a ${d.name}: ${km} kilómetros, ${min} minutos. Cuesta ${precio} pesos`)
            }
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-accent-blue/10 py-3 text-base font-extrabold text-accent-blue"
          >
            <Volume2 className="size-5" /> Escuchar
          </button>
          {!alcanza && (
            <div className="rounded-2xl bg-accent-yellow/25 p-3 text-center text-base font-extrabold">
              No te alcanza para este viaje. Primero trabaja en COOPRECOZ.
            </div>
          )}
          <div className="grid grid-cols-[auto_1fr] gap-3">
            <button
              onClick={onCancelar}
              className="min-h-14 rounded-2xl border-2 border-border bg-card px-4 text-lg font-extrabold"
            >
              Cancelar
            </button>
            <button
              onClick={() => setFase("buscando")}
              disabled={!alcanza}
              className="flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-foreground text-xl font-black text-background disabled:opacity-40"
            >
              <Car className="size-6" /> Pedir carro
            </button>
          </div>
        </div>
      )}

      {fase === "buscando" && (
        <div className="rounded-3xl bg-card p-8 text-center shadow-sm ring-1 ring-border/70">
          <div className="mx-auto size-14 animate-spin rounded-full border-4 border-muted border-t-primary" />
          <div className="mt-4 text-xl font-black">Buscando un conductor…</div>
        </div>
      )}

      {fase === "placa" && (
        <div className="space-y-4 rounded-3xl bg-card p-5 shadow-sm ring-1 ring-border/70">
          <div className="flex items-center gap-4">
            <div
              className="grid size-16 shrink-0 place-items-center rounded-2xl text-4xl"
              style={{ background: `${conductor.color}22` }}
            >
              🚗
            </div>
            <div>
              <div className="text-lg font-black">{conductor.nombre} viene por ti</div>
              <div className="text-base font-bold text-muted-foreground">
                {conductor.carro} · Placa{" "}
                <span className="rounded-md bg-accent-yellow px-2 py-0.5 font-mono font-black text-neutral-900">
                  {conductor.placa}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-start gap-2 rounded-2xl bg-accent-blue/10 p-3 text-base font-bold text-accent-blue">
            <ShieldCheck className="mt-0.5 size-5 shrink-0" />
            Antes de subirte, revisa siempre que la placa sea la misma de la app.
          </div>
          <div className="text-xl font-black">Llegaron dos carros. ¿Cuál es el tuyo?</div>
          <div className="grid grid-cols-2 gap-3">
            {placas.map((c) => (
              <button
                key={c.placa}
                onClick={() => {
                  if (c.placa === conductor.placa) {
                    toast.success("¡Bien hecho! Ese es tu carro.");
                    speak("Bien hecho. Súbete, vamos en camino");
                    setFase("enCamino");
                  } else {
                    setFalloPlaca(c.placa);
                    toast.error("Esa placa no es la de tu conductor. ¡No te subas!");
                  }
                }}
                className={`flex flex-col items-center gap-2 rounded-3xl p-4 ring-2 active:scale-95 ${
                  falloPlaca === c.placa
                    ? "bg-accent-red/10 ring-accent-red/40"
                    : "bg-muted/40 ring-border"
                }`}
              >
                <span className="text-5xl">🚗</span>
                <span className="rounded-lg border-2 border-neutral-900 bg-accent-yellow px-3 py-1 font-mono text-xl font-black text-neutral-900">
                  {c.placa}
                </span>
                <span className="text-sm font-bold text-muted-foreground">{c.carro}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {fase === "enCamino" && (
        <div className="rounded-3xl bg-card p-6 text-center shadow-sm ring-1 ring-border/70">
          <div className="text-5xl">🛣️</div>
          <div className="mt-2 text-xl font-black">Vas en camino a {d.name}</div>
          <div className="text-base font-bold text-muted-foreground">
            {conductor.nombre} · {conductor.placa} · {min} min
          </div>
        </div>
      )}

      {fase === "pagar" && (
        <PagarConBilletera
          precio={precio}
          billetera={billetera}
          titulo={`Llegaste. Paga el viaje a ${conductor.nombre}`}
          onPagado={(entregados) => {
            setPagado(totalDe(entregados));
            onPagar(entregados);
            setFase("vuelto");
          }}
        />
      )}

      {fase === "vuelto" && (
        <VueltoQuiz
          precio={precio}
          pagado={pagado}
          quien={conductor.nombre}
          onListo={(v) => {
            onRecibirVuelto(v);
            onLlegar();
          }}
        />
      )}
    </div>
  );
}
