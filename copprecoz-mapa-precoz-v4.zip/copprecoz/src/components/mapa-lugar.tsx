import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Check, Minus, Plus, ShoppingBasket, Trophy, Volume2 } from "lucide-react";
import { COP_DENOMINATIONS, COP_IMAGES, formatCOP } from "@/lib/cop";
import { speak } from "@/components/money-ui";
import {
  PagarConBilletera,
  Pasos,
  ReciboQuiz,
  VueltoQuiz,
  type LineaRecibo,
} from "@/components/mapa-ui";
import { QUIEN_ENCARGA, totalDe, type Place, type Producto } from "@/lib/mapa";
import { mensajePositivo } from "@/lib/gamification";

const PASOS = ["Reconoce", "Escoge", "¿Necesidad?", "Paga", "Vuelto", "Recibo"];

type ItemLista = Producto & { qty: number };

function crearEncargo(place: Place): { quien: string; items: ItemLista[] } {
  const necesidades = place.productos.filter((p) => p.tipo === "necesidad");
  const n = 2 + (Math.random() < 0.5 ? 1 : 0);
  const items = [...necesidades]
    .sort(() => Math.random() - 0.5)
    .slice(0, n)
    .map((p) => ({ ...p, qty: p.price <= 2000 && Math.random() < 0.5 ? 2 : 1 }));
  return { quien: QUIEN_ENCARGA[Math.floor(Math.random() * QUIEN_ENCARGA.length)], items };
}

/* --------------------------- 1) Reconoce el billete --------------------------- */

function ReconoceBillete({
  vendedor,
  billetera,
  onOk,
}: {
  vendedor: string;
  billetera: number[];
  onOk: () => void;
}) {
  // Solo se usan los billetes y monedas que el estudiante tiene en su cartera.
  const { objetivo, opciones } = useMemo(() => {
    const enCartera = COP_DENOMINATIONS.filter(
      (d) => d.value >= 500 && billetera.includes(d.value),
    );
    const pool =
      enCartera.length >= 2
        ? enCartera
        : COP_DENOMINATIONS.filter((d) => d.value >= 500 && d.value <= 50000);
    const objetivo = pool[Math.floor(Math.random() * pool.length)];
    const otros = pool
      .filter((d) => d.value !== objetivo.value)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3);
    return { objetivo, opciones: [objetivo, ...otros].sort(() => Math.random() - 0.5) };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const [ok, setOk] = useState(false);
  const [fallo, setFallo] = useState<number | null>(null);
  const tipo = objetivo.type === "billete" ? "el billete" : "la moneda";
  const frase = `Abre tu cartera y busca ${tipo} de ${objetivo.value.toLocaleString("es-CO")} pesos para pagarle a ${vendedor}`;

  return (
    <div className="space-y-4">
      <div className="rounded-3xl bg-card p-5 text-center shadow-sm ring-1 ring-border/70">
        <div className="text-5xl">👛</div>
        <div className="mt-2 text-xl font-black leading-snug">
          Abre tu cartera y busca {tipo} de{" "}
          <span className="font-mono text-primary">{formatCOP(objetivo.value)}</span>
        </div>
        <div className="mt-1 text-base font-bold text-muted-foreground">
          Esto es lo que tienes en tu cartera
        </div>
        <button
          onClick={() => speak(frase)}
          className="mx-auto mt-3 flex items-center gap-2 rounded-2xl bg-accent-blue/10 px-4 py-2 text-base font-extrabold text-accent-blue"
        >
          <Volume2 className="size-5" /> Escuchar
        </button>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {opciones.map((d) => (
          <button
            key={d.value}
            disabled={ok}
            onClick={() => {
              if (d.value === objetivo.value) {
                setOk(true);
                toast.success(mensajePositivo());
                speak("¡Muy bien, ese es!");
              } else {
                setFallo(d.value);
                toast.error("Ese no es. Mira el color y el número 👀");
              }
            }}
            aria-label={`Opción: ${d.type}`}
            className={`grid min-h-32 place-items-center rounded-3xl p-3 ring-2 transition active:scale-95 ${
              ok && d.value === objetivo.value
                ? "bg-accent-green/15 ring-accent-green"
                : fallo === d.value
                  ? "bg-accent-red/10 ring-accent-red/40"
                  : "bg-card ring-border hover:ring-primary/40"
            }`}
          >
            <img
              src={COP_IMAGES[d.value]}
              alt=""
              draggable={false}
              className={`${d.type === "billete" ? "h-20 w-36 sm:h-24 sm:w-44" : "size-20 sm:size-24"} rounded-lg object-contain drop-shadow`}
            />
          </button>
        ))}
      </div>
      {ok && (
        <button
          onClick={onOk}
          className="min-h-16 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground shadow-playful"
        >
          Ahora haz la compra →
        </button>
      )}
    </div>
  );
}

/* ------------------------- 3) ¿Necesidad o gusto? ------------------------- */

function NecesidadOGusto({ producto, onOk }: { producto: Producto; onOk: () => void }) {
  const [ok, setOk] = useState(false);
  const [fallo, setFallo] = useState(false);
  const explicacion =
    producto.tipo === "necesidad"
      ? "Es una necesidad: la usas para estar bien, comer, estudiar o cuidarte."
      : "Es un gusto: es rico o bonito, pero puedes vivir sin eso. Primero van las necesidades.";

  function responder(r: Producto["tipo"]) {
    if (r === producto.tipo) {
      setOk(true);
      setFallo(false);
      toast.success(mensajePositivo());
      speak(explicacion);
    } else {
      setFallo(true);
      toast.error("Piénsalo otra vez: ¿lo necesitas o solo lo quieres?");
    }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-3xl bg-mod-finanzas-soft p-6 text-center ring-1 ring-mod-finanzas/30">
        <div className="text-xs font-extrabold uppercase tracking-widest text-mod-finanzas">
          Cuido mi dinero
        </div>
        <div className="mt-2 text-7xl">{producto.emoji}</div>
        <div className="mt-2 text-2xl font-black">
          {producto.name} — <span className="font-mono">{formatCOP(producto.price)}</span>
        </div>
        <div className="mt-1 text-xl font-bold">¿Es una necesidad o un gusto?</div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {(
          [
            ["necesidad", "✅ Necesidad"],
            ["gusto", "🍭 Gusto"],
          ] as const
        ).map(([v, label]) => (
          <button
            key={v}
            disabled={ok}
            onClick={() => responder(v)}
            className={`min-h-20 rounded-3xl text-xl font-black ring-2 transition active:scale-95 ${
              ok && v === producto.tipo
                ? "bg-accent-green/15 text-accent-green ring-accent-green"
                : fallo && v !== producto.tipo
                  ? "bg-accent-red/10 ring-accent-red/30"
                  : "bg-card ring-border hover:ring-primary/40"
            }`}
          >
            {label}
          </button>
        ))}
      </div>
      {ok && (
        <>
          <p className="rounded-2xl bg-card p-4 text-lg font-bold ring-1 ring-border">
            {explicacion}
          </p>
          <button
            onClick={onOk}
            className="min-h-16 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground shadow-playful"
          >
            Ir a pagar →
          </button>
        </>
      )}
    </div>
  );
}

/* --------------------------------- Misión --------------------------------- */

export function MisionLugar({
  place,
  billetera,
  onPagar,
  onRecibirVuelto,
  onTerminar,
}: {
  place: Place;
  billetera: number[];
  onPagar: (entregados: number[]) => void;
  onRecibirVuelto: (vuelto: number) => void;
  onTerminar: () => void;
}) {
  const [paso, setPaso] = useState(0);
  const [encargo] = useState(() => crearEncargo(place));
  const [cesta, setCesta] = useState<Record<string, number>>({});
  const [pagado, setPagado] = useState(0);
  const [preguntaProducto] = useState<Producto>(() => {
    const gustos = place.productos.filter((p) => p.tipo === "gusto");
    if (gustos.length && Math.random() < 0.6)
      return gustos[Math.floor(Math.random() * gustos.length)];
    return encargo.items[0];
  });

  const total = place.productos.reduce((a, p) => a + p.price * (cesta[p.name] ?? 0), 0);
  const lineas: LineaRecibo[] = place.productos
    .filter((p) => (cesta[p.name] ?? 0) > 0)
    .map((p) => ({ name: p.name, emoji: p.emoji, qty: cesta[p.name], price: p.price }));

  function cambiar(p: Producto, d: number) {
    setCesta((c) => {
      const n = Math.max(0, (c[p.name] ?? 0) + d);
      return { ...c, [p.name]: n };
    });
    if (d > 0) speak(`${p.name}, ${p.price} pesos`);
  }

  function revisarCesta() {
    for (const it of encargo.items) {
      const tengo = cesta[it.name] ?? 0;
      if (tengo < it.qty) {
        toast.error(`Te falta: ${it.qty - tengo} ${it.name}`);
        return;
      }
      if (tengo > it.qty) {
        toast.error(`Llevas ${tengo} ${it.name}, pero la lista dice ${it.qty}`);
        return;
      }
    }
    const extra = place.productos.find(
      (p) => (cesta[p.name] ?? 0) > 0 && !encargo.items.some((i) => i.name === p.name),
    );
    if (extra) {
      toast.error(`${extra.name} no está en la lista. Quítalo.`);
      return;
    }
    toast.success(`¡Lista completa! Total: ${formatCOP(total)}`);
    setPaso(2);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3 rounded-3xl bg-accent-blue/10 p-4 ring-1 ring-accent-blue/20">
        <span className="text-4xl">🛍️</span>
        <div className="min-w-0">
          <div className="text-xs font-extrabold uppercase tracking-widest text-accent-blue">
            Aquí eres el cliente
          </div>
          <div className="text-base font-bold">
            {place.vendedor} te atiende. Tú compras y pagas con lo que tienes en tu cartera.
          </div>
        </div>
      </div>
      <Pasos pasos={PASOS} actual={paso} />

      {paso === 0 && (
        <ReconoceBillete vendedor={place.vendedor} billetera={billetera} onOk={() => setPaso(1)} />
      )}

      {paso === 1 && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-primary p-5 text-primary-foreground shadow-playful">
            <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest opacity-90">
              <ShoppingBasket className="size-5" /> Lista de compras
            </div>
            <div className="mt-1 text-xl font-extrabold">{encargo.quien}:</div>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {encargo.items.map((it) => {
                const listo = (cesta[it.name] ?? 0) === it.qty;
                return (
                  <li
                    key={it.name}
                    className={`flex items-center gap-3 rounded-2xl px-4 py-2.5 ${listo ? "bg-background/90 text-foreground" : "bg-white/15"}`}
                  >
                    <span className="text-3xl">{it.emoji}</span>
                    <span className="flex-1 text-lg font-extrabold">
                      {it.qty} {it.name}
                    </span>
                    {listo && <Check className="size-6 text-accent-green" />}
                  </li>
                );
              })}
            </ul>
            <button
              onClick={() =>
                speak(
                  `${encargo.quien}: ${encargo.items.map((i) => `${i.qty} ${i.name}`).join(", ")}`,
                )
              }
              className="mt-3 flex items-center gap-2 rounded-2xl bg-background px-4 py-2 text-base font-extrabold text-foreground"
            >
              <Volume2 className="size-5" /> Escuchar la lista
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {place.productos.map((p) => {
              const n = cesta[p.name] ?? 0;
              return (
                <div
                  key={p.name}
                  className={`flex flex-col items-center gap-1 rounded-3xl p-3 ring-2 ${n > 0 ? "bg-accent-green/10 ring-accent-green/40" : "bg-card ring-border"}`}
                >
                  <button
                    onClick={() => cambiar(p, 1)}
                    className="flex flex-col items-center"
                    aria-label={`Agregar ${p.name}`}
                  >
                    <span className="text-5xl">{p.emoji}</span>
                    <span className="text-base font-extrabold">{p.name}</span>
                    <span className="font-mono text-lg font-black text-primary">
                      {formatCOP(p.price)}
                    </span>
                  </button>
                  <div className="mt-1 flex items-center gap-2">
                    <button
                      onClick={() => cambiar(p, -1)}
                      disabled={n === 0}
                      aria-label={`Quitar ${p.name}`}
                      className="grid size-10 place-items-center rounded-full bg-muted disabled:opacity-30"
                    >
                      <Minus className="size-5" />
                    </button>
                    <span className="w-6 text-center font-mono text-xl font-black">{n}</span>
                    <button
                      onClick={() => cambiar(p, 1)}
                      aria-label={`Agregar ${p.name}`}
                      className="grid size-10 place-items-center rounded-full bg-primary text-primary-foreground"
                    >
                      <Plus className="size-5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="rounded-3xl bg-card p-4 shadow-lg ring-1 ring-border">
            <div className="flex items-baseline justify-between">
              <span className="text-base font-extrabold text-muted-foreground">
                Total de la cesta
              </span>
              <span className="font-mono text-3xl font-black text-primary">{formatCOP(total)}</span>
            </div>
            <button
              onClick={revisarCesta}
              disabled={total === 0}
              className="mt-3 min-h-14 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground disabled:opacity-40"
            >
              Ya tengo todo
            </button>
          </div>
        </div>
      )}

      {paso === 2 && <NecesidadOGusto producto={preguntaProducto} onOk={() => setPaso(3)} />}

      {paso === 3 && (
        <PagarConBilletera
          precio={total}
          billetera={billetera}
          titulo={`Paga en ${place.name}`}
          onPagado={(entregados) => {
            setPagado(totalDe(entregados));
            onPagar(entregados);
            setPaso(4);
          }}
        />
      )}

      {paso === 4 && (
        <VueltoQuiz
          precio={total}
          pagado={pagado}
          quien={place.vendedor}
          onListo={(v) => {
            onRecibirVuelto(v);
            setPaso(5);
          }}
        />
      )}

      {paso === 5 && (
        <ReciboQuiz
          tienda={place.name}
          lineas={lineas}
          recibido={pagado}
          onListo={() => setPaso(6)}
        />
      )}

      {paso === 6 && (
        <div className="rounded-3xl bg-primary p-8 text-center text-primary-foreground shadow-lg">
          <Trophy className="mx-auto size-12" />
          <h2 className="mt-3 text-2xl font-extrabold">¡Misión cumplida en {place.name}!</h2>
          <p className="mt-1 text-lg opacity-90">Ganaste 100 XP y 300 monedas para tu alcancía.</p>
          <button
            onClick={onTerminar}
            className="mt-5 min-h-14 w-full rounded-2xl bg-background px-5 text-xl font-black text-foreground"
          >
            Volver al mapa 🗺️
          </button>
        </div>
      )}
    </div>
  );
}
