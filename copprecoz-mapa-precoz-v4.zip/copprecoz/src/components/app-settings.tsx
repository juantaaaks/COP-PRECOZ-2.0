import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";
import {
  applyTheme,
  formatMoney,
  getMoneyFormat,
  getTheme,
  setMoneyFormat,
  setTheme,
  subscribeSettings,
  type MoneyFormat,
} from "@/lib/settings";

export function useMoneyFormat(): MoneyFormat {
  const [f, setF] = useState<MoneyFormat>("digitos");
  useEffect(() => {
    setF(getMoneyFormat());
    return subscribeSettings(() => setF(getMoneyFormat()));
  }, []);
  return f;
}

// Texto de dinero que respeta la opción elegida (10.000 vs 10 mil).
export function Money({ value, className }: { value: number; className?: string }) {
  const f = useMoneyFormat();
  return <span className={className}>{formatMoney(value, f)}</span>;
}

export function ThemeToggle() {
  const [t, setT] = useState<"light" | "dark">("light");
  useEffect(() => {
    const current = getTheme();
    setT(current);
    applyTheme(current);
    return subscribeSettings(() => setT(getTheme()));
  }, []);
  return (
    <button
      onClick={() => setTheme(t === "dark" ? "light" : "dark")}
      aria-label={t === "dark" ? "Activar modo claro" : "Activar modo oscuro"}
      className="grid size-12 place-items-center rounded-2xl border border-border bg-card shadow-sm transition hover:bg-muted active:scale-95"
    >
      {t === "dark" ? <Sun className="size-6" /> : <Moon className="size-6" />}
    </button>
  );
}

// Selector inicial: cómo quiere ver los números el educando.
export function MoneyFormatPicker() {
  const f = useMoneyFormat();
  const options: { id: MoneyFormat; label: string; sample: string }[] = [
    { id: "digitos", label: "Opción 1", sample: "$ 10.000" },
    { id: "palabras", label: "Opción 2", sample: "10 mil pesos" },
  ];
  return (
    <div className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-black/5">
      <h2 className="text-base font-extrabold uppercase tracking-widest text-muted-foreground">
        ¿Cómo quieres ver el dinero?
      </h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {options.map((o) => (
          <button
            key={o.id}
            onClick={() => setMoneyFormat(o.id)}
            aria-pressed={f === o.id}
            className={`rounded-2xl px-5 py-6 text-center transition active:scale-95 ${
              f === o.id
                ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                : "bg-muted/50 text-foreground ring-1 ring-black/5 hover:bg-muted"
            }`}
          >
            <div className="text-sm font-bold uppercase tracking-widest opacity-80">{o.label}</div>
            <div className="mt-1 font-mono text-3xl font-black">{o.sample}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
