import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Calculator, Minus, Plus, Trophy, Undo2, Volume2 } from "lucide-react";
import { COP_IMAGES, formatCOP } from "@/lib/cop";
import { MoneyBreakdown, speak } from "@/components/money-ui";
import { Pasos } from "@/components/mapa-ui";
import {
  SENCILLO_GERENTE,
  agrupar,
  opcionesVuelto,
  puedeDarVuelto,
  sacarDeBilletera,
  totalDe,
} from "@/lib/mapa";
import { mensajePositivo } from "@/lib/gamification";
import hummusAsset from "@/assets/tienda/hummus.jpg.asset.json";
import limonadaAsset from "@/assets/tienda/limonada.jpg.asset.json";

const SUELDO = 5000;
const PASOS = ["Marca el pedido", "¿Con cuánto pagó?", "Entrega el vuelto"];

const ITEMS = [
  { id: "hummus", name: "Hummus", plural: "hummus", price: 10000, img: hummusAsset.url },
  {
    id: "limonada",
    name: "Limonada cerezada",
    plural: "limonadas cerezadas",
    price: 3500,
    img: limonadaAsset.url,
  },
] as const;

const CLIENTES = [
  { nombre: "Valentina", emoji: "👧" },
  { nombre: "Profe Andrés", emoji: "👨‍🏫" },
  { nombre: "Samuel", emoji: "👦" },
  { nombre: "Doña Gloria", emoji: "👵" },
  { nombre: "Mateo", emoji: "🧑" },
];

type Pedido = {
  cliente: (typeof CLIENTES)[number];
  qty: Record<string, number>;
  total: number;
  pagaCon: number[];
};

function nuevoPedido(): Pedido {
  const cliente = CLIENTES[Math.floor(Math.random() * CLIENTES.length)];
  let qty: Record<string, number> = { hummus: 0, limonada: 0 };
  while (qty.hummus + qty.limonada === 0) {
    qty = {
      hummus: Math.floor(Math.random() * 3),
      limonada: Math.floor(Math.random() * 3),
    };
  }
  const total = qty.hummus * 10000 + qty.limonada * 3500;
  const billetes = [5000, 10000, 20000, 50000].filter((b) => b >= total);
  const opciones: number[][] = billetes.slice(0, 2).map((b) => [b]);
  if (total <= 15000) opciones.push([10000, 5000]);
  if (total <= 30000 && total > 20000) opciones.push([20000, 10000]);
  const pagaCon = opciones[Math.floor(Math.random() * opciones.length)];
  return { cliente, qty, total, pagaCon };
}

function textoPedido(p: Pedido) {
  return ITEMS.filter((it) => p.qty[it.id] > 0)
    .map((it) => `${p.qty[it.id]} ${p.qty[it.id] === 1 ? it.name.toLowerCase() : it.plural}`)
    .join(" y ");
}

export function TrabajoCooprecoz({
  caja,
  setCaja,
  onSueldo,
  onTurnoCompleto,
}: {
  caja: number[];
  setCaja: (c: number[]) => void;
  onSueldo: (valor: number) => void;
  onTurnoCompleto: () => void;
}) {
  const [pedido, setPedido] = useState<Pedido>(nuevoPedido);
  const [paso, setPaso] = useState(0);
  const [marcado, setMarcado] = useState<Record<string, number>>({ hummus: 0, limonada: 0 });
  const [vuelto, setVuelto] = useState<number[]>([]);
  const [atendidos, setAtendidos] = useState(0);
  const [falloPago, setFalloPago] = useState<number | null>(null);
  const meta = 3;

  const recibido = totalDe(pedido.pagaCon);
  const vueltoCorrecto = recibido - pedido.total;
  const totalMarcado = ITEMS.reduce((a, it) => a + it.price * (marcado[it.id] ?? 0), 0);
  const opcionesPago = useMemo(() => opcionesVuelto(recibido), [recibido]);
  const entregado = totalDe(vuelto);
  const enCaja = agrupar(sacarDeBilletera(caja, vuelto));

  function recibirPago() {
    toast.success(mensajePositivo());
    let nueva = [...caja, ...pedido.pagaCon];
    if (!puedeDarVuelto(nueva, vueltoCorrecto)) {
      nueva = [...nueva, ...SENCILLO_GERENTE];
      toast("El gerente trajo sencillo a la caja 🪙");
    }
    setCaja(nueva);
    speak("Guarda el dinero en la caja y saca el vuelto");
    setPaso(2);
  }

  function marcar(id: string, d: number) {
    setMarcado((m) => ({ ...m, [id]: Math.max(0, (m[id] ?? 0) + d) }));
  }

  function confirmarPedido() {
    const ok = ITEMS.every((it) => (marcado[it.id] ?? 0) === pedido.qty[it.id]);
    if (!ok) {
      toast.error(`Revisa el pedido: ${pedido.cliente.nombre} pidió ${textoPedido(pedido)}`);
      return;
    }
    toast.success(`Total: ${formatCOP(pedido.total)}`);
    speak(`El total es ${pedido.total} pesos`);
    setPaso(1);
  }

  function entregarVuelto() {
    if (entregado < vueltoCorrecto) {
      toast.error(`Falta entregar ${formatCOP(vueltoCorrecto - entregado)}`);
      return;
    }
    if (entregado > vueltoCorrecto) {
      toast.error(`Estás devolviendo ${formatCOP(entregado - vueltoCorrecto)} de más`);
      return;
    }
    setCaja(sacarDeBilletera(caja, vuelto));
    const n = atendidos + 1;
    setAtendidos(n);
    onSueldo(SUELDO);
    toast.success(`${mensajePositivo()} Ganaste ${formatCOP(SUELDO)} para tu cartera.`);
    speak(`Muy bien. Ganaste ${SUELDO} pesos`);
    if (n === meta) onTurnoCompleto();
    setPaso(3);
  }

  function siguienteCliente() {
    setPedido(nuevoPedido());
    setMarcado({ hummus: 0, limonada: 0 });
    setVuelto([]);
    setFalloPago(null);
    setPaso(0);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3 rounded-3xl bg-mod-precoz-soft p-4 ring-1 ring-mod-precoz/30">
        <span className="text-4xl">🧑‍🍳</span>
        <div className="min-w-0">
          <div className="text-xs font-extrabold uppercase tracking-widest text-mod-precoz">
            Aquí trabajas tú
          </div>
          <div className="text-base font-bold">
            Eres la persona cajera: cobras, guardas el dinero y entregas el vuelto con lo que hay en
            la caja.
          </div>
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-3xl bg-card p-4 ring-1 ring-border/70">
        <div>
          <div className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">
            Turno en la cooperativa
          </div>
          <div className="text-lg font-black">
            Clientes atendidos: {atendidos} / {meta}
          </div>
        </div>
        <div className="rounded-2xl bg-accent-green/10 px-3 py-2 text-sm font-extrabold text-accent-green">
          Pago: {formatCOP(SUELDO)} por cliente
        </div>
      </div>

      {paso < 3 && <Pasos pasos={PASOS} actual={paso} />}

      {paso < 3 && (
        <div className="flex items-center gap-4 rounded-3xl bg-mod-precoz-soft p-5 ring-1 ring-mod-precoz/30">
          <div className="text-6xl">{pedido.cliente.emoji}</div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-extrabold uppercase tracking-widest text-mod-precoz">
              {pedido.cliente.nombre} pide
            </div>
            <div className="text-xl font-black leading-snug">{textoPedido(pedido)}</div>
          </div>
          <button
            onClick={() => speak(`${pedido.cliente.nombre} pide ${textoPedido(pedido)}`)}
            aria-label="Escuchar el pedido"
            className="grid size-14 shrink-0 place-items-center rounded-full bg-accent-blue/15 text-accent-blue"
          >
            <Volume2 className="size-7" />
          </button>
        </div>
      )}

      {paso === 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-base font-extrabold text-muted-foreground">
            <Calculator className="size-5" /> Calculadora Precoz: marca lo que pidió
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {ITEMS.map((it) => (
              <div
                key={it.id}
                className="flex items-center gap-3 rounded-3xl bg-card p-3 ring-1 ring-border"
              >
                <img
                  src={it.img}
                  alt={it.name}
                  className="size-20 shrink-0 rounded-2xl bg-muted object-cover"
                />
                <div className="min-w-0 flex-1">
                  <div className="text-lg font-extrabold leading-tight">{it.name}</div>
                  <div className="font-mono text-base font-black text-primary">
                    {formatCOP(it.price)}
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <button
                      onClick={() => marcar(it.id, -1)}
                      aria-label={`Quitar ${it.name}`}
                      className="grid size-10 place-items-center rounded-full bg-muted"
                    >
                      <Minus className="size-5" />
                    </button>
                    <span className="w-6 text-center font-mono text-xl font-black">
                      {marcado[it.id]}
                    </span>
                    <button
                      onClick={() => marcar(it.id, 1)}
                      aria-label={`Agregar ${it.name}`}
                      className="grid size-10 place-items-center rounded-full bg-primary text-primary-foreground"
                    >
                      <Plus className="size-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="rounded-3xl bg-foreground p-5 text-background">
            <div className="text-xs font-extrabold uppercase tracking-widest opacity-70">Total</div>
            <div className="font-mono text-5xl font-black">{formatCOP(totalMarcado)}</div>
          </div>
          <button
            onClick={confirmarPedido}
            disabled={totalMarcado === 0}
            className="min-h-16 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground shadow-playful disabled:opacity-40"
          >
            Cobrar
          </button>
        </div>
      )}

      {paso === 1 && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-card p-5 text-center ring-1 ring-border">
            <div className="text-lg font-bold text-muted-foreground">
              El total es <b className="font-mono text-foreground">{formatCOP(pedido.total)}</b>.{" "}
              {pedido.cliente.nombre} te entrega:
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
              {pedido.pagaCon.map((b, i) => (
                <img
                  key={i}
                  src={COP_IMAGES[b]}
                  alt="Billete que te entregan"
                  className="h-24 w-44 rounded-lg object-contain drop-shadow-lg"
                />
              ))}
            </div>
            <div className="mt-4 text-xl font-black">¿Cuánto dinero te entregó?</div>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            {opcionesPago.map((o) => (
              <button
                key={o}
                onClick={() => {
                  if (o === recibido) {
                    recibirPago();
                  } else {
                    setFalloPago(o);
                    toast.error("Mira bien el billete: su color y su número");
                  }
                }}
                className={`min-h-20 rounded-3xl font-mono text-3xl font-black ring-2 active:scale-95 ${
                  falloPago === o
                    ? "bg-accent-red/10 text-accent-red ring-accent-red/40"
                    : "bg-card ring-border"
                }`}
              >
                {formatCOP(o)}
              </button>
            ))}
          </div>
        </div>
      )}

      {paso === 2 && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-card p-5 text-center ring-1 ring-border">
            <div className="text-lg font-bold text-muted-foreground">
              Recibiste <b className="font-mono text-foreground">{formatCOP(recibido)}</b> y el
              pedido cuesta <b className="font-mono text-foreground">{formatCOP(pedido.total)}</b>.
            </div>
            <div className="mt-2 text-2xl font-black">Saca de la caja el vuelto exacto</div>
          </div>
          <div className="rounded-3xl bg-card p-4 ring-1 ring-border">
            <div className="mb-3 flex items-baseline justify-between gap-2">
              <span className="text-sm font-extrabold uppercase tracking-widest text-muted-foreground">
                🗃️ Esto hay en la caja
              </span>
              <span className="font-mono text-base font-black text-muted-foreground">
                {formatCOP(totalDe(caja) - entregado)}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {enCaja.map((g) => (
                <button
                  key={g.value}
                  onClick={() => {
                    setVuelto((x) => [...x, g.value]);
                    speak(`${g.value} pesos`);
                  }}
                  aria-label={`Sacar ${g.value} pesos de la caja. Hay ${g.count}`}
                  className="relative flex flex-col items-center gap-1 rounded-2xl bg-muted/40 p-2 ring-1 ring-border transition hover:bg-muted active:scale-95"
                >
                  <img
                    src={COP_IMAGES[g.value]}
                    alt=""
                    draggable={false}
                    className={`${g.value >= 2000 ? "h-12 w-20" : "size-12"} rounded-md object-contain`}
                  />
                  <span className="font-mono text-sm font-black">
                    ${g.value.toLocaleString("es-CO")}
                  </span>
                  <span className="absolute right-1 top-1 rounded-full bg-card px-1.5 font-mono text-xs font-black ring-1 ring-border">
                    {g.count}
                  </span>
                </button>
              ))}
            </div>
            {vuelto.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2 border-t border-dashed border-border pt-3">
                {vuelto.map((v, i) => (
                  <img
                    key={`${v}-${i}`}
                    src={COP_IMAGES[v]}
                    alt={`${v} pesos`}
                    className={`${v >= 2000 ? "h-10 w-16" : "size-10"} rounded object-contain`}
                  />
                ))}
              </div>
            )}
          </div>
          <div className="rounded-3xl bg-card p-4 shadow-lg ring-1 ring-border">
            <div className="flex items-baseline justify-between">
              <span className="text-base font-extrabold text-muted-foreground">Vas entregando</span>
              <span className="font-mono text-3xl font-black">{formatCOP(entregado)}</span>
            </div>
            <div className="mt-3 grid grid-cols-[auto_1fr] gap-3">
              <button
                onClick={() => setVuelto((x) => x.slice(0, -1))}
                disabled={vuelto.length === 0}
                aria-label="Quitar el último"
                className="grid min-h-14 place-items-center rounded-2xl bg-accent-red/10 px-4 text-accent-red disabled:opacity-40"
              >
                <Undo2 className="size-6" />
              </button>
              <button
                onClick={entregarVuelto}
                disabled={vueltoCorrecto > 0 && vuelto.length === 0}
                className="min-h-14 rounded-2xl bg-primary text-xl font-black text-primary-foreground disabled:opacity-40"
              >
                {vueltoCorrecto === 0 ? "No hay vuelto: listo" : "Entregar vuelto"}
              </button>
            </div>
          </div>
        </div>
      )}

      {paso === 3 && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-accent-green/10 p-6 text-center ring-1 ring-accent-green/30">
            <div className="text-5xl">{pedido.cliente.emoji}💚</div>
            <div className="mt-2 text-2xl font-black">¡{pedido.cliente.nombre} quedó feliz!</div>
            <div className="mt-1 text-lg font-bold text-muted-foreground">
              Ganaste {formatCOP(SUELDO)}. Ya está en tu cartera:
            </div>
            <div className="mt-3">
              <MoneyBreakdown value={SUELDO} />
            </div>
          </div>
          {atendidos >= meta && (
            <div className="rounded-3xl bg-primary p-6 text-center text-primary-foreground">
              <Trophy className="mx-auto size-10" />
              <div className="mt-2 text-xl font-black">¡Terminaste tu turno!</div>
              <div className="opacity-90">Ahora pide un carro y ve a comprar a otro lugar.</div>
            </div>
          )}
          <button
            onClick={siguienteCliente}
            className="min-h-16 w-full rounded-2xl bg-primary text-xl font-black text-primary-foreground shadow-playful"
          >
            Atender otro cliente
          </button>
          <Link
            to="/modulo/$slug"
            params={{ slug: "precoz" }}
            className="flex min-h-14 w-full items-center justify-center gap-2 rounded-2xl border-2 border-border bg-card text-lg font-extrabold"
          >
            <Calculator className="size-5" /> Abrir la Calculadora Precoz completa
          </Link>
        </div>
      )}
    </div>
  );
}
