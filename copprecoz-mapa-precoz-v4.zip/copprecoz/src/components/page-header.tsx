import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import logo from "@/assets/logo.jpg.asset.json";
import { SettingsButton } from "@/components/settings-sheet";

/**
 * Encabezado común de las pantallas internas: volver, logo, título y ajustes.
 * Mantiene el mismo aire del panel para que la navegación se sienta igual.
 */
export function PageHeader({
  eyebrow,
  title,
  extra,
  width = "max-w-4xl",
}: {
  eyebrow?: string;
  title: string;
  extra?: React.ReactNode;
  width?: string;
}) {
  return (
    <header className="sticky top-0 z-30 border-b border-border/70 bg-background/85 backdrop-blur">
      <div className={`mx-auto flex ${width} items-center gap-3 px-4 py-3 sm:px-6`}>
        <Link
          to="/panel"
          aria-label="Volver al panel"
          className="grid size-12 shrink-0 place-items-center rounded-2xl border-2 border-border bg-card shadow-sm transition duration-200 hover:bg-muted active:scale-95"
        >
          <ArrowLeft className="size-6" />
        </Link>
        <img
          src={logo.url}
          alt="Logo Cooprecoz"
          className="hidden size-11 shrink-0 rounded-2xl object-contain ring-1 ring-border sm:block"
        />
        <div className="min-w-0 flex-1">
          {eyebrow && (
            <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
              {eyebrow}
            </div>
          )}
          <h1 className="truncate text-lg font-extrabold leading-tight sm:text-xl">{title}</h1>
        </div>
        {extra}
        <SettingsButton />
      </div>
    </header>
  );
}
