import { useEffect, useState } from "react";
import { Settings, X, RotateCcw, WifiOff } from "lucide-react";
import {
  DEFAULT_A11Y,
  applyA11y,
  getA11y,
  getMoneyFormat,
  getTheme,
  resetA11y,
  setA11y,
  setMoneyFormat,
  setTheme,
  subscribeSettings,
  type A11ySettings,
  type Difficulty,
  type MoneyFormat,
} from "@/lib/settings";

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-muted/40 p-4 ring-1 ring-black/5">
      <div className="mb-3">
        <div className="text-lg font-extrabold leading-tight">{label}</div>
        {hint && <div className="text-sm text-muted-foreground">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

function Options<T extends string | number>({
  value,
  options,
  onChange,
  label,
}: {
  value: T;
  options: { v: T; l: string }[];
  onChange: (v: T) => void;
  label: string;
}) {
  return (
    <div role="group" aria-label={label} className="grid grid-cols-2 gap-2 sm:grid-cols-3">
      {options.map((o) => (
        <button
          key={String(o.v)}
          onClick={() => onChange(o.v)}
          aria-pressed={value === o.v}
          className={`min-h-12 rounded-xl px-3 py-3 text-base font-bold transition active:scale-95 ${
            value === o.v
              ? "bg-primary text-primary-foreground shadow"
              : "bg-card text-foreground ring-1 ring-black/10 hover:bg-muted"
          }`}
        >
          {o.l}
        </button>
      ))}
    </div>
  );
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      onClick={() => onChange(!on)}
      role="switch"
      aria-checked={on}
      aria-label={label}
      className={`min-h-12 w-full rounded-xl px-4 py-3 text-base font-extrabold transition active:scale-95 ${
        on ? "bg-accent-green/15 text-accent-green ring-1 ring-accent-green/40" : "bg-card ring-1 ring-black/10"
      }`}
    >
      {on ? "Activado" : "Desactivado"}
    </button>
  );
}

export function useA11y(): A11ySettings {
  const [s, setS] = useState<A11ySettings>(DEFAULT_A11Y);
  useEffect(() => {
    const cur = getA11y();
    setS(cur);
    applyA11y(cur);
    return subscribeSettings(() => setS(getA11y()));
  }, []);
  return s;
}

export function SettingsButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label="Abrir configuración"
        className="grid size-12 place-items-center rounded-2xl border border-border bg-card shadow-sm transition hover:bg-muted active:scale-95"
      >
        <Settings className="size-6" />
      </button>
      {open && <SettingsPanel onClose={() => setOpen(false)} />}
    </>
  );
}

function SettingsPanel({ onClose }: { onClose: () => void }) {
  const s = useA11y();
  const [theme, setTh] = useState<"light" | "dark">("light");
  const [money, setMoney] = useState<MoneyFormat>("digitos");

  useEffect(() => {
    setTh(getTheme());
    setMoney(getMoneyFormat());
    return subscribeSettings(() => {
      setTh(getTheme());
      setMoney(getMoneyFormat());
    });
  }, []);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  // Evita que la página de atrás se mueva mientras la configuración está abierta.
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/50"
      role="dialog"
      aria-modal="true"
      aria-label="Configuración"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex h-dvh max-h-dvh w-full max-w-lg flex-col bg-background shadow-2xl"
      >
        <div className="flex shrink-0 items-center justify-between gap-3 border-b border-border bg-background px-4 py-3 sm:px-6">
          <h2 className="truncate text-2xl font-extrabold">⚙️ Configuración</h2>
          <button
            onClick={onClose}
            aria-label="Cerrar configuración"
            className="grid size-12 shrink-0 place-items-center rounded-2xl border border-border bg-card"
          >
            <X className="size-6" />
          </button>
        </div>

        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto overscroll-contain p-4 sm:p-6">
          <Row label="Modo claro u oscuro">
            <Options
              label="Tema"
              value={theme}
              onChange={(v) => setTheme(v)}
              options={[
                { v: "light" as const, l: "☀️ Claro" },
                { v: "dark" as const, l: "🌙 Oscuro" },
              ]}
            />
          </Row>

          <Row label="¿Cómo ver el dinero?">
            <Options
              label="Formato de dinero"
              value={money}
              onChange={(v) => setMoneyFormat(v)}
              options={[
                { v: "digitos" as MoneyFormat, l: "$ 10.000" },
                { v: "palabras" as MoneyFormat, l: "10 mil pesos" },
              ]}
            />
          </Row>

          <Row label="Tamaño de la letra">
            <Options
              label="Tamaño de la letra"
              value={s.fontScale}
              onChange={(v) => setA11y({ fontScale: v })}
              options={[
                { v: 0.9, l: "Pequeña" },
                { v: 1, l: "Normal" },
                { v: 1.15, l: "Grande" },
                { v: 1.3, l: "Muy grande" },
              ]}
            />
          </Row>

          <Row label="Alto contraste" hint="Colores más fuertes para ver mejor">
            <Toggle label="Alto contraste" on={s.highContrast} onChange={(v) => setA11y({ highContrast: v })} />
          </Row>

          <Row label="Sonidos">
            <Toggle label="Sonidos" on={s.sounds} onChange={(v) => setA11y({ sounds: v })} />
          </Row>

          <Row label="Lectura en voz alta">
            <Toggle label="Lectura en voz alta" on={s.readAloud} onChange={(v) => setA11y({ readAloud: v })} />
          </Row>


          <Row label="Velocidad de lectura">
            <Options
              label="Velocidad de lectura"
              value={s.speechRate}
              onChange={(v) => setA11y({ speechRate: v })}
              options={[
                { v: 0.7, l: "🐢 Lenta" },
                { v: 0.95, l: "🚶 Normal" },
                { v: 1.2, l: "🐇 Rápida" },
              ]}
            />
          </Row>

          <Row label="Pictogramas" hint="Muestra dibujos junto a los textos">
            <Toggle label="Pictogramas" on={s.pictograms} onChange={(v) => setA11y({ pictograms: v })} />
          </Row>

          <Row label="Reducir animaciones">
            <Toggle label="Reducir animaciones" on={s.reduceMotion} onChange={(v) => setA11y({ reduceMotion: v })} />
          </Row>

          <Row label="Baja estimulación sensorial" hint="Colores suaves y sin sombras">
            <Toggle label="Baja estimulación" on={s.lowStimulus} onChange={(v) => setA11y({ lowStimulus: v })} />
          </Row>

          <Row label="Dificultad">
            <Options
              label="Dificultad"
              value={s.difficulty}
              onChange={(v) => setA11y({ difficulty: v })}
              options={[
                { v: "basica" as Difficulty, l: "Básica" },
                { v: "intermedia" as Difficulty, l: "Intermedia" },
                { v: "avanzada" as Difficulty, l: "Avanzada" },
              ]}
            />
          </Row>

          <Row label="Idioma" hint="Pronto habrá más idiomas">
            <Options label="Idioma" value={s.language} onChange={() => {}} options={[{ v: "es" as const, l: "🇨🇴 Español" }]} />
          </Row>

          <button
            onClick={() => {
              resetA11y();
              setTheme("light");
              setMoneyFormat("digitos");
            }}
            className="min-h-14 w-full rounded-2xl bg-accent-red/10 px-4 py-4 text-lg font-extrabold text-accent-red"
          >
            <RotateCcw className="mr-2 inline size-5" /> Restablecer configuración
          </button>
          <p className="pb-6 text-center text-sm text-muted-foreground">
            Tus preferencias se guardan solas en este dispositivo.
          </p>
        </div>
      </div>
    </div>
  );
}

/** Aviso visual cuando no hay internet. */
export function OfflineBadge() {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    const upd = () => setOnline(navigator.onLine);
    upd();
    window.addEventListener("online", upd);
    window.addEventListener("offline", upd);
    return () => {
      window.removeEventListener("online", upd);
      window.removeEventListener("offline", upd);
    };
  }, []);
  if (online) return null;
  return (
    <div
      role="status"
      className="fixed inset-x-0 bottom-0 z-40 flex items-center justify-center gap-2 bg-accent-yellow/90 px-4 py-3 text-base font-extrabold text-foreground"
    >
      <WifiOff className="size-5" /> Sin conexión: puedes seguir practicando, guardamos tu avance
    </div>
  );
}
