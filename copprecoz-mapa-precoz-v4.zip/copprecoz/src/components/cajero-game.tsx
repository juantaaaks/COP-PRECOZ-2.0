import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Check, RotateCcw, Sparkles, Volume2, UserRound } from "lucide-react";
import { breakdownCOP, formatCOP } from "@/lib/cop";
import {
  BillPicker,
  ChangeHelper,
  MoneyBreakdown,
  Section,
  changeSpeech,
  speak,
  MoneyImage,
} from "@/components/money-ui";
import { saveModuleProgress } from "@/lib/module-progress";
import { recordActivity, mensajePositivo } from "@/lib/gamification";
import { getA11y } from "@/lib/settings";
import hummusAsset from "@/assets/tienda/hummus.jpg.asset.json";
import limonadaAsset from "@/assets/tienda/limonada.jpg.asset.json";

type Prod = { name: string; price: number; emoji?: string; img?: string };

const CATALOGO: Prod[] = [
  { name: "Hummus Cooprecoz", price: 10000, img: hummusAsset.url },
  { name: "Limonada cerezada", price: 3500, img: limonadaAsset.url },
  { name: "Pan", price: 1500, emoji: "🥖" },
  { name: "Jugo", price: 2000, emoji: "🧃" },
  { name: "Galletas", price: 2000, emoji: "🍪" },
  { name: "Agua", price: 2500, emoji: "💧" },
  { name: "Banano", price: 1000, emoji: "🍌" },
  { name: "Queso", price: 7500, emoji: "🧀" },
];

const CLIENTES = [
  { nombre: "Doña Marta", emoji: "👩" },
  { nombre: "Don Julián", emoji: "👨" },
  { nombre: "La profe Ana", emoji: "👩‍🏫" },
  { nombre: "Camilo", emoji: "🧑" },
  { nombre: "Abuela Rosa", emoji: "👵" },
];

const BILLETES_CLIENTE = [2000, 5000, 10000, 20000, 50000];

type Pedido = {
  cliente: (typeof CLIENTES)[number];
  items: Prod[];
  total: number;
  pago: number;
};

function nuevoPedido(nItems: number): Pedido {
  const cliente = CLIENTES[Math.floor(Math.random() * CLIENTES.length)];
  const barajado = [...CATALOGO].sort(() => Math.random() - 0.5);
  const items = barajado.slice(0, nItems);
  const total = items.reduce((a, b) => a + b.price, 0);
  const pago =
    BILLETES_CLIENTE.find((b) => b >= total) ?? BILLETES_CLIENTE[BILLETES_CLIENTE.length - 1];
  return { cliente, items, total, pago };
}

export function CajeroGame() {
  const dificultad = getA11y().difficulty;
  // Modo sencillo: 1 producto y el total ya está calculado.
  const facil = dificultad === "basica";
  const nItems = facil ? 1 : dificultad === "intermedia" ? 2 : 3;

  const [pedido, setPedido] = useState<Pedido>(() => nuevoPedido(nItems));
  const [picks, setPicks] = useState<number[]>([]);
  const [ayuda, setAyuda] = useState(facil);
  const [atendidos, setAtendidos] = useState(0);

  const vuelto = Math.max(0, pedido.pago - pedido.total);
  const dado = picks.reduce((a, b) => a + b, 0);
  const vueltoOk = dado === vuelto;
  const piezas = useMemo(
    () => breakdownCOP(vuelto).reduce((a, b) => a + b.count, 0),
    [vuelto],
  );

  function leerPedido() {
    speak(
      `${pedido.cliente.nombre} lleva ${pedido.items.map((i) => i.name).join(" y ")}. ` +
        `Vale ${pedido.total} pesos y paga con ${pedido.pago} pesos. Devuélvele ${vuelto} pesos.`,
    );
  }

  function cobrar() {
    if (!vueltoOk) {
      toast(`Casi lo logras 💛 El vuelto es ${formatCOP(vuelto)} y llevas ${formatCOP(dado)}`);
      speak("Todavía no está el vuelto. Mira la ayuda.");
      return;
    }
    speak(vuelto === 0 ? "Pago exacto, muy bien" : changeSpeech(vuelto));
    const next = atendidos + 1;
    setAtendidos(next);
    saveModuleProgress("cajero", Math.min(100, next * 25));
    const { nuevasInsignias } = recordActivity({ xp: 90, coins: 450, keys: ["cajero", "vuelto"] });
    toast.success(mensajePositivo());
    nuevasInsignias.forEach((b) => toast.success(`${b.emoji} Nueva insignia: ${b.name}`));
    setTimeout(siguiente, 900);
  }

  function siguiente() {
    setPedido(nuevoPedido(nItems));
    setPicks([]);
    setAyuda(facil);
  }

  const diff = dado - vuelto;

  return (
    <div className="space-y-5 sm:space-y-6">
      {/* Escena: el cliente llega al mostrador */}
      <div className="overflow-hidden rounded-3xl bg-card shadow-playful ring-1 ring-border">
        <div className="flex items-center gap-4 bg-mod-cajero-soft p-5 sm:p-6">
          <span className="grid size-20 shrink-0 animate-float place-items-center rounded-full bg-card text-5xl shadow sm:size-24 sm:text-6xl">
            {pedido.cliente.emoji}
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-widest text-mod-cajero">
              <UserRound className="size-4" /> Llegó un cliente
            </div>
            <h2 className="font-display text-2xl font-extrabold leading-tight sm:text-3xl">
              {pedido.cliente.nombre}
            </h2>
            <p className="text-base text-muted-foreground">Tú eres la persona cajera.</p>
          </div>
          <button
            onClick={leerPedido}
            aria-label="Escuchar el pedido"
            className="grid size-14 shrink-0 place-items-center rounded-full bg-card text-accent-blue shadow active:scale-95"
          >
            <Volume2 className="size-7" />
          </button>
        </div>

        {/* Producto */}
        <ul className="grid gap-3 p-4 sm:grid-cols-2 sm:p-5">
          {pedido.items.map((p) => (
            <li key={p.name} className="flex items-center gap-3 rounded-2xl surface-soft p-3 ring-1 ring-border">
              {p.img ? (
                <img src={p.img} alt={p.name} loading="lazy" draggable={false} className="size-14 shrink-0 object-contain" />
              ) : (
                <span className="grid size-14 shrink-0 place-items-center text-4xl">{p.emoji}</span>
              )}
              <span className="min-w-0 flex-1 truncate text-lg font-extrabold">{p.name}</span>
              <span className="shrink-0 font-mono text-xl font-black">{formatCOP(p.price)}</span>
            </li>
          ))}
        </ul>

        {/* Precio → Dinero entregado → Vuelto */}
        <div className="grid gap-3 px-4 pb-5 sm:grid-cols-[1fr_1fr_1.3fr] sm:px-5">
          <div className="rounded-2xl bg-accent-yellow/15 p-4 text-center">
            <div className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">Precio</div>
            <div className="font-mono text-3xl font-black">{formatCOP(pedido.total)}</div>
          </div>
          <div className="rounded-2xl bg-accent-blue/10 p-4 text-center">
            <div className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">Te entrega</div>
            <div className="mt-1 flex justify-center">
              <MoneyImage value={pedido.pago} alt={`Billete de ${pedido.pago} pesos`} className="h-12 w-20 object-contain" />
            </div>
            <div className="font-mono text-2xl font-black">{formatCOP(pedido.pago)}</div>
          </div>
          <div className="rounded-2xl bg-accent-green/15 p-4 text-center ring-2 ring-accent-green/40">
            <div className="text-xs font-extrabold uppercase tracking-widest text-accent-green">Debes devolver</div>
            <div className="font-mono text-5xl font-black leading-tight text-accent-green">{formatCOP(vuelto)}</div>
          </div>
        </div>
      </div>

      {/* Tu vuelto */}
      <Section
        title="Escoge el vuelto"
        hint={vuelto === 0 ? "Pago exacto" : `Con ${piezas} ${piezas === 1 ? "pieza" : "piezas"}`}
      >
        <BillPicker picks={picks} onPick={(v) => setPicks((p) => [...p, v])} />

        <div
          className={`mt-5 rounded-3xl p-4 ring-2 transition ${vueltoOk && picks.length > 0 ? "bg-accent-green/10 ring-accent-green/50" : "surface-soft ring-border"}`}
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">Tu vuelto</div>
              <div className="font-mono text-3xl font-black">{formatCOP(dado)}</div>
            </div>
            <span
              className={`rounded-full px-4 py-2 text-base font-extrabold ${
                diff === 0 ? "bg-accent-green/15 text-accent-green" : diff < 0 ? "bg-accent-blue/10 text-accent-blue" : "bg-accent-yellow/20 text-foreground"
              }`}
            >
              {diff === 0 ? "✓ Exacto" : diff < 0 ? `Faltan ${formatCOP(-diff)}` : `Sobran ${formatCOP(diff)}`}
            </span>
            <button
              onClick={() => setPicks((p) => p.slice(0, -1))}
              disabled={picks.length === 0}
              className="min-h-12 rounded-xl bg-card px-4 py-2 text-base font-bold ring-1 ring-border disabled:opacity-40"
            >
              Quitar último
            </button>
          </div>
          {picks.length > 0 && (
            <div className="mt-4">
              <MoneyBreakdown value={dado} />
            </div>
          )}
          {vueltoOk && picks.length > 0 && (
            <div className="mt-3 flex animate-pop items-center justify-center gap-2 text-xl font-extrabold text-accent-green">
              <Check className="size-7" /> ¡Muy bien! El vuelto es correcto ✓
            </div>
          )}
        </div>

        <button
          onClick={() => setAyuda((a) => !a)}
          className="mt-4 min-h-14 w-full rounded-2xl bg-accent-blue/10 py-4 text-lg font-bold text-accent-blue"
        >
          {ayuda ? "Ocultar ayuda" : "Necesito ayuda"}
        </button>
        {ayuda && (
          <div className="mt-4">
            <ChangeHelper value={vuelto} />
          </div>
        )}
        <button
          onClick={cobrar}
          className="mt-4 min-h-16 w-full rounded-2xl bg-primary py-6 text-2xl font-black text-primary-foreground shadow-playful transition active:scale-95"
        >
          <Sparkles className="mr-2 inline size-7" /> Entregar vuelto
        </button>
      </Section>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <span className="text-base font-bold text-muted-foreground">
          Clientes atendidos: {atendidos}
        </span>
        <button
          onClick={siguiente}
          className="min-h-14 rounded-2xl border border-border bg-card px-5 py-4 text-lg font-bold"
        >
          <RotateCcw className="mr-2 inline size-5" /> Otro cliente
        </button>
      </div>
    </div>
  );
}
