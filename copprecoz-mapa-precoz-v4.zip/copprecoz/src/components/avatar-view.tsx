import { useEffect, useState } from "react";
import {
  DEFAULT_AVATAR,
  getAvatar,
  prenda,
  subscribeAvatar,
  type AvatarState,
  type Peinado,
} from "@/lib/avatar";

export function useAvatar(): AvatarState {
  const [s, setS] = useState<AvatarState>(DEFAULT_AVATAR);
  useEffect(() => {
    setS(getAvatar());
    return subscribeAvatar(() => setS(getAvatar()));
  }, []);
  return s;
}

function Pelo({ tipo, color }: { tipo: Peinado; color: string }) {
  switch (tipo) {
    case "calvo":
      return null;
    case "largo":
      return (
        <g fill={color}>
          <path d="M28 42 Q26 20 50 18 Q74 20 72 42 Q72 70 66 74 Q68 46 50 44 Q32 46 34 74 Q28 70 28 42 Z" />
        </g>
      );
    case "rizado":
      return (
        <g fill={color}>
          <circle cx="34" cy="30" r="9" />
          <circle cx="45" cy="23" r="10" />
          <circle cx="57" cy="24" r="9" />
          <circle cx="66" cy="32" r="8" />
        </g>
      );
    case "coletas":
      return (
        <g fill={color}>
          <path d="M30 38 Q32 18 50 18 Q68 18 70 38 Q62 28 50 28 Q38 28 30 38 Z" />
          <circle cx="26" cy="44" r="8" />
          <circle cx="74" cy="44" r="8" />
        </g>
      );
    case "moño":
      return (
        <g fill={color}>
          <path d="M30 38 Q32 18 50 18 Q68 18 70 38 Q62 28 50 28 Q38 28 30 38 Z" />
          <circle cx="50" cy="14" r="8" />
        </g>
      );
    case "trenzas":
      return (
        <g fill={color}>
          <path d="M30 38 Q32 18 50 18 Q68 18 70 38 Q62 28 50 28 Q38 28 30 38 Z" />
          <rect x="24" y="40" width="7" height="26" rx="3.5" />
          <rect x="69" y="40" width="7" height="26" rx="3.5" />
        </g>
      );
    case "afro":
      return <circle cx="50" cy="32" r="25" fill={color} />;
    case "mohicano":
      return (
        <g fill={color}>
          <path d="M44 34 Q46 10 50 8 Q54 10 56 34 Z" />
        </g>
      );
    default:
      return (
        <path
          d="M30 38 Q32 18 50 18 Q68 18 70 38 Q62 28 50 28 Q38 28 30 38 Z"
          fill={color}
        />
      );
  }
}

export function AvatarView({
  state,
  size = 220,
}: {
  state: AvatarState;
  size?: number;
}) {
  const c = state.config;
  const fondo = prenda(c.fondo)?.color ?? "#dbeafe";
  const camiseta = prenda(c.camiseta)?.color ?? "#f97316";
  const sombrero = prenda(c.sombrero)?.emoji;
  const gafas = prenda(c.gafas)?.emoji;
  const mascota = prenda(c.mascota)?.emoji;
  const genero = c.genero ?? "mujer";
  const peinado = c.peinado ?? "corto";

  return (
    <div
      className="relative grid place-items-center overflow-hidden rounded-3xl ring-1 ring-black/10"
      style={{ width: size, height: size, background: fondo }}
      role="img"
      aria-label={`Personaje ${c.nombre}`}
    >
      <svg viewBox="0 0 100 100" width={size} height={size} aria-hidden>
        {/* cuerpo / ropa */}
        {genero === "mujer" ? (
          <path d="M22 100 Q30 66 50 66 Q70 66 78 100 Z" fill={camiseta} />
        ) : (
          <path d="M26 100 L26 76 Q26 66 50 66 Q74 66 74 76 L74 100 Z" fill={camiseta} />
        )}
        <rect x="41" y="55" width="18" height="14" rx="6" fill={c.piel} />
        {/* cabeza */}
        <circle cx="50" cy="40" r="20" fill={c.piel} />
        {/* pelo */}
        <Pelo tipo={peinado} color={c.pelo} />
        {/* ojos y sonrisa */}
        <circle cx="43" cy="40" r="2.6" fill="#1f2937" />
        <circle cx="57" cy="40" r="2.6" fill="#1f2937" />
        <path d="M43 48 Q50 54 57 48" stroke="#1f2937" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      </svg>
      {sombrero && (
        <span className="absolute" style={{ top: size * 0.02, fontSize: size * 0.3 }} aria-hidden>
          {sombrero}
        </span>
      )}
      {gafas && (
        <span className="absolute" style={{ top: size * 0.3, fontSize: size * 0.22 }} aria-hidden>
          {gafas}
        </span>
      )}
      {mascota && (
        <span
          className="absolute"
          style={{ bottom: size * 0.03, right: size * 0.05, fontSize: size * 0.2 }}
          aria-hidden
        >
          {mascota}
        </span>
      )}
    </div>
  );
}