import { useEffect, useState } from "react";
import { Download, X, Share, PlusSquare, MoreVertical } from "lucide-react";
import logo from "@/assets/logo.jpg.asset.json";

type BIPEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

const KEY = "copprecoz_install_oculto";

function esStandalone() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    // iOS Safari
    (window.navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

/** Aviso para instalar COPprecoz como app, con guía para iPhone y Android. */
export function InstallPrompt() {
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [visible, setVisible] = useState(false);
  const [guia, setGuia] = useState(false);
  const [ios, setIos] = useState(false);

  useEffect(() => {
    if (esStandalone()) return;
    if (window.localStorage.getItem(KEY) === "1") return;

    const ua = window.navigator.userAgent;
    const esIOS = /iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && "ontouchend" in document);
    setIos(esIOS);

    const onPrompt = (e: Event) => {
      e.preventDefault();
      setEvt(e as BIPEvent);
      setVisible(true);
    };
    const onInstalled = () => setVisible(false);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);

    // Si el navegador no ofrece el aviso automático (iPhone), mostramos la guía.
    const t = window.setTimeout(() => setVisible(true), 2500);

    return () => {
      window.clearTimeout(t);
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const ocultar = () => {
    window.localStorage.setItem(KEY, "1");
    setVisible(false);
    setGuia(false);
  };

  if (!visible) return null;

  return (
    <>
      <div className="fixed inset-x-3 bottom-3 z-40 flex items-center gap-3 rounded-3xl bg-card p-4 shadow-2xl ring-2 ring-primary/30 sm:left-auto sm:right-5 sm:w-96">
        <img
          src={logo.url}
          alt="Logo Cooprecoz"
          className="size-14 shrink-0 rounded-2xl object-contain ring-2 ring-primary/20"
        />
        <div className="min-w-0 flex-1">
          <div className="text-lg font-extrabold leading-tight">Instala COPprecoz</div>
          <div className="text-sm text-muted-foreground">Úsala como app, incluso sin internet.</div>
        </div>
        <button
          onClick={async () => {
            if (evt) {
              await evt.prompt();
              setVisible(false);
            } else {
              setGuia(true);
            }
          }}
          className="inline-flex items-center gap-2 rounded-2xl bg-primary px-4 py-3 text-base font-extrabold text-primary-foreground active:scale-95"
        >
          <Download className="size-5" /> Instalar
        </button>
        <button
          onClick={ocultar}
          aria-label="Ahora no"
          className="grid size-10 shrink-0 place-items-center rounded-xl border border-border"
        >
          <X className="size-5" />
        </button>
      </div>

      {guia && (
        <div
          className="fixed inset-0 z-50 grid place-items-end bg-black/50 p-3 sm:place-items-center"
          onClick={() => setGuia(false)}
        >
          <div
            className="w-full max-w-md rounded-3xl bg-card p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <img src={logo.url} alt="Logo Cooprecoz" className="size-12 rounded-xl object-contain" />
              <h2 className="text-xl font-extrabold">Cómo instalar COPprecoz</h2>
            </div>

            <ol className="mt-4 space-y-3 text-lg">
              {ios ? (
                <>
                  <li className="flex gap-3">
                    <Share className="mt-1 size-6 shrink-0 text-primary" />
                    <span>
                      En Safari toca el botón <b>Compartir</b> (el cuadrito con la flecha hacia
                      arriba).
                    </span>
                  </li>
                  <li className="flex gap-3">
                    <PlusSquare className="mt-1 size-6 shrink-0 text-primary" />
                    <span>
                      Elige <b>Añadir a pantalla de inicio</b>.
                    </span>
                  </li>
                  <li className="flex gap-3">
                    <Download className="mt-1 size-6 shrink-0 text-primary" />
                    <span>
                      Toca <b>Añadir</b>. Verás el logo de Cooprecoz en tu pantalla de inicio.
                    </span>
                  </li>
                </>
              ) : (
                <>
                  <li className="flex gap-3">
                    <MoreVertical className="mt-1 size-6 shrink-0 text-primary" />
                    <span>
                      En Chrome toca los <b>tres puntos</b> de arriba a la derecha.
                    </span>
                  </li>
                  <li className="flex gap-3">
                    <PlusSquare className="mt-1 size-6 shrink-0 text-primary" />
                    <span>
                      Elige <b>Instalar aplicación</b> o <b>Añadir a pantalla de inicio</b>.
                    </span>
                  </li>
                  <li className="flex gap-3">
                    <Download className="mt-1 size-6 shrink-0 text-primary" />
                    <span>
                      Confirma con <b>Instalar</b>: aparecerá el logo de Cooprecoz.
                    </span>
                  </li>
                </>
              )}
            </ol>

            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setGuia(false)}
                className="flex-1 rounded-2xl bg-primary px-5 py-4 text-lg font-extrabold text-primary-foreground active:scale-95"
              >
                Entendido
              </button>
              <button
                onClick={ocultar}
                className="rounded-2xl border-2 border-border px-5 py-4 text-lg font-bold active:scale-95"
              >
                No mostrar
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
