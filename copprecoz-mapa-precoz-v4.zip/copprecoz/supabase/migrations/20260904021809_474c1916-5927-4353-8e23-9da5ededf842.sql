insert into public.team_owners (email) values ('juantaaaks@gmail.com') on conflict do nothing;

create or replace function public.is_team_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.team_owners o where lower(o.email) = lower(auth.jwt() ->> 'email'))
$$;

create policy "Owners manage owner list insert" on public.team_owners for insert to authenticated with check (public.is_team_owner());
create policy "Owners manage owner list delete" on public.team_owners for delete to authenticated using (public.is_team_owner());

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  seller_name text not null default '',
  sold_at timestamptz not null default now(),
  items jsonb not null default '{}'::jsonb,
  total integer not null default 0,
  received integer not null default 0,
  change_given integer not null default 0,
  notes text not null default '',
  created_at timestamptz not null default now()
);

grant select, insert, update, delete on public.sales to authenticated;
grant all on public.sales to service_role;
alter table public.sales enable row level security;

create policy "sales_own" on public.sales for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "sales_owners_select" on public.sales for select to authenticated using (public.is_team_owner());

create policy "cash_counts_owners_select" on public.cash_counts for select to authenticated using (public.is_team_owner());

create index sales_sold_at_idx on public.sales (sold_at desc);