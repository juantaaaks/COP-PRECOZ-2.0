CREATE TABLE public.team_owners (
  email text PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.team_owners TO authenticated;
GRANT ALL ON public.team_owners TO service_role;
ALTER TABLE public.team_owners ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_team_owner(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM auth.users u
    JOIN public.team_owners o ON lower(o.email) = lower(u.email)
    WHERE u.id = _user_id
  );
$$;
REVOKE EXECUTE ON FUNCTION public.is_team_owner(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.is_team_owner(uuid) TO authenticated, service_role;

CREATE POLICY "Owners can view owners" ON public.team_owners
FOR SELECT TO authenticated USING (public.is_team_owner(auth.uid()));

CREATE TABLE public.team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  cargo text NOT NULL DEFAULT 'cajero',
  status text NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente','aprobado','rechazado')),
  approved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.team_members TO authenticated;
GRANT ALL ON public.team_members TO service_role;
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Members see own request" ON public.team_members
FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.is_team_owner(auth.uid()));

CREATE POLICY "Members can request access" ON public.team_members
FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND status = 'pendiente');

CREATE POLICY "Owners can update members" ON public.team_members
FOR UPDATE TO authenticated USING (public.is_team_owner(auth.uid())) WITH CHECK (public.is_team_owner(auth.uid()));

CREATE POLICY "Owners can delete members" ON public.team_members
FOR DELETE TO authenticated USING (public.is_team_owner(auth.uid()));

CREATE OR REPLACE FUNCTION public.touch_team_members()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER team_members_touch BEFORE UPDATE ON public.team_members
FOR EACH ROW EXECUTE FUNCTION public.touch_team_members();