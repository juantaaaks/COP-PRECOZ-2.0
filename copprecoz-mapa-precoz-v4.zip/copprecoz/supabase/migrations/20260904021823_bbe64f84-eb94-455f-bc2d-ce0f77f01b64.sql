revoke execute on function public.is_team_owner() from public, anon;
grant execute on function public.is_team_owner() to authenticated, service_role;