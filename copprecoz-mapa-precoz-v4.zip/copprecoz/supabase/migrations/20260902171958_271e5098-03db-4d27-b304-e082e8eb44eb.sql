DROP POLICY "Owners can view owners" ON public.team_owners;
DROP POLICY "Members see own request" ON public.team_members;
DROP POLICY "Owners can update members" ON public.team_members;
DROP POLICY "Owners can delete members" ON public.team_members;
DROP FUNCTION IF EXISTS public.is_team_owner(uuid);

CREATE POLICY "Authenticated can view owner list" ON public.team_owners
FOR SELECT TO authenticated USING (true);

CREATE POLICY "Members see own request" ON public.team_members
FOR SELECT TO authenticated USING (
  user_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.team_owners o WHERE lower(o.email) = lower(auth.jwt() ->> 'email'))
);

CREATE POLICY "Owners can update members" ON public.team_members
FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM public.team_owners o WHERE lower(o.email) = lower(auth.jwt() ->> 'email'))
) WITH CHECK (
  EXISTS (SELECT 1 FROM public.team_owners o WHERE lower(o.email) = lower(auth.jwt() ->> 'email'))
);

CREATE POLICY "Owners can delete members" ON public.team_members
FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM public.team_owners o WHERE lower(o.email) = lower(auth.jwt() ->> 'email'))
);