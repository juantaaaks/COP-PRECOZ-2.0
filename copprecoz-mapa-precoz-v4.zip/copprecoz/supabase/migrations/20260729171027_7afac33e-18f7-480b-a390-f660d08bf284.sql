ALTER TABLE public.module_progress
  ADD CONSTRAINT module_progress_user_slug_unique UNIQUE (user_id, module_slug);