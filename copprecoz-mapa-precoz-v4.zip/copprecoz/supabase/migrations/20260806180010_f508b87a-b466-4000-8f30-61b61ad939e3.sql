CREATE TABLE public.cash_counts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  cashier_name text NOT NULL DEFAULT '',
  counted_at timestamptz NOT NULL DEFAULT now(),
  denominations jsonb NOT NULL DEFAULT '{}'::jsonb,
  coins_total integer NOT NULL DEFAULT 0,
  bills_total integer NOT NULL DEFAULT 0,
  total integer NOT NULL DEFAULT 0,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cash_counts TO authenticated;
GRANT ALL ON public.cash_counts TO service_role;
ALTER TABLE public.cash_counts ENABLE ROW LEVEL SECURITY;
CREATE POLICY cash_counts_own ON public.cash_counts FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX cash_counts_user_date_idx ON public.cash_counts (user_id, counted_at DESC);

CREATE TABLE public.avatars (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  owned text[] NOT NULL DEFAULT '{}',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.avatars TO authenticated;
GRANT ALL ON public.avatars TO service_role;
ALTER TABLE public.avatars ENABLE ROW LEVEL SECURITY;
CREATE POLICY avatars_own ON public.avatars FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);