# COP Conecta

Hola.

Quiero que desarrolles una plataforma completa compuesta por una página web y una aplicación móvil con el mismo diseño, funciones y base de datos sincronizada. La plataforma estará enfocada en enseñar a educandos neurodiversos el uso del dinero colombiano (COP) de una manera visual, práctica, interactiva y accesible.



El objetivo es que cualquier estudiante pueda aprender desde reconocer monedas y billetes hasta administrar su dinero en situaciones reales de la vida cotidiana.



Quiero un diseño moderno, limpio y amigable, inspirado en aplicaciones como Duolingo, pero adaptado a personas neurodiversas. La navegación debe ser muy sencilla, con botones grandes, pocos elementos por pantalla, ilustraciones claras, colores suaves, iconos intuitivos y una experiencia que reduzca las distracciones.



La plataforma debe incluir un sistema de inicio de sesión con tres tipos de usuarios: estudiante, docente y acudiente, donde cada uno tenga un panel personalizado.



Para los estudiantes, quiero un panel principal con acceso rápido a todos los módulos de aprendizaje y un sistema de progreso que muestre nivel, experiencia, medallas, logros, tiempo de estudio, porcentaje de avance y retos completados.



Los módulos deben incluir:



Conocer todas las monedas y billetes colombianos con imágenes, audio y explicación.

Reconocer monedas y billetes mediante juegos.

Contar dinero.

Operaciones matemáticas usando dinero (sumas, restas, multiplicaciones y divisiones).

Calculadora especializada en pesos colombianos (COP).

Calculadora de descuentos.

Calculadora de cambio.

Simulador de supermercado.

Simulador de tienda de barrio.

Simulador de restaurante.

Simulador de transporte público.

Simulador de compras por internet.

Caja registradora interactiva.

Juegos para calcular el cambio correcto.

Presupuestos personales.

Metas de ahorro.

Educación financiera básica.

Diferenciar necesidades y deseos.

Organización de gastos.

Planeación de compras.

Uso responsable del dinero.

Quiero un asistente inteligente integrado que explique cualquier ejercicio, dé pistas cuando el estudiante tenga dificultades, motive constantemente y adapte automáticamente la dificultad según el desempeño del usuario.



También quiero un sistema completo de gamificación con niveles, estrellas, monedas virtuales, medallas, insignias, desafíos diarios, recompensas, rachas de estudio, misiones semanales y desbloqueo de nuevos contenidos.



El docente debe tener un panel donde pueda crear estudiantes, organizar grupos, asignar actividades, revisar estadísticas, identificar errores frecuentes, generar informes y monitorear el progreso de cada estudiante.



Los acudientes deben tener un panel donde puedan visualizar el avance del estudiante, el tiempo de práctica, los logros obtenidos y recibir recomendaciones para reforzar el aprendizaje desde casa.



Toda la plataforma debe ser completamente accesible, incluyendo lectura en voz alta, instrucciones por audio, ajuste del tamaño del texto, alto contraste, modo oscuro, subtítulos, navegación sencilla y retroalimentación positiva.



La aplicación debe funcionar correctamente tanto en dispositivos móviles como en computadores, sincronizando automáticamente toda la información entre la página web y la aplicación.



Incluye un sistema de notificaciones para recordar actividades, retos diarios, metas de ahorro y nuevos logros.



Agrega un buscador interno para encontrar rápidamente cualquier actividad o módulo.



Incluye estadísticas visuales con gráficos sencillos para mostrar el progreso.



Toda la plataforma debe utilizar únicamente pesos colombianos (COP), mostrando los valores con el formato correcto.



Quiero una plataforma profesional, moderna, intuitiva y lista para crecer con nuevos módulos en el futuro. Organiza el proyecto con una estructura escalable, interfaces limpias y una experiencia de usuario excepcional, priorizando siempre la accesibilidad y el aprendizaje de personas neurodiversas.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://cop-precoz.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4a5e3743-8de2-4fa3-9b0c-aaef516bc3e3).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
